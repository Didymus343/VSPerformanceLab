﻿using System;

namespace BoundsChecksLab {
    public class ImprovedPositivesCounter {

        private readonly double[] _data;

        public ImprovedPositivesCounter(double[] data) => _data = data;

        public int All() {
            int total = 0;
            double[] data = _data;
            for (int i = 0; i < data.Length; i++) {
                if (data[i] > 0) {
                    total++;
                }
            }
            return total;
        }

        public int Subset(int start, int length) {
            int total = 0;
            var data = new ReadOnlySpan<double>(_data, start, length);
            for (int i = 0; i < data.Length; i++) {
                if (data[i] > 0) {
                    total++;
                }
            }
            return total;
        }
    }

}
