﻿using System;

namespace BoundsChecksLab {

    public class PositivesCounter {

        private readonly double[] _data;

        public PositivesCounter(double[] data) => _data = data;

        public int All() => CountSpan(_data.AsSpan());

        public int Subset(int start, int length) => CountSpan(_data.AsSpan(start, length));

        private static int CountSpan(Span<double> span) {
            int total = 0;
            for (int i = 0; i < span.Length; i++) {
                if (span[i] > 0) {
                    total++;
                }
            }
            return total;
        }
    }
}
