﻿namespace BoundsChecksLab {
    internal class Program {

        static void Main(string[] args) {
            //var pc = new PositivesCounter(new double[10240]);
            var pc = new ImprovedPositivesCounter(new double[10240]);

            PerformanceUtils.Measure(() => {
                pc.All();
            }, repeats: 10_000, warmups: 10_000);

            PerformanceUtils.Measure(() => {
                pc.Subset(1024, 2048);
            }, repeats: 10_000, warmups: 10_000);
        }
    }

}
