﻿using System;
using System.Linq;

namespace BoundsChecksLab {
    public class ImprovedPositivesCounter {

        private readonly double[] _data;

        public ImprovedPositivesCounter(double[] data) => _data = data;

        public int All() {
            int total = 0;
            for (int i = 0; i < _data.Length; i++) {
                if (_data[i] > 0) {
                    total++;
                }
            }
            return total;
        }

        public int Subset(int start, int length) {
            return _data.Skip(start).Take(length).Count(n => n > 0);
        }
    }

}
