﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Microsoft.Extensions.Primitives;
using System;
using System.Linq;

namespace SpanLab {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    [ShortRunJob]
    public class BM {

        private readonly string _text = "Hello World performance in a C# trainiNg";
        private static readonly char[] _separators = new char[] { ' ' };

        [Benchmark(Baseline = true)]
        public int CountUsingSplit() => this._text.Split(_separators).Count(word => word.Any(c => char.IsUpper(c)));

        [Benchmark()]
        public int CountUsingSpan() {
            // TODO: create your own implementation here with 0 allocations
            throw new NotImplementedException();
        }


    }
    public static class Extensions {

        // https://extensionmethod.net/csharp/readonlyspan/splitnext
        public static ReadOnlySpan<T> SplitNext<T>(this ref ReadOnlySpan<T> span, T seperator) where T : IEquatable<T> {
            int pos = span.IndexOf(seperator);
            if (pos > -1) {
                var part = span.Slice(0, pos);
                span = span.Slice(pos + 1);
                return part;
            } else {
                var part = span;
                span = span.Slice(span.Length);
                return part;
            }
        }

    }

}