﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using CommunityToolkit.HighPerformance;
using Microsoft.Extensions.Primitives;
using System;
using System.Linq;

namespace SpanLab {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    [HideColumns("Job", "Error", "StdDev", "Median", "RatioSD", "Alloc Ratio")]
    [ShortRunJob]
    public class BM {

        private readonly string _text = "Hello World performance in a C# trainiNg";
        private static readonly char[] _separators = new char[] { ' ' };

        [Benchmark(Baseline = true)]
        public int CountUsingSplit() => this._text.Split(_separators).Count(word => word.Any(c => char.IsUpper(c)));

        [Benchmark()]
        public int CountUsingSpan() {
            ReadOnlySpan<char> s = _text;
            int t = 0;
            while (s.Length > 0) {
                var i = s.IndexOf(' ');
                var word = i > -1 ? s.Slice(0, i) : s;
                if (ContainsUppercase(word)) {
                    t++;
                }
                if (i == -1) {
                    break;
                }
                s = s.Slice(i + 1);
            }
            return t;
        }

        private static bool ContainsUppercase(ReadOnlySpan<char> span) {
            for (int i = 0; i < span.Length; i++) {
                if (char.IsUpper(span[i])) {
                    return true;
                }
            }
            return false;
        }

        [Benchmark]
        public int CountUsingStringTokenizer() {
            // Install-Package Microsoft.Extensions.Primitives
            StringTokenizer tokenizer = new StringTokenizer(this._text, _separators);
            int t = 0;
            foreach (var segment in tokenizer) {
                if (ContainsUppercase(segment)) {
                    t++;
                }
            }
            return t;
        }

        private static bool ContainsUppercase(StringSegment segment) {
            for (int i = 0; i < segment.Length; i++) {
                if (char.IsUpper(segment[i])) {
                    return true;
                }
            }
            return false;
        }


        [Benchmark]
        public int CountUsingSplitNext() {
            int t = 0;
            ReadOnlySpan<char> span = _text.AsSpan();
            scoped ReadOnlySpan<char> word;
            while (!(word = span.SplitNext(' ')).IsEmpty) {
                if (ContainsUppercase(word)) {
                    t++;
                }
            }
            return t;
        }

        [Benchmark]
        public int CountUsingReadOnlySpanTokenizer() {
            // Install-Package CommunityToolkit.HighPerformance
            var tokenizer = this._text.Tokenize(' '); // Extension Method
            int t = 0;
            foreach (var span in tokenizer) {
                if (ContainsUppercase(span)) {
                    t++;
                }
            }
            return t;
        }

    }
    public static class Extensions {

        public static ReadOnlySpan<T> SplitNext<T>(this ref ReadOnlySpan<T> span, T seperator) where T : IEquatable<T> {
            int pos = span.IndexOf(seperator);
            if (pos > -1) {
                var part = span.Slice(0, pos);
                span = span.Slice(pos + 1);
                return part;
            } else {
                var part = span;
                span = span.Slice(span.Length);
                return part;
            }
        }

    }

}