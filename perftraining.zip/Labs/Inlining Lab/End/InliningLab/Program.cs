﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InliningLab {
    class Program {

        static void Main(string[] args) {
            Console.WriteLine(Foo(12, 12, 12));
            Console.WriteLine(Bar(12, 12, 12));
            BenchmarkRunner.Run<BM>();
        }

        public static double Foo(double a, double b, decimal c) {
            if (a < 0) {
                throw new ArgumentOutOfRangeException(nameof(a), "Must be positive");
            } else if (a > 100) {
                throw new ArgumentOutOfRangeException(nameof(a), "Must be below 101");
            }
            return a * b / (double)c;
        }

        public static double Bar(double a, double b, decimal c) {
            if (a < 0 || a > 100) {
                ThrowHelper.ThrowArgumentOutOfRangeException(nameof(a), "Must be between 0 and 100");
            }
            return a * b / (double)c;
        }
    }

    static class ThrowHelper {

        public static void ThrowArgumentOutOfRangeException(string name, string text) {
            throw new ArgumentOutOfRangeException(name, text);
        }

    }

    public class BM {

        [Benchmark]
        public double Foo() => Program.Foo(12D, 12D, 12M);

        [Benchmark(Baseline = true)]
        public double Bar() => Program.Bar(12D, 12D, 12M);

    }
}
