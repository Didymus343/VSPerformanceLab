namespace TestProject1;

using LinqToObjectsLab.Models;
using Xunit;

public class HumanResourcesTest {

    private readonly Company _reflectionIT;
    private readonly Company _asml;

    private readonly Employee _empFons;
    private readonly Employee _empEllen;
    private readonly Employee _empJim;

    public HumanResourcesTest() {
        _empFons = new Employee("Fons", 2000, "Asten");
        _empEllen = new Employee("Ellen", 3000, "Amsterdam");
        _empJim = new Employee("Jim", 4000, null);

        _reflectionIT = new Company("Reflection IT", "Asten");
        _asml = new Company("ASML", null);
    }

    [Fact]
    public void TestAddEmployee() {
        // Act
        _reflectionIT.Employees.Add(_empFons);

        // Assert
        Assert.Single(_reflectionIT.Employees);
        Assert.Equal(_empFons.Employer, _reflectionIT);
    }

    [Fact]
    public void TestSetEmployer() {
        // Act
        _empFons.Employer = _reflectionIT;

        // Assert
        Assert.Single(_reflectionIT.Employees);
        Assert.Equal(_empFons.Employer, _reflectionIT);
    }

    [Fact]
    public void TestAddToDifferentEmployer() {
        // Arange
        _reflectionIT.Employees.Add(_empFons);

        // Act
        _asml.Employees.Add(_empFons);

        // Assert
        Assert.Empty(_reflectionIT.Employees);
        Assert.Single(_asml.Employees);
        Assert.Equal(_empFons.Employer, _asml);
    }

    [Fact]
    public void TestModifyEmployee() {
        // Arange
        _reflectionIT.Employees.Add(_empFons);
        _reflectionIT.Employees.Add(_empJim);

        // Act
        _reflectionIT.Employees[1] = _empEllen;

        // Assert
        Assert.Equal(2, _reflectionIT.Employees.Count);
        Assert.Equal(_empFons.Employer, _reflectionIT);
        Assert.Equal(_empEllen.Employer, _reflectionIT);
        Assert.Null(_empJim.Employer);
    }

    [Fact]
    public void TestModifyEmployer() {
        // Arange
        _reflectionIT.Employees.Add(_empFons);

        // Act
        _empFons.Employer = _asml;

        // Assert
        Assert.Empty(_reflectionIT.Employees);
        Assert.Single(_asml.Employees);
        Assert.Equal(_empFons.Employer, _asml);
    }

    [Fact]
    public void ClearEmployees() {
        _reflectionIT.Employees.Add(_empFons);
        _reflectionIT.Employees.Add(_empEllen);
        _reflectionIT.Employees.Add(_empJim);

        // Act
        _reflectionIT.Employees.Clear();

        // Assert
        Assert.Empty(_reflectionIT.Employees);
        Assert.Null(_empFons.Employer);
        Assert.Null(_empEllen.Employer);
        Assert.Null(_empJim.Employer);
    }


}

