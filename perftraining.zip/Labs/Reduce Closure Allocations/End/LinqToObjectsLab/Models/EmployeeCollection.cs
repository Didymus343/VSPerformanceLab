﻿using System.Collections;
using System.Collections.ObjectModel;

namespace LinqToObjectsLab.Models {

    public sealed class EmployeeCollection : Collection<Employee> {

        private Company Company { get; }

        public EmployeeCollection(Company owner) {
            Company = owner;
        }

        protected override void InsertItem(int index, Employee item) {
            if (!Contains(item)) {
                base.InsertItem(index, item);
                item.Employer = Company;
            }
        }

        protected override void RemoveItem(int index) {
            Employee emp = this[index];
            base.RemoveItem(index);
            emp.Employer = null;
        }

        protected override void ClearItems() {
            var employees = new List<Employee>(this.Items);
            base.ClearItems();
            foreach (Employee emp in employees) {
                emp.Employer = null;
            }
        }

        protected override void SetItem(int index, Employee item) {
            Employee emp = this[index];
            base.SetItem(index, item);
            emp.Employer = null;
            item.Employer = Company;
        }

    }

}

