﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace LinqToObjectsLab.Models {

    [DebuggerDisplay("Company: {Name}")]
    public class Company {

        public EmployeeCollection Employees { get; }
        //public EmployeeList Employees { get; }

        public Company(string name, string city) {
            Name = name;
            City = city;
            Employees = new (this);
        }

        public string Name { get; set; }
        public string City { get; set; }

        public override string ToString() {
            return string.Format("Name = {0}, City = {1}", Name, City);
        }

    }

}

