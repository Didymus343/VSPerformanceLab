﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace LinqToObjectsLab.Models {

    [DebuggerDisplay("Employee: {Name}")]
    public class Employee {

        public string Name { get; set; }
        public decimal Salary { get; set; }
        public string City { get; set; }

        private Company? _employer;

        public Employee(string name, decimal salary, string city) {
            Name = name;
            Salary = salary;
            City = city;
        }

        public Company? Employer {
            get {
                return _employer;
            }
            set {
                if (Employer != value) {

                    // Remove from 'old' Employer
                    if (Employer is not null) {
                        Company old = Employer;
                        _employer = null;
                        old.Employees.Remove(this);
                    }

                    // Set the Employer				
                    _employer = value;

                    // Add to 'new' Employer
                    if (Employer?.Employees.Contains(this) == false) {
                        Employer.Employees.Add(this);
                    }
                }
            }
        }

        public override string ToString() {
            return $"Name = {Name}, Salary = {Salary.ToString()}, City = {City}, Employer = [{Employer}]";
        }

    }

}

