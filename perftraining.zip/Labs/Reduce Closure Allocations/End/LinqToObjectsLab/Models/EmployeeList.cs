﻿using System.Collections.Generic;

namespace LinqToObjectsLab.Models {
    public sealed class EmployeeList : List<Employee> {

        private Company Company { get; }

        public EmployeeList(Company owner) {
            Company = owner;
        }

        public new void Insert(int index, Employee item) {
            base.Insert(index, item);
            item.Employer = Company;
        }

        public new void RemoveAt(int index) {
            var emp = base[index];
            base.RemoveAt(index);
            emp.Employer = null;
        }

        public new Employee this[int index] {
            get => base[index];
            set {
                var old = base[index];                
                base[index] = value;
                old.Employer = null;
                value.Employer = Company;
            }
        }

        public new void Add(Employee item) {
            base.Add(item);
            item.Employer = Company;
        }

        public new void Clear() {
            var employees = this.ToArray();
            base.Clear();
            foreach (var item in employees) {
                item.Employer = null;
            }
        }

        public new bool Remove(Employee item) {
            try {
                return base.Remove(item);
            } finally {
                item.Employer = null;
            }
        }

    }

}

