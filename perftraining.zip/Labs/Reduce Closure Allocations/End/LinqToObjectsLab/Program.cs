﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LinqToObjectsLab.Models;

namespace LinqToObjectsLab {
    class Program {
        static void Main() {

            var fons = new Employee("Fons", 2000, "Asten");
            var ellen = new Employee("Ellen", 3000, "Amsterdam");
            var jim = new Employee("Jim", 4000, "Amsterdam");
            var frank = new Employee("Frank", 3000, "Rotterdam");
            var anna = new Employee("Anna", 6000, "Utrecht");

            List<Employee> employees = new List<Employee> { fons, ellen, jim, frank, anna };

            var rit = new Company("Reflection IT", "Asten");
            var dmy = new Company("Dummy Inc", "Utrecht");

            List<Company> companies = new List<Company> { rit, dmy };

            rit.Employees.Add(fons);

            dmy.Employees.Add(ellen);
            dmy.Employees.Add(jim);
            dmy.Employees.Add(anna);
            frank.Employer = dmy;
            
            ShowEmployeesWithSalaryBelowAverageEmployerSalary(employees, companies);

            var sw = System.Diagnostics.Stopwatch.StartNew();
            for (int i = 0; i < 100_000; i++) {
                //ShowEmployeesWithSalaryBelowAverageEmployerSalary(employees, companies);
            }
            sw.Stop();
            Console.WriteLine(sw.Elapsed.TotalSeconds);
        }
        private static void ShowEmployeesWithSalaryBelowAverageEmployerSalary(List<Employee> employees, List<Company> companies) {
            foreach (var company in companies) {
                if (company.Employees.Count == 0) {
                    continue;
                }

                var avg = company.Employees.Average(emp => emp.Salary);

                //decimal avg = 0;
                //foreach (var emp in company.Employees) {
                //    avg += emp.Salary;
                //}
                //avg = avg / company.Employees.Count;

                foreach (var emp in company.Employees) {
                    if (emp.Salary < avg) {
                        Console.WriteLine(emp.ToString());
                    }
                }
            }
        }
    }

}
