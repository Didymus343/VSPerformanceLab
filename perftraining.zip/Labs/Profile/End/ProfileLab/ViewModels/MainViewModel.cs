﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.HighPerformance.Buffers;
using CommunityToolkit.HighPerformance.Enumerables;
using ProfileLab.Models;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.IO;
using System.Text.Unicode;
using System.Text;

namespace ProfileLab.ViewModels {
    internal partial class MainViewModel : ObservableObject {

        [ObservableProperty]
        private List<Data> _data = new();

        [ObservableProperty]
        private double _duration;

        [RelayCommand]
        private void OnProcess(string path) {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            try {
                using var memoryOwner = GetBytesFromFile(path);
                var list = new List<Data>(capacity: 17_000);
                var header = true;
                foreach (var line in new ReadOnlySpanTokenizer<byte>(memoryOwner.Span, (byte)'\n')) {
                    if (header) {
                        header = false;
                    } else {
                        var data = new Data();
                        var index = 0;
                        foreach (var item in new ReadOnlySpanTokenizer<byte>(line, (byte)',')) {
                            switch (index++) {
                                case 0:
                                    data.VendorId = MakeString(item, StringPool.Shared);
                                    break;
                                case 1:
                                    if (Utf8Parser.TryParse(item, out int rateCode, out _)) {
                                        data.RateCode = (RateCodes)rateCode;
                                    }
                                    break;
                                case 2:
                                    if (Utf8Parser.TryParse(item, out byte passengerCount, out _)) {
                                        data.PassengerCount = passengerCount;
                                    }
                                    break;
                                case 3:
                                    if (Utf8Parser.TryParse(item, out short tripTimeInSecs, out _)) {
                                        data.TripTimeInSecs = tripTimeInSecs;
                                    }
                                    break;
                                case 4:
                                    if (Utf8Parser.TryParse(item, out double tripDistance, out _)) {
                                        data.TripDistance = tripDistance;
                                    }
                                    break;
                                case 5:
                                    data.PaymentType = MakeString(item, StringPool.Shared);
                                    break;
                                case 6:
                                    if (Utf8Parser.TryParse(item, out decimal fareAmount, out _)) {
                                        data.FareAmount = fareAmount;
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                        list.Add(data);
                    }
                }
                Data = list;
            } finally {
                sw.Stop();
                Duration = sw.Elapsed.TotalSeconds;
            }

            static string MakeString(ReadOnlySpan<byte> bytes, StringPool pool) {
                Span<char> chars = stackalloc char[Encoding.UTF8.GetMaxCharCount(bytes.Length)];
                Utf8.ToUtf16(bytes, chars, out _, out _);
                return pool.GetOrAdd(chars);
            }

            static MemoryOwner<byte> GetBytesFromFile(string path) {
                using Stream stream = File.OpenRead(path);
                MemoryOwner<byte> buffer = MemoryOwner<byte>.Allocate((int)stream.Length);
                stream.Read(buffer.Span);
                return buffer;
            }
        }
    }
}
