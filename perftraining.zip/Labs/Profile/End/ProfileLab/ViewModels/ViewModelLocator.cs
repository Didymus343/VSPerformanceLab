﻿using CommunityToolkit.Mvvm.DependencyInjection;

namespace ProfileLab.ViewModels {
    internal class ViewModelLocator {

        public static MainViewModel? Main { get; } = Ioc.Default.GetService<MainViewModel>();
    }
}
