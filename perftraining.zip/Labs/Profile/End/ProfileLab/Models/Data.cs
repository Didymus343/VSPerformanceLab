﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProfileLab.Models {

    record struct Data {

        public string VendorId;
        public RateCodes RateCode;
        public byte PassengerCount;
        public short TripTimeInSecs;
        public double TripDistance;
        public string PaymentType;
        public decimal FareAmount;

        public override string ToString() {
            return $"{VendorId},{RateCode},{PassengerCount},{TripTimeInSecs},{TripDistance:N2},{PaymentType},{FareAmount:C2}";
        }
    }
}
