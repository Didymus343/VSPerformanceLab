﻿using System;

namespace ProfileLab.Models {
    [Flags]
    enum RateCodes {
        None = 0,
        Normal = 1,
        Senior = 2,
        Night = 4,
        LargGroup = 8
    }
}
