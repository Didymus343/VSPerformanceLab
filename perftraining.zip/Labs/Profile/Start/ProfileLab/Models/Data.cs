﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProfileLab.Models {
    record class Data(string VendorId, RateCodes RateCode, byte PassengerCount, short TripTimeInSecs, double TripDistance, string PaymentType, decimal FareAmount) {

        public override string ToString() {
            return $"{VendorId},{RateCode},{PassengerCount},{TripTimeInSecs},{TripDistance:N2},{PaymentType},{FareAmount:C2}";
        }
    }
}
