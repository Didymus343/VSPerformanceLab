﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ProfileLab.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace ProfileLab.ViewModels {
    internal partial class MainViewModel : ObservableObject {

        public ObservableCollection<Data> Data { get; } = new();

        [ObservableProperty]
        private double _duration;

        [RelayCommand]
        private void OnProcess(string path) {
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
            try {
                Data.Clear();
                string[] lines = File.ReadAllLines(path);

                foreach (string? line in lines.Skip(1)) {
                    string[] values = line.Split(',');

                    Data data = new Data(
                        VendorId: values[0],
                        RateCode: (RateCodes)int.Parse(values[1]),
                        PassengerCount: byte.Parse(values[2]),
                        TripTimeInSecs: short.Parse(values[3]),
                        TripDistance: double.Parse(values[4]),
                        PaymentType: values[5],
                        FareAmount: decimal.Parse(values[6]));

                    Data.Add(data);
                }
            } finally {
                sw.Stop();
                Duration = sw.Elapsed.TotalSeconds;
            }
        }
            
    }
}
