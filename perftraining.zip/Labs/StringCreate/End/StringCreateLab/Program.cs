﻿using System;

namespace StringCreateLab {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine(new ClockTime().ToString());
            Console.WriteLine(new ClockTime(1, 5).ToString());
            Console.WriteLine(new ClockTime(2, 15).ToString());
            Console.WriteLine(new ClockTime(10, 25).ToString());
            Console.WriteLine(new ClockTime(24, 59).ToString());
            Console.WriteLine(new ClockTime(10, 25).AddMinutes(40).ToString());
            Console.WriteLine(new ClockTime(10, 25).AddHours(10).ToString());
            Console.WriteLine(new ClockTime(10, 25).AddHours(17).ToString());
            Console.WriteLine(new ClockTime(10, 25).Add(new ClockTime(2, 35)).ToString());
            Console.WriteLine();

            var t = new ClockTime(14, 50);

            var sw = System.Diagnostics.Stopwatch.StartNew();
            for (int i = 0; i < 10_000_000; i++) {
                string s = t.ToString();
            }
            sw.Stop();
            Console.WriteLine(sw.Elapsed.ToString());
        }
    }
}
