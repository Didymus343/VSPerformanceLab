﻿using System;

namespace StringCreateLab {

    readonly struct ClockTime : IEquatable<ClockTime> {

        public readonly byte Hours;
        public readonly byte Minutes;

        public ClockTime(int totalMinutes) : this(totalMinutes / 60, totalMinutes % 60) {
        }

        public ClockTime(int hours, int minutes) {
            if (hours > 23) {
                hours -= (hours / 24) * 24;
            }
            Hours = hours >= 0 ? (byte)hours : throw new ArgumentOutOfRangeException(nameof(hours), "Must be positive");
            Minutes = minutes >= 0 && minutes < 60 ? (byte)minutes : throw new ArgumentOutOfRangeException(nameof(minutes), "Must be between 0 and 59");
        }

        public int TotalMinutes => Hours * 60 + Minutes;

        public override string ToString() {
            // TODO: create the string using string.Create<T>() method
            //return $"{Hours.ToString("00")}:{Minutes.ToString("00")}";
            return $"{Hours:00}:{Minutes:00}";
        }

        public override bool Equals(object obj) => obj is ClockTime time && Equals(time);

        public bool Equals(ClockTime other) => TotalMinutes == other.TotalMinutes;

        public override int GetHashCode() => TotalMinutes;

        

        public static bool operator ==(ClockTime left, ClockTime right) => left.Equals(right);

        public static bool operator !=(ClockTime left, ClockTime right) => !(left == right);

        public ClockTime AddMinutes(int minutes) => new ClockTime(TotalMinutes + minutes);

        public ClockTime AddHours(int hours) => AddMinutes(hours * 60);

        public ClockTime Add(ClockTime clockTime) => new ClockTime(TotalMinutes + clockTime.TotalMinutes);
    }
}
