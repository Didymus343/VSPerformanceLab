﻿using BenchmarkDotNet.Running;

//BenchmarkRunner.Run<BM>();

var bm = new BM();
Console.WriteLine(bm.StringCreate());
Console.WriteLine();
Console.WriteLine(bm.ArrayReverse());
