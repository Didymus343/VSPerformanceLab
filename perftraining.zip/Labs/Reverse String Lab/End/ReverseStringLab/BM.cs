﻿using BenchmarkDotNet.Attributes;

[MemoryDiagnoser(false)]
[ShortRunJob]
public class BM {

    private readonly string _text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas viverra ex et sodales gravida. Aenean semper tincidunt sapien, a posuere lorem venenatis non. Ut interdum, felis ut dapibus placerat, libero libero sodales nibh, vitae blandit orci tellus id ante. Curabitur laoreet eu neque vel pharetra. Phasellus mollis efficitur maximus. Vestibulum mattis arcu facilisis magna pellentesque, eu euismod felis fringilla. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed venenatis dignissim turpis sit amet interdum. Curabitur sodales, ex non molestie dapibus, augue felis euismod leo, vel suscipit neque turpis vitae diam. Aenean id porttitor enim. Suspendisse vel velit finibus, scelerisque lacus nec, vestibulum ante. Nulla hendrerit urna lectus, eget commodo nisl rutrum sed. Mauris dignissim gravida lacinia. Proin et consectetur libero, a feugiat nisi. Phasellus vel nisl sapien. Quisque libero justo, hendrerit in tincidunt at, blandit nec purus.";


    [Benchmark(Baseline = true)]
    public string ArrayReverse() {
        var a = _text.ToCharArray();
        Array.Reverse(a);
        return new string(a);
    }

    [Benchmark]
    public string StringCreate() {
        return string.Create(_text.Length, state: _text, static (chars, state) => {
            state.AsSpan().CopyTo(chars);
            chars.Reverse();
        });
    }

}
