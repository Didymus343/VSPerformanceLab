﻿using BenchmarkDotNet.Attributes;

namespace Lab1 {

    [MemoryDiagnoser(false)]
    [ShortRunJob]
    public class BM {

        [Benchmark()]
        public void CreatePointClass() {
            for (int i = 0; i < 100; i++) {
               var p = new PointClass(i, i);
            }
        }

        [Benchmark(Baseline = true)]
        public void CreatePointStruct() {
            for (int i = 0; i < 100; i++) {
                var p = new PointStruct(i, i);
            }
        }

    }

}
