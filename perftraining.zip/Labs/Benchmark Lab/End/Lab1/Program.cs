﻿using BenchmarkDotNet.Running;
using Lab1;

BenchmarkRunner.Run<BM>();
