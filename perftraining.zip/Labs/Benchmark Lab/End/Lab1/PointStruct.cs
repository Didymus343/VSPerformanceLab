﻿namespace Lab1 {
    public struct PointStruct {

        public readonly int X;
        public readonly int Y;

        public PointStruct(int x, int y) {
            this.X = x;
            this.Y = y;
        }
    }

}
