﻿// TODO: Start a Benchmark.NET Benchmark using BenchmarkRunner.Run<T>()
