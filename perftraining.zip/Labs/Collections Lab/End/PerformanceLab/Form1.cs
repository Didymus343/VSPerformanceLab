﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PerformanceLab {
    public partial class Form1 : Form {

        private readonly Dictionary<Point, double> _dictDistance = new Dictionary<Point, double>();
        //private readonly Dictionary<Point, double> _dictDistance = new Dictionary<Point, double>(600 * 300);

        public Form1() {
            InitializeComponent();
        }

        private void ButtonInit_Click(object sender, EventArgs e) {
            if (_dictDistance.Count == 0) {
                Init();
            }
        }

        private void Init() {
            using (new DurationLogger()) {
                _dictDistance.EnsureCapacity(600 * 300);
                for (int x = 0; x < 600; x++) {
                    for (int y = 0; y < 300; y++) {
                        var p = new Point(x, y);
                        var dist = p.Dist;
                        this._dictDistance.Add(p, dist);
                    }
                }
            }
        }

        private void ButtonFoo_Click(object sender, EventArgs e) {
            if (_dictDistance.Count != 0) {
                buttonFoo.Text = Foo().ToString();
            }
        }

        private double Foo() {
            using (new DurationLogger()) {
                double t = 0;
                for (int x = 0; x < 600; x += 2) {
                    for (int y = 0; y < 300; y++) {
                        var p = new Point(x, y);
                        var d = _dictDistance[p];
                        if (d > 100) {
                            t += d;
                        }
                    }
                }
                return t;
            }
        }

        private void ButtonBar_Click(object sender, EventArgs e) {

            if (_dictDistance.Count != 0) {
                buttonBar.Text = Bar().Length.ToString();
            }
        }

        private string Bar() {
            using (new DurationLogger()) {
                StringBuilder s = new StringBuilder(200_000);
                foreach (var item in _dictDistance.Keys.Take(25000)) {
                    s.Append(item.ToString());
                }
                return s.ToString();
            }
        }

    }
}
