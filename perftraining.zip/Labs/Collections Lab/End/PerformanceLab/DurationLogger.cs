﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace PerformanceLab {
    public sealed class DurationLogger : IDisposable {

        private readonly Stopwatch _stopwatch;
        private readonly string _text;
        private static int _level;
        private string _indent;

        public DurationLogger(string arguments = "", [CallerMemberName] string memberName = "") {
            _indent = new string(' ', _level++);
            _text = $"{memberName}({arguments})";
            Trace.TraceInformation($"{_indent}+{_text}: {DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss.fff")}");
            _stopwatch = Stopwatch.StartNew();
        }

        public void Dispose() {
            _level--;
            _stopwatch.Stop();
            Trace.TraceInformation($"{_indent}-{_text}: {_stopwatch.Elapsed.ToString()}");
        }
    }
}
