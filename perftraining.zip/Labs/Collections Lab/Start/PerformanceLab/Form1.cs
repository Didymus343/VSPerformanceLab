﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PerformanceLab {
    public partial class Form1 : Form {

        private readonly Dictionary<Point, double> _dictDistance = new Dictionary<Point, double>();

        public Form1() {
            InitializeComponent();
        }

        private void ButtonInit_Click(object sender, EventArgs e) {
            if (_dictDistance.Count == 0) {
                Init();
            }
        }

        private void Init() {
            using (new DurationLogger()) {
                for (int x = 0; x < 600; x++) {
                    for (int y = 0; y < 300; y++) {
                        var p = new Point(x, y);
                        var dist = p.Dist;
                        this._dictDistance.Add(p, dist);
                    }
                }
            }
        }

        private void ButtonFoo_Click(object sender, EventArgs e) {
            if (_dictDistance.Count != 0) {
                buttonFoo.Text = Foo().ToString();
            }
        }

        private double Foo() {
            using (new DurationLogger()) {
                double t = 0;
                for (int x = 0; x < 600; x += 2) {
                    for (int y = 0; y < 300; y++) {
                        var p = new Point(x, y);
                        var d = _dictDistance[p];
                        if (d > 100) {
                            t += d;
                        }
                    }
                }
                return t;
            }
        }

        private void ButtonBar_Click(object sender, EventArgs e) {
            if (_dictDistance.Count != 0) {
                buttonBar.Text = Bar().Length.ToString();
            }
        }

        private string Bar() {
            using (new DurationLogger()) {
                string s = "";
                foreach (var item in _dictDistance.Keys.Take(25000)) {
                    s += item.ToString();
                }
                return s;
            }
        }


    }
}

//PerformanceLab Information: 0 : +Init(): 10 / 23 / 2023 15:34:57.327
//PerformanceLab Information: 0 : -Init(): 00:00:00.8328424
//PerformanceLab Information: 0 : +Foo(): 10 / 23 / 2023 15:34:59.133
//PerformanceLab Information: 0 : -Foo(): 00:00:00.2550827
//PerformanceLab Information: 0 : +Bar(): 10 / 23 / 2023 15:35:00.679
//PerformanceLab Information: 0 : -Bar(): 00:00:01.3627562
