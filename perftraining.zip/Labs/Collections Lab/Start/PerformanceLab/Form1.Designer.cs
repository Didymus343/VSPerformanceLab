﻿namespace PerformanceLab {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            buttonFoo = new System.Windows.Forms.Button();
            buttonBar = new System.Windows.Forms.Button();
            buttonInit = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // buttonFoo
            // 
            buttonFoo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            buttonFoo.Location = new System.Drawing.Point(21, 134);
            buttonFoo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            buttonFoo.Name = "buttonFoo";
            buttonFoo.Size = new System.Drawing.Size(305, 82);
            buttonFoo.TabIndex = 0;
            buttonFoo.Text = "Foo";
            buttonFoo.UseVisualStyleBackColor = true;
            buttonFoo.Click += ButtonFoo_Click;
            // 
            // buttonBar
            // 
            buttonBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            buttonBar.Location = new System.Drawing.Point(21, 239);
            buttonBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            buttonBar.Name = "buttonBar";
            buttonBar.Size = new System.Drawing.Size(305, 82);
            buttonBar.TabIndex = 1;
            buttonBar.Text = "Bar";
            buttonBar.UseVisualStyleBackColor = true;
            buttonBar.Click += ButtonBar_Click;
            // 
            // buttonInit
            // 
            buttonInit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            buttonInit.Location = new System.Drawing.Point(21, 26);
            buttonInit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            buttonInit.Name = "buttonInit";
            buttonInit.Size = new System.Drawing.Size(305, 82);
            buttonInit.TabIndex = 2;
            buttonInit.Text = "Init";
            buttonInit.UseVisualStyleBackColor = true;
            buttonInit.Click += ButtonInit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(351, 355);
            Controls.Add(buttonInit);
            Controls.Add(buttonBar);
            Controls.Add(buttonFoo);
            Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button buttonFoo;
        private System.Windows.Forms.Button buttonBar;
        private System.Windows.Forms.Button buttonInit;
    }
}

