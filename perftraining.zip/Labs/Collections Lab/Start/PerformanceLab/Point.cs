﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceLab {
    internal struct Point {

        public int X;
        public int Y;

        public Point(int x, int y) {
            this.X = x;
            this.Y = y;
        }

        public double Dist => Math.Sqrt(X * X + Y * Y);

        public override string ToString() => $"({X},{Y})";
    }

}
