﻿using System;

namespace ConsoleApp98 {
readonly struct Time {

    public readonly int TotalMinutes;
    public int Hours => TotalMinutes / 60;
    public int Minutes => TotalMinutes % 60;

    public Time(int totalMinutes) {
        if (totalMinutes < 0) {
            throw new ArgumentOutOfRangeException(
                nameof(totalMinutes), "Must be positive");
        }
        this.TotalMinutes = totalMinutes;
    }

    public Time(int hours, int minutes) : this(hours * 60 + minutes) {
    }

    public override string ToString() {
        return $"{Hours.ToString()}:{Minutes.ToString("00")}";
    }
}
}
