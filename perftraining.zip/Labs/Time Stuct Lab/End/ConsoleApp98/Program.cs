﻿using System;

namespace ConsoleApp98 {
    class Program {
        static void Main(string[] args) {
            var t1 = new Time();
            var t2 = new Time(hours: 2, minutes: 70);
            var t3 = new Time(totalMinutes: 90);

            // Hours, Minutes and TotalMinutes can't be set
            //t1.Hours = 1; 

            Console.WriteLine(t1.ToString());
            Console.WriteLine(t2.ToString());
            Console.WriteLine(t3.ToString());
            Console.WriteLine(t3.TotalMinutes.ToString());
            Console.WriteLine(t3.Hours.ToString());
            Console.WriteLine(t3.Minutes.ToString());

            try {
                var t4 = new Time(-10);
            } catch (Exception ex) {
                Console.WriteLine(ex);
            }
        }
    }
}
