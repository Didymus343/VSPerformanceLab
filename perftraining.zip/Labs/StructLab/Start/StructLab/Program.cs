﻿using System;
using System.Linq;

namespace StructLab {
    class Program {
        static void Main(string[] args) {
            var d = new Document(Enumerable.Range(1, 10_000).Select(i => new Section(i, i, i)).ToArray());

            PerformanceUtils.Measure(() => {
                for (int i = 0; i < 100_000; i++) {
                    d.Contains(d.Get(d.Length - 1));
                }
            });
        }
    }

    struct Section {

        private readonly long _headerToken;
        private readonly long _bodyToken;
        private readonly long _payLoadToken;

        public Section(long headerToken, long bodyToken, long payLoadToken) {
            _headerToken = headerToken;
            _bodyToken = bodyToken;
            _payLoadToken = payLoadToken;
        }

        public long HeaderToken => _headerToken;
        public long BodyToken => _bodyToken;
        public long PayLoadToken => _payLoadToken;

    }

    class Document {

        private readonly Section[] _sections;

        public Document(Section[] sections) {
            _sections = sections;
        }

        public int Length => _sections.Length;

        public Section Get(int index) => _sections[index];

        public Section Set(int index, Section value) => _sections[index] = value;

        public bool Contains(Section value) {
            for (int i = 0; i < _sections.Length; i++) {
                var section = Get(i);
                if (value.HeaderToken == section.HeaderToken &&
                    value.BodyToken == section.BodyToken &&
                    value.PayLoadToken == section.PayLoadToken) {
                    return true;
                }
            }
            return false;
        }
    }


    public static class PerformanceUtils {

        public static void Measure(Action fp, int times = 10, int repeats = 1, int warmups = 4) {
            System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.High;
            System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Highest;

            Console.WriteLine(" Warmup... ");
            for (int i = 0; i < warmups; i++) {
                fp.Invoke();
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            Console.WriteLine(" Running... ");
            var sw = new System.Diagnostics.Stopwatch();
            var total = 0L;
            for (int i = 0; i < times; i++) {
                sw.Restart();
                for (int j = 0; j < repeats; j++) {
                    fp.Invoke();
                }
                sw.Stop(); //x
                total += sw.ElapsedMilliseconds;
                Console.WriteLine($" [{i}] Took:\t{sw.ElapsedMilliseconds:N0} ms");
            }
            Console.WriteLine($" Average:\t{total / times:N0} ms");
        }
    }

}
