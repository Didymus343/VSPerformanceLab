﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxingLab {

    class Program {
        static void Main(string[] args) {
            var v = new DemoStruct(5);

            FooBar(v);
        }

        static void FooBar<T>(T demo) where T : IDemo {
            demo.Foo();
            demo.Bar();
        }

    }


    interface IDemo {
        void Foo();
        void Bar();
    }

    struct DemoStruct : IDemo {

        public readonly int Value;

        public DemoStruct(int value) {
            Value = value;
        }

        public void Bar() {
            Console.WriteLine("Foo");
        }

        public void Foo() {
            Console.WriteLine("Bar");
        }
    }
}
