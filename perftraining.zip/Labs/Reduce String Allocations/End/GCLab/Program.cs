﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCLab {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser(false)]
    [ShortRunJob]
    public class BM {

        private readonly string _textA = "Hello World";
        private readonly string _textB = "HELLO world";

        [Benchmark]
        public bool UsingToUpper() {
            return _textA.ToUpper() == _textB.ToUpper();
        }

        [Benchmark(Baseline = true)]
        public bool UsingNoAllocaton() {
            return string.Equals(_textA, _textB, StringComparison.OrdinalIgnoreCase);
        }
    }
}
