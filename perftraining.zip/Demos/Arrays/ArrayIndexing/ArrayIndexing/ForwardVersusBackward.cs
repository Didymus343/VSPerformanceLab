﻿using BenchmarkDotNet.Attributes;

namespace ArrayIndexing {
    public class ForwardVersusBackwardReading {

        private const int n = 500000;


        [Benchmark(Baseline = true)]
        public int Forward() {
            int[] tab = new int[n];
            int t = 0;
            for (int i = 0; i < n; i++) {
                t += tab[i];
            }
            return t;
        }

        [Benchmark]
        public int Backward() {
            int[] tab = new int[n];
            int t = 0;
            for (int i = n - 1; i > -1; i--) {
                t += tab[i];
            }
            return t;
        }
    }

    public class ForwardVersusBackwardWriting {

        private const int n = 500000;


        [Benchmark(Baseline = true)]
        public int[] Forward() {
            int[] tab = new int[n];
            for (int i = 0; i < n; i++) {
                tab[i] = 1;
            }
            return tab;
        }

        [Benchmark]
        public int[] Backward() {
            int[] tab = new int[n];
            for (int i = n - 1; i > -1; i--) {
                tab[i] = 1;
            }
            return tab;
        }
    }

    public class ForwardVersusBackwardReadingAndWriting {

        private const int n = 500000;


        [Benchmark(Baseline = true)]
        public int[] Forward() {
            int[] tab = new int[n];
            for (int i = 0; i < n; i++) {
                tab[i] += 1;
            }
            return tab;
        }

        [Benchmark]
        public int[] Backward() {
            int[] tab = new int[n];
            for (int i = n - 1; i > -1; i--) {
                tab[i] += 1;
            }
            return tab;
        }
    }
}
