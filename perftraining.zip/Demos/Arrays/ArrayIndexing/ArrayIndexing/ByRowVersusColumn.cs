﻿using BenchmarkDotNet.Attributes;

namespace ArrayIndexing {

    public class ByRowVersusColumnReading {

        private const int n = 500;
        private const int m = 500;


        [Benchmark(Baseline = true)]
        public int ByRow() {
            int[,] tab = new int[n, m];
            int t = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    t += tab[i, j];
                }
            }
            return t;
        }

        [Benchmark]
        public int ByColumn() {
            int[,] tab = new int[n, m];
            int t = 0;
            for (int j = 0; j < m; j++) {
                for (int i = 0; i < n; i++) {
                    t += tab[i, j];
                }
            }
            return t;
        }

    }
    public class ByRowVersusColumnWriting {

        private const int n = 500;
        private const int m = 500;


        [Benchmark(Baseline = true)]
        public int[,] ByRow() {
            int[,] tab = new int[n, m];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    tab[i, j] = 1;
                }
            }
            return tab;
        }

        [Benchmark]
        public int[,] ByColumn() {
            int[,] tab = new int[n, m];
            for (int j = 0; j < m; j++) {
                for (int i = 0; i < n; i++) {
                    tab[i, j] = 1;
                }
            }
            return tab;
        }

    }

    public class ByRowVersusColumnReadingAndWriting {

        private const int n = 500;
        private const int m = 500;


        [Benchmark(Baseline = true)]
        public int[,] ByRow() {
            int[,] tab = new int[n, m];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    tab[i, j] = tab[i, j] + 1;
                }
            }
            return tab;
        }

        [Benchmark]
        public int[,] ByColumn() {
            int[,] tab = new int[n, m];
            for (int j = 0; j < m; j++) {
                for (int i = 0; i < n; i++) {
                    tab[i, j] = tab[i, j] + 1;
                }
            }
            return tab;
        }

        [Benchmark()]
        public int[,] ByRowUsingPlusIs() {
            int[,] tab = new int[n, m];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    tab[i, j] += 1;
                }
            }
            return tab;
        }

        [Benchmark]
        public int[,] ByColumnUsingPlusIs() {
            int[,] tab = new int[n, m];
            for (int j = 0; j < m; j++) {
                for (int i = 0; i < n; i++) {
                    tab[i, j] += 1;
                }
            }
            return tab;
        }

    }
}
