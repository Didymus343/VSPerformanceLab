﻿using BenchmarkDotNet.Running;
using System;

namespace ArrayIndexing {
    class Program {
        static void Main(string[] args) {
            //BenchmarkRunner.Run<ForwardVersusBackwardReading>();
            //BenchmarkRunner.Run<ForwardVersusBackwardWriting>();
            //BenchmarkRunner.Run<ForwardVersusBackwardReadingAndWriting>();

            //BenchmarkRunner.Run<ByRowVersusColumnReading>();
            BenchmarkRunner.Run<ByRowVersusColumnWriting>();
            //BenchmarkRunner.Run<ByRowVersusColumnReadingAndWriting>();
        }
    }
}
