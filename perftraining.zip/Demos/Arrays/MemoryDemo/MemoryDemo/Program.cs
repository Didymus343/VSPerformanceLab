﻿using System;
using System.Runtime.InteropServices;

namespace MemoryDemo
{
    class Program {

        private static void Main(string[] args) {
            string source = "span like types are awesome!";

            // source.AsMemory() converts source from string to ReadOnlyMemory<char>,
            // and MemoryMarshal.AsMemory converts ReadOnlyMemory<char> to Memory<char>
            // so you can modify the elements.
            TitleCase(MemoryMarshal.AsMemory(source.AsMemory()));

            // You get "Span like types are awesome!";
            Console.WriteLine(source);
        }

        private static void TitleCase(Memory<char> memory) {
            if (memory.IsEmpty)
                return;
            ref char first = ref memory.Span[0];
            if (first >= 'a' && first <= 'z') {
                first = (char)(first - 32);
            }
        }
    }

}
