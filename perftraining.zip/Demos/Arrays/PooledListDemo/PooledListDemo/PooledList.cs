﻿using System;
using System.Buffers;
using System.Collections;
using System.Collections.Generic;

namespace PooledListDemo {

    public class PooledList<T> : IEnumerable<T>, IDisposable {

        public int Size { get; }

        private readonly ArrayPool<T> _pool;
        private T[] _items;
        public int Count { get; private set; }

        public PooledList(int size) : this(size, ArrayPool<T>.Shared)  {
        }

        public PooledList(int size, ArrayPool<T> pool) {
            this.Size = size;
            this._pool = pool;
            this._items = pool.Rent(this.Size);
        }

        public void Add(T value) {
            if (Count == Size) {
                throw new InvalidOperationException("PooledList is full");
            }
            _items[Count++] = value;
        }

        public T this[int index] {
            get {
                if (index >= Count) {
                    throw new ArgumentOutOfRangeException(nameof(index), "Index was out of range. Must be non-negative and less than the size of the collection.");
                }
                return _items[index];
            }
            set {
                if (index >= Count) {
                    throw new ArgumentOutOfRangeException(nameof(index), "Index was out of range. Must be non-negative and less than the size of the collection.");
                }
                _items[index] = value;
            }
        }

        public void Dispose() => _pool.Return(_items);

        public IEnumerator<T> GetEnumerator() {
            for (int i = 0; i < this.Count; i++) {
                yield return _items[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
