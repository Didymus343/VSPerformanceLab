﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PooledListDemo {
    class Program {
        static void Main(string[] args) {

            using (var l = new PooledList<string>(20)) {
                l.Add("Fons");
                l.Add("Jim");
                l.Add("Ellen");

                l[0] += " Sonnemans";

                foreach (var item in l) {
                    Console.WriteLine(item);
                }

                Console.WriteLine(l.Count);
                Console.WriteLine(l.Size);
            }
        }
    }
}
