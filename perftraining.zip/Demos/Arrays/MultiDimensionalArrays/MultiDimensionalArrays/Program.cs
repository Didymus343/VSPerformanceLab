﻿
using BenchmarkDotNet.Running;

BenchmarkRunner.Run<BM>();

var bm = new BM();
var row = bm.ByRow();
var column = bm.ByColumn();
var jagged = bm.Jagged();
var flattened = bm.Flattened();

Console.WriteLine();