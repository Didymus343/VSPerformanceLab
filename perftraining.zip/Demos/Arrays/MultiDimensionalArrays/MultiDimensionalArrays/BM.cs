﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;

[MemoryDiagnoser(false)]
[HideColumns("Job", "Alloc Ratio", "Ratio SD")]
[ShortRunJob(runtimeMoniker: RuntimeMoniker.Net48)]
[ShortRunJob(runtimeMoniker: RuntimeMoniker.Net80)]
public class BM {

    private const int HEIGHT = 300;
    private const int WIDTH = 600;

    [Benchmark(Baseline = true)]
    public int[,] ByRow() {
        int[,] array = new int[HEIGHT, WIDTH];
        for (int y = 0; y < array.GetLength(0); y++) {
            for (int x = 0; x < array.GetLength(1); x++) {
                array[y, x] = x * y;
            }
        }
        return array;
    }

    [Benchmark]
    public int[,] ByColumn() {
        int[,] array = new int[HEIGHT, WIDTH];
        for (int x = 0; x < array.GetLength(1); x++) {
            for (int y = 0; y < array.GetLength(0); y++) {
                array[y, x] = x * y;
            }
        }
        return array;
    }

    [Benchmark]
    public int[][] Jagged() {
        int[][] array = new int[HEIGHT][];
        for (int y = 0; y < array.Length; y++) {
            var subarray = array[y] = new int[WIDTH];
            for (int x = 0; x < subarray.Length; x++) {
                subarray[x] = x * y;
            }
        }
        return array;
    }

    [Benchmark]
    public int[] Flattened() {
        int[] array = new int[HEIGHT * WIDTH];
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                array[y * WIDTH + x] = x * y;
            }
        }
        return array;
    }
}
