﻿using BenchmarkDotNet.Running;
using System;

namespace StackallocDemo {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<FibonacciSequenceUsingArrayVersusStackalloc>();
        }
    }
}
