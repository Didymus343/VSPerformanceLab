﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Attributes.Jobs;
using BenchmarkDotNet.Running;
using System;

namespace StackallocDemo {
    [MemoryDiagnoser]
    //[LegacyJitX86Job, LegacyJitX64Job, RyuJitX64Job, RyuJitX86Job]
    [RyuJitX64Job]
    public class FibonacciSequenceUsingArrayVersusStackalloc {

        private const int ArraySize = 1000;

        [Benchmark(Baseline = true)]
        public int Array() {
            int[] fib = new int[ArraySize];
            fib[0] = fib[1] = 1; // The sequence begins with 1, 1.
            for (int i = 2; i < ArraySize; ++i) {
                fib[i] = fib[i - 1] + fib[i - 2]; // Sum the previous two numbers.
            }
            return fib[ArraySize - 1];
        }

        [Benchmark()]
        public unsafe int Stackalloc() {
            int* fib = stackalloc int[ArraySize];
            int* p = fib;
            *p++ = *p++ = 1; // The sequence begins with 1, 1.
            for (int i = 2; i < ArraySize; ++i, ++p) {
                *p = p[-1] + p[-2]; // Sum the previous two numbers.
            }
            return fib[ArraySize - 1];
        }

        [Benchmark()]
        public int SpanArray() {
            Span<int> fib = new int[ArraySize];
            fib[0] = fib[1] = 1; // The sequence begins with 1, 1.
            for (int i = 2; i < ArraySize; ++i) {
                fib[i] = fib[i - 1] + fib[i - 2]; // Sum the previous two numbers.
            }
            return fib[ArraySize - 1];
        }

        [Benchmark()]
        public int SpanStackalloc() {
            Span<int> fib = stackalloc int[ArraySize];
            fib[0] = fib[1] = 1; // The sequence begins with 1, 1.
            for (int i = 2; i < ArraySize; ++i) {
                fib[i] = fib[i - 1] + fib[i - 2]; // Sum the previous two numbers.
            }
            return fib[ArraySize - 1];
        }
    }
}
