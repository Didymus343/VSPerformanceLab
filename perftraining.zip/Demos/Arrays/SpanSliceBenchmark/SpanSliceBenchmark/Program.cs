﻿using BenchmarkDotNet.Running;
using System.Collections.Generic;

namespace SpanSliceBenchmark {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<StringSpanTest>();
        }
    }
}