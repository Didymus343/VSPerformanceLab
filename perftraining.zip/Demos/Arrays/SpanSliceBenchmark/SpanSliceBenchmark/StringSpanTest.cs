﻿using BenchmarkDotNet.Attributes;
using Microsoft.Extensions.Primitives;
using System;

namespace SpanSliceBenchmark {

    [MemoryDiagnoser]
    public class StringSpanTest {

        const string Lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent posuere ligula non massa egestas varius. Maecenas id laoreet dui. Sed vestibulum sem eu libero iaculis egestas. Pellentesque sit amet fermentum elit. Nullam hendrerit tortor sit amet turpis dictum, ut cursus urna interdum. Pellentesque nec consectetur dolor, quis dignissim neque. Praesent maximus interdum nulla, sed pellentesque magna consectetur in. Praesent fermentum sagittis felis vitae congue. Mauris sit amet maximus ex. Sed rutrum ut magna eget laoreet. Proin non vulputate orci. Nam rhoncus fringilla nisi a dapibus.";
        const char Space = ' ';

        [Benchmark]
        public bool StringSplit() {
            var a = Lorem.Split(Space);
            bool b = false;
            foreach (var word in a) {
                b = b & IsCSharpIdentifier(word);
            }
            return b;
        }


        [Benchmark]
        public bool StringSubstring() {
            bool b = false;
            int start = 0;
            for (int i = Lorem.IndexOf(Space); i > -1; i = Lorem.IndexOf(Space, start)) {
                var word = Lorem.Substring(start, i - start);
                b = b & IsCSharpIdentifier(word);
                start = i + 1;
            }
            return b;
        }

        [Benchmark(Baseline = true)]
        public bool ReadonlySpanSlice() {
            ReadOnlySpan<char> s = Lorem.AsSpan();
            bool b = false;
            for (int i = s.IndexOf(Space); i > -1; i = s.IndexOf(Space)) {
                var word = s.Slice(0, i);
                b = b & IsCSharpIdentifier(word);
                s = s.Slice(i + 1);
            }
            return b;
        }

        [Benchmark]
        public bool StringTokenizerAndStringSegment() {
            StringTokenizer st = new StringTokenizer(Lorem, new char[] { Space });
            bool b = false;
            foreach (var segment in st) {
                b = b & IsCSharpIdentifier(segment);
            }
            return b;
        }

        static bool IsCSharpIdentifier(string value) {
            if (value.Length == 0) {
                return false;
            }
            if (char.IsNumber(value[0])) {
                return false;
            }
            for (var i = 0; i < value.Length; i++) {
                char c = value[i];
                if (!(char.IsLetterOrDigit(c) || c == '_')) {
                    return false;
                }
            }
            return true;
        }

        static bool IsCSharpIdentifier(ReadOnlySpan<char> value) {
            if (value.Length == 0) {
                return false;
            }
            if (char.IsNumber(value[0])) {
                return false;
            }
            for (var i = 0; i < value.Length; i++) {
                char c = value[i];
                if (!(char.IsLetterOrDigit(c) || c == '_')) {
                    return false;
                }
            }
            return true;
        }

        static bool IsCSharpIdentifier(StringSegment value) {
            if (value.Length == 0) {
                return false;
            }
            if (char.IsNumber(value[0])) {
                return false;
            }
            for (var i = 0; i < value.Length; i++) {
                char c = value[i];
                if (!(char.IsLetterOrDigit(c) || c == '_')) {
                    return false;
                }
            }
            return true;
        }
    }


}