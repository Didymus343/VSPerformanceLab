using System;
using System.Linq;
using Xunit;

namespace SpanLinq.Test {
    public class UnitTest1 {

        [Fact]
        public void TestSumInt() {
            var a = new[] { 3, 15, 43, 124, 55 };

            Span<int> s = a;

            Assert.Equal(a.Sum(), s.Sum());
        }

        [Fact]
        public void TestSumLong() {
            var a = new[] { 3L, 15L, 43L, 124L, 55L };

            Span<long> s = a;

            Assert.Equal(a.Sum(), s.Sum());
        }
    }
}
