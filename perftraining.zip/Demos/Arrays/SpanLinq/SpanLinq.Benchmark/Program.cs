﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Linq;
using System.Runtime.CompilerServices;

namespace SpanLinq.Benchmark {
    internal class Program {
        private static void Main(string[] args) {
            BenchmarkRunner.Run<Test>();
        }
    }

    public class Test {

        private const int Iterations = 1000;
        private int[] a = new[] { 3, 15, 43, 124, 55, 77, 323, 4523, 5435, 12167, 131,
                                  32, 4343, 5, 1231, 343, 1234, 42334, 12524, 865656 };

        [Benchmark]
        public int Array() {
            int t = 0;
            for (int i = 0; i < Iterations; i++) {
                t += Sum(a);
            }
            return t;
        }

        [Benchmark(Baseline = true)]
        public int Span() {
            Span<int> s = a;
            int t = 0;
            for (int i = 0; i < Iterations; i++) {
                t += Sum(s);
            }
            return t;
        }

        [Benchmark()]
        public int SpanWithBoundCheck() {
            Span<int> s = a;
            int t = 0;
            for (int i = 0; i < Iterations; i++) {
                t += SumWithBoundCheck(s, 0, s.Length);
            }
            return t;
        }

        [Benchmark()]
        public int SpanForEach() {
            Span<int> s = a;
            int t = 0;
            for (int i = 0; i < Iterations; i++) {
                t += SumForEach(s);
            }
            return t;
        }
    
        [MethodImpl(methodImplOptions: MethodImplOptions.NoInlining)]
        public static int Sum(int[] array) {
            int sum = 0;
            for (var i = 0; i < array.Length; i++) {
                sum += array[i]; // <-- bounds check 
            }
            return sum;
        }

        [MethodImpl(methodImplOptions: MethodImplOptions.NoInlining)]
        public static int Sum(Span<int> span) {
            int sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i]; // <-- bounds check here removed
            }
            return sum;
        }

        [MethodImpl(methodImplOptions: MethodImplOptions.NoInlining)]
        public static int SumWithBoundCheck(Span<int> span, int start, int length) {
            int sum = 0;
            for (var i = start; i < length; i++) {
                sum += span[i]; // <-- bounds check 
            }
            return sum;
        }

        [MethodImpl(methodImplOptions: MethodImplOptions.NoInlining)]
        public static int SumForEach(Span<int> span) {
            int sum = 0;
            foreach (var item in span) {
                sum += item;
            }
            return sum;
        }
    }

}
