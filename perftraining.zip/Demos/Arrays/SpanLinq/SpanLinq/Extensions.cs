﻿using System;
using System.Runtime.CompilerServices;

namespace SpanLinq {

    public static class Extensions {

        public static int Sum(this int[] array) {
            int sum = 0;
            for (var i = 0; i < array.Length; i++) {
                sum += array[i]; // <-- bounds check 
            }
            return sum;
        }

        public static int Sum(this Span<int> span) {
            int sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i]; // <-- bounds check here removed
            }
            return sum;
        }

        public static int SumForEach(this Span<int> span) {
            int sum = 0;
            foreach (var item in span) {
                sum += item;
            }
            return sum;
        }

        public static long Sum(this Span<long> span) {
            long sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static double Sum(this Span<double> span) {
            double sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static float Sum(this Span<float> span) {
            float sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static decimal Sum(this Span<decimal> span) {
            decimal sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static int Sum(this ReadOnlySpan<int> span) {
            int sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i]; // <-- bounds check here removed
            }
            return sum;
        }

        public static long Sum(this ReadOnlySpan<long> span) {
            long sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static double Sum(this ReadOnlySpan<double> span) {
            double sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static float Sum(this ReadOnlySpan<float> span) {
            float sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

        public static decimal Sum(this ReadOnlySpan<decimal> span) {
            decimal sum = 0;
            for (var i = 0; i < span.Length; i++) {
                sum += span[i];
            }
            return sum;
        }

    }
}
