﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MemoryMarshalDemo {
    class Program {

        public const string Filename = @"D:\data.dat";

        static void Main(string[] args) {
            Write();

            BenchmarkRunner.Run<BM>();

            //Console.WriteLine(new BM().ReadAll());
            //Console.WriteLine(new BM().ReadOneByOne());
            //Console.WriteLine(new BM().ReadBlocksOf100());
        }

        private static void Write() {
            Data[] a = new Data[100_000];
            for (int i = 0; i < a.Length; i++) {
                ref var item = ref a[i];
                item.A = i;
                item.B = -i;
                item.C = item.A * item.B * 1.5;
            }

            var byteSpan = MemoryMarshal.Cast<Data, byte>(a);

            using (var fs = new FileStream(Program.Filename, FileMode.OpenOrCreate)) {
                fs.Write(byteSpan);
            }
        }
    }

    [MemoryDiagnoser()]
    public class BM {

        [Benchmark]
        public long ReadAll() {
            var bytes = File.ReadAllBytes(Program.Filename);
            var dataSpan = MemoryMarshal.Cast<byte, Data>(bytes);
            long total = 0;
            foreach (var data in dataSpan) total += data.A;
            return total;
        }

        [Benchmark]
        public long ReadOneByOne() {
            long total = 0;
            using (var fs = new FileStream(Program.Filename, FileMode.Open)) {
                using (var sr = new BinaryReader(fs)) {
                    var v = fs.Length / 16;
                    for (int i = 0; i < v; i++) {
                        var bytes = sr.ReadBytes(16);
                        var data = MemoryMarshal.Read<Data>(bytes);
                        total += data.A;
                    }
                }
            }
            return total;
        }

        [Benchmark]
        public long ReadBlocksOf100() {
            long total = 0;
            using (var fs = new FileStream(Program.Filename, FileMode.Open)) {
                var size = Unsafe.SizeOf<Data>();
                Span<byte> a = stackalloc byte[size * 100];
                int bytesRead;
                while ((bytesRead = fs.Read(a)) > 0) {
                    var dataSpan = MemoryMarshal.Cast<byte, Data>(a);
                    foreach (var data in dataSpan) total += data.A;
                }
            }
            return total;
        }

    }

    struct Data {

        public int A;
        public int B;
        public double C;

        public override string ToString() {
            return $"A={A.ToString()} B={B.ToString()} C={C.ToString()}";
        }
    }

}

