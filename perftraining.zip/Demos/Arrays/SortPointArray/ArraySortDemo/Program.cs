﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace SortPointArray {
    internal class Program {
        static void Main(string[] args) {

            var a = new PointStruct[1_000_000];
            for (int i = 0, j = a.Length; i < a.Length; i++, j--) {
                a[i] = new PointStruct(i, j);
            }

            var sw = System.Diagnostics.Stopwatch.StartNew();

            //Array.Sort(a, (l, r) => l.Dist.CompareTo(r.Dist));
            //a = a.OrderBy(p => p.Dist).ToArray();

            ArraySorter.SortBy(a, static p => p.Dist);
            //ArraySorter.SortBy(a, p => p.Dist, new PointDistComparer());
            //ArraySorter.SortBy(a, p => p.Dist, static (l, r) => l.Value.CompareTo(r.Value));

            sw.Stop();
            Console.WriteLine(sw.Elapsed.ToString());

            foreach (var item in a.Take(10)) {
                Console.WriteLine(item.ToString());
            }
        }
    }

    class PointDistComparer : IComparer<(PointStruct Item, double Value)> {
        public int Compare((PointStruct Item, double Value) x, (PointStruct Item, double Value) y) {
            return x.Value.CompareTo(y.Value);
        }
    }

    static class ArraySorter {

        public static void SortBy<TItem, TValue>(TItem[] array, Func<TItem, TValue> slowKeySelector, Comparison<(TItem Item, TValue Value)> comparison) {
            var tuples = CreateTuples(array, slowKeySelector);
            Array.Sort(tuples, comparison);
            Sync(array, tuples);
        }

        public static void SortBy<TItem, TValue>(TItem[] array, Func<TItem, TValue> slowKeySelector, IComparer<(TItem Item, TValue Value)> comparer) {
            var tuples = CreateTuples(array, slowKeySelector);
            Array.Sort(tuples, comparer);
            Sync(array, tuples);
        }

        public static void SortBy<TItem, TValue>(TItem[] array, Func<TItem, TValue> slowKeySelector) where TValue : IComparable<TValue> {
            var tuples = CreateTuples(array, slowKeySelector);
            Array.Sort(tuples, static (x, y) => x.Value.CompareTo(y.Value));
            Sync(array, tuples);
        }

        private static (TItem Item, TValue Value)[] CreateTuples<TItem, TValue>(TItem[] array, Func<TItem, TValue> slowKeySelector) {
            var tuples = new (TItem Item, TValue Value)[array.Length];
            for (int i = 0; i < array.Length; i++) {
                tuples[i] = (array[i], slowKeySelector(array[i]));
            }
            return tuples;
        }

        private static void Sync<TItem, TValue>(TItem[] array, (TItem Item, TValue Value)[] tuples) {
            for (int i = 0; i < tuples.Length; i++) {
                array[i] = tuples[i].Item;
            }
        }

    }

    readonly struct PointStruct {

        public readonly long X;
        public readonly long Y;

        public PointStruct(long x, long y) {
            X = x;
            Y = y;
        }

        public double Dist => Math.Sqrt(X * X + Y * Y);

        public override string ToString() => $"({X},{Y}) {Dist}";
    }

}
