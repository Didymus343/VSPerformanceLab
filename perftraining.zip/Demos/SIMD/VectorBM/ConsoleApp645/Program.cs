﻿using System;
using System.Numerics;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

var summary = BenchmarkRunner.Run<BM>();
//var result1 = BM.AddArrays_Simple(BM.V1, BM.V2);
//var result2 = BM.AddArrays_Vector(BM.V1, BM.V2);
//foreach (var item in result1.Zip(result2)) {
//    Console.WriteLine($"{item.First}\t{item.Second}");
//}

public class BM {

    [Benchmark]
    public double[] AddArrays_Simple_Benchmark() => AddArrays_Simple(V1, V2);

    [Benchmark]
    public double[] AddArrays_Vector_Benchmark() => AddArrays_Vector(V1, V2);

    public static double[] AddArrays_Simple(double[] v1, double[] v2) {
        double[] retVal = new double[v1.Length];

        for (int i = 0; i < v1.Length; i++) {
            retVal[i] = v1[i] + v2[i];
        }

        return retVal;
    }

    public static double[] AddArrays_Vector(double[] v1, double[] v2) {
        double[] retVal = new double[v1.Length];
        var vectSize = Vector<double>.Count;

        int i = 0;
        for (i = 0; i < v1.Length - vectSize; i += vectSize) {
            var va = new Vector<double>(v1, i);
            var vb = new Vector<double>(v2, i);
            var vc = va + vb;
            vc.CopyTo(retVal, i);
        }

        if (i != v1.Length) {
            // Do the rest without vectors
            for (int j = i; j < v1.Length; j++) {
                retVal[j] = v1[j] + v2[j];
            }
        }

        return retVal;
    }
    
   
    public readonly static double[] V1 = new double[] { 1, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 86, 45, 65, 74, 27, 33, 55, 45, 63, 72, 47, 33, 36, 45, 65, 82, 27, 33, 85, 15, 63, 72, 47, 33, 96, 45, 63, 72, 17, };
    public readonly static double[] V2 = new double[] { 1, 33, 65, 45, 63, 72, 57, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 37, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 12, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 86, 45, 75, 74, 27, 33, 55, 45, 63, 72, 47, 33, 36, 45, 65, 82, 27, 13, 85, 15, 63, 72, 47, 93, 96, 15, 63, 52, 17, };
}
