﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Linq;
using System.Numerics;
using System.Runtime.Intrinsics;
using System.Runtime.Intrinsics.X86;

namespace VectorBenchmark {
    class Program {
        static void Main(string[] args) {
            //BenchmarkRunner.Run<BenchmarkAdd>();
            BenchmarkRunner.Run<BenchmarkDot>();

            //var bm = new BenchmarkAdd();
            //Array.ForEach(bm.Normal(), Console.WriteLine);
            //Console.WriteLine();
            //Array.ForEach(bm.Simd(), Console.WriteLine);
            //Console.WriteLine();
            //Array.ForEach(bm.Sse2(), Console.WriteLine);
            //Console.WriteLine();
        }

        public static unsafe int[] Sse2Add(int[] lhs, int[] rhs) {
            if (!Sse2.IsSupported) //no SSE41 support 
                return VectorsAdd(lhs, rhs);

            var simdLength = Vector128<int>.Count;
            var result = new int[lhs.Length];
            fixed (int* ptr_a = lhs, ptr_b = rhs, ptr_res = result) {
                var i = 0;
                for (i = 0; i <= lhs.Length - simdLength; i += simdLength) {
                    Vector128<int> v1 = Sse2.LoadVector128(ptr_a + i);
                    Vector128<int> v2 = Sse2.LoadVector128(ptr_b + i);
                    Vector128<int> res = Sse2.Add(v1, v2);
                    Sse2.Store(ptr_res + i, res);
                }

                // the input array lengths may not be a multiple of Vector<T>.Count, 
                // and so there is a second loop to sum any remaining elements.
                for (; i < lhs.Length; ++i) {
                    result[i] = lhs[i] + rhs[i];
                }
            }
            return result;
        }

        public static int[] VectorsAdd(int[] lhs, int[] rhs) {
            var simdLength = Vector<int>.Count;
            var result = new int[lhs.Length];
            var i = 0;
            for (i = 0; i <= lhs.Length - simdLength; i += simdLength) {
                var va = new Vector<int>(lhs, i);
                var vb = new Vector<int>(rhs, i);
                (va + vb).CopyTo(result, i);
            }
            // the input array lengths may not be a multiple of Vector<T>.Count, 
            // and so there is a second loop to sum any remaining elements.
            for (; i < lhs.Length; ++i) {
                result[i] = lhs[i] + rhs[i];
            }
            return result;
        }
    }

    [MemoryDiagnoser]
    public class BenchmarkDot {

        private readonly int[] _a = new[] { 1, 234232, 3, 23424, 5, 6, 7, 8, 9, 10, 11, 12 };
        private readonly int[] _b = new[] { 12, 2, 3, 4, 5, 4546, 7, 234348, 9, 10, 11, 1234322 };

        [Benchmark]
        public int Normal() => _a.Zip(_b, (a, b) => a * b).Sum();

        [Benchmark(Baseline = true)]
        public int Simd() => Vector.Dot(new Vector<int>(_a), new Vector<int>(_b));

    }

    public class BenchmarkAdd {

        private readonly int[] _a = new[] { 1, 234232, 3, 23424, 5, 6, 7, 8, 9, 10, 11, 12 };
        private readonly int[] _b = new[] { 12, 2, 3, 4, 5, 4546, 7, 234348, 9, 10, 11, 1234322 };

        [Benchmark]
        public int[] Normal() {
            int[] result = new int[_a.Length];
            for (int i = 0; i < _a.Length; i++) result[i] = _a[i] + _b[i];
            return result;
        }

        [Benchmark(Baseline = true)]
        public int[] Vectors() => Program.VectorsAdd(_a, _b);

        [Benchmark]
        public int[] Sse2() => Program.Sse2Add(_a, _b);

    }
}
