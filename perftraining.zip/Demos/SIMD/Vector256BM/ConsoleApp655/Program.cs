﻿using System.Numerics;
using System.Runtime.Intrinsics;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

#if RELEASE
var summary = BenchmarkRunner.Run<BM>();
#else
var result1 = BM.AddArrays_Simple(BM.V1, BM.V2);
//var result2 = BM.AddArrays_Vector(BM.V1, BM.V2);
//var result2 = BM.AddArrays_Vector256(BM.V1, BM.V2);
var result2 = BM.AddArrays_Vector256_Unsafe(BM.V1, BM.V2);
foreach (var item in result1.Zip(result2)) {
    Console.WriteLine($"{item.First}\t{item.Second}");
}
#endif

[ShortRunJob, MemoryDiagnoser]
public class BM {

    [Benchmark]
    public double[] AddArrays_SimpleBM() => AddArrays_Simple(V1, V2);

    [Benchmark]
    public double[] AddArrays_VectorBM() => AddArrays_Vector(V1, V2);

    [Benchmark]
    public double[] AddArrays_Vector256BM() => AddArrays_Vector256(V1, V2);

    [Benchmark]
    public double[] AddArrays_Vector256BMUnsafe() => AddArrays_Vector256_Unsafe(V1, V2);

    public static unsafe double[] AddArrays_Vector256(double[] v1, double[] v2) {
        var simdLength = Vector256<double>.Count;
        var result = new double[v1.Length];
        fixed (double* ptr_a = v1, ptr_b = v2, ptr_res = result) {
            var i = 0;
            for (i = 0; i <= v1.Length - simdLength; i += simdLength) {
                Vector256<double> lv1 = Vector256.Load<double>(ptr_a + i);
                Vector256<double> lv2 = Vector256.Load<double>(ptr_b + i);
                Vector256<double> res = Vector256.Add(lv1, lv2);
                Vector256.Store(res, ptr_res + i);
            }

            // the input array lengths may not be a multiple of Vector<T>.Count, 
            // and so there is a second loop to sum any remaining elements.
            for (; i < v1.Length; ++i) result[i] = v1[i] + v2[i];
        }
        return result;
    }

    public static double[] AddArrays_Vector256_Unsafe(double[] v1, double[] v2) {
        var simdLength = Vector256<double>.Count;
        var result = new double[v1.Length];
        var i = 0;
        for (i = 0; i <= v1.Length - simdLength; i += simdLength) {
            Vector256<double> lv1 = Vector256.LoadUnsafe<double>(ref v1[0], (nuint)i);
            Vector256<double> lv2 = Vector256.LoadUnsafe<double>(ref v2[0], (nuint)i);
            Vector256<double> res = Vector256.Add(lv1, lv2);
            Vector256.StoreUnsafe(res, ref result[i]);
        }

        // the input array lengths may not be a multiple of Vector<T>.Count, 
        // and so there is a second loop to sum any remaining elements.
        for (; i < v1.Length; ++i) result[i] = v1[i] + v2[i];
        return result;
    }

    public static double[] AddArrays_Vector(double[] v1, double[] v2) {
        double[] retVal = new double[v1.Length];
        var vectSize = Vector<double>.Count;

        int i = 0;
        for (i = 0; i < v1.Length - vectSize; i += vectSize) {
            var va = new Vector<double>(v1, i);
            var vb = new Vector<double>(v2, i);
            var vc = va + vb;
            vc.CopyTo(retVal, i);
        }

        if (i != v1.Length) {
            // Do the rest without vectors
            for (int j = i; j < v1.Length; j++) {
                retVal[j] = v1[j] + v2[j];
            }
        }

        return retVal;
    }

    public static double[] AddArrays_Simple(double[] v1, double[] v2) {
        double[] retVal = new double[v1.Length];

        for (int i = 0; i < v1.Length; i++) {
            retVal[i] = v1[i] + v2[i];
        }

        return retVal;
    }

    public readonly static double[] V1 = new double[] { 1, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 86, 45, 65, 74, 27, 33, 55, 45, 63, 72, 47, 33, 36, 45, 65, 82, 27, 33, 85, 15, 63, 72, 47, 33, 96, 45, 63, 72, 17, };
    public readonly static double[] V2 = new double[] { 1, 33, 65, 45, 63, 72, 57, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 37, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 12, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 36, 45, 65, 72, 27, 33, 35, 45, 63, 72, 47, 33, 86, 45, 75, 74, 27, 33, 55, 45, 63, 72, 47, 33, 36, 45, 65, 82, 27, 13, 85, 15, 63, 72, 47, 93, 96, 15, 63, 52, 17, };
}

