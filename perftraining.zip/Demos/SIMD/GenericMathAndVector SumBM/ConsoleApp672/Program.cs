﻿using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;

BenchmarkRunner.Run<BM>();

[HideColumns("Job", "Error", "StdDev", "Median", "RatioSD",
             "Alloc Ratio")]
[MemoryDiagnoser(displayGenColumns: false)]
[SimpleJob(RuntimeMoniker.Net60)]
[SimpleJob(RuntimeMoniker.Net70, baseline: true)]
[GroupBenchmarksBy(BenchmarkLogicalGroupRule.ByMethod)]
public class BM {

    private readonly int[] _numbers = Enumerable.Range(1, 1000).ToArray();

    [Benchmark]
    public int Sum() => _numbers.Sum();

    [Benchmark]
    public int SumLinq() => System.Linq.Enumerable.Sum(_numbers);

}

#if NET7_0_OR_GREATER
public static class Extensions {
    public static T Sum<T>(this IEnumerable<T> source)
        where T : struct, IAdditionOperators<T, T, T>, IAdditiveIdentity<T, T> {
        if (source.GetType() == typeof(T[]))
            return Sum(Unsafe.As<T[]>(source));

        if (source.GetType() == typeof(List<T>))
            return Sum<T>(CollectionsMarshal.AsSpan(Unsafe.As<List<T>>(source)));

        var sum = T.AdditiveIdentity;
        foreach (var value in source) {
            checked { sum += value; }
        }
        return sum;
    }

    public static T Sum<T>(this T[] source)
        where T : struct, IAdditionOperators<T, T, T>, IAdditiveIdentity<T, T>
        => Sum<T>(source.AsSpan());

    public static T Sum<T>(this ReadOnlySpan<T> source)
        where T : struct, IAdditionOperators<T, T, T>, IAdditiveIdentity<T, T> {
        var sum = T.AdditiveIdentity;
        if (Vector.IsHardwareAccelerated && Vector<T>.IsSupported && source.Length > Vector<T>.Count) {
            var vectors = MemoryMarshal.Cast<T, Vector<T>>(source);

            var sumVector = Vector<T>.Zero;
            foreach (ref readonly var vector in vectors)
                sumVector += vector;

            sum = Vector.Sum(sumVector);
            var remainder = source.Length % Vector<T>.Count;
            source = source[^remainder..];
        }
        foreach (ref readonly var value in source) {
            checked { sum += value; }
        }
        return sum;
    }
}

#endif