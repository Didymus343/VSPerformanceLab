﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Runtime.CompilerServices;

namespace InliningOperatorOverloading {

    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    public class BM {

        [Benchmark(Baseline = true)]
        public VecWithFields TestVecWithFields() {
            var p = new VecWithFields(12f, 5f, 1.5f);
            var r = new VecWithFields();
            for (int i = 0; i < 100000; i++) {
                r = p + r;
                //r = p * r;
            }
            return r;
        }

        [Benchmark]
        public VecWithProperties TestVecWithProperties() {
            var p = new VecWithProperties(12f, 5f, 1.5f);
            var r = new VecWithProperties(); ;
            for (int i = 0; i < 100000; i++) {
                r = p + r;
                //r = p * r;
            }
            return r;
        }

        //[Benchmark]
        //public VecWithProperties TestVecWithPropertiesNoOperator() {
        //    var p = new VecWithProperties(12f, 5f, 1.5f);
        //    var r = new VecWithProperties(); ;
        //    for (int i = 0; i < 100000; i++) {
        //        r = new VecWithProperties(p.X + r.X, p.Y + r.Y, p.Z + r.Z);

        //        //r = p * r;
        //        //r = new VecWithProperties(p.X * r.X, p.Y * r.Y, p.Z * r.Z);
        //    }
        //    return r;
        //}

        [Benchmark]
        public VecWithPropertiesAndAggressiveInlining TestVecWithPropertiesAndAggressiveInlining() {
            var p = new VecWithPropertiesAndAggressiveInlining(12f, 5f, 1.5f);
            var r = new VecWithPropertiesAndAggressiveInlining(); ;
            for (int i = 0; i < 100000; i++) {
                r = p + r;

                //r = p * r;
                //r = new VecWithProperties(p.X * r.X, p.Y * r.Y, p.Z * r.Z);
            }
            return r;
        }
    }

    public struct VecWithFields {
        public float X;
        public float Y;
        public float Z;

        public VecWithFields(float x, float y, float z) {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public static VecWithFields operator *(VecWithFields q, VecWithFields r) {
            return new VecWithFields(q.X * r.X, q.Y * r.Y, q.Z * r.Z);
        }

        public static VecWithFields operator +(VecWithFields q, VecWithFields r) {
            return new VecWithFields(q.X + r.X, q.Y + r.Y, q.Z + r.Z);
        }
    }


    public struct VecWithProperties {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public VecWithProperties(float x, float y, float z) {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public static VecWithProperties operator *(VecWithProperties q, VecWithProperties r) {
            return new VecWithProperties(q.X * r.X, q.Y * r.Y, q.Z * r.Z);
        }

        public static VecWithProperties operator +(VecWithProperties q, VecWithProperties r) {
            return new VecWithProperties(q.X + r.X, q.Y + r.Y, q.Z + r.Z);
        }

    }

    public struct VecWithPropertiesAndAggressiveInlining {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public VecWithPropertiesAndAggressiveInlining(float x, float y, float z) {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static VecWithPropertiesAndAggressiveInlining operator *(VecWithPropertiesAndAggressiveInlining q, VecWithPropertiesAndAggressiveInlining r) {
            return new VecWithPropertiesAndAggressiveInlining(q.X * r.X, q.Y * r.Y, q.Z * r.Z);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static VecWithPropertiesAndAggressiveInlining operator +(VecWithPropertiesAndAggressiveInlining q, VecWithPropertiesAndAggressiveInlining r) {
            return new VecWithPropertiesAndAggressiveInlining(q.X + r.X, q.Y + r.Y, q.Z + r.Z);
        }

    }

}

