﻿using System.Diagnostics;

int t = 10_000_000;
if (args.Length > 0 && int.TryParse(args[0], out int v)) {
    t = v;
}

var sw = System.Diagnostics.Stopwatch.StartNew();
int c = 0;
for (int i = 0; i < t; i++) {
    if (IsPrime(i)) {
        c++;
    }
}
sw.Stop();
Console.WriteLine($"{t}: {c} Primes in {sw.Elapsed}");
Console.ReadKey();

bool IsPrime(int n) {
    if (n <= 1) {
        return false;
    }
    if (n <= 3) {
        return true;
    }
    if (n % 2 == 0 || n % 3 == 0) {
        return false;
    }

    //var sqrt = (int)Math.Sqrt(n);
    //for (int i = 5; i <= sqrt; i = i + 6) {

    for (int i = 5; i * i <= n; i = i + 6) {
        if (n % i == 0 || n % (i + 2) == 0) {
            return false;
        }
    }

    return true;
}


