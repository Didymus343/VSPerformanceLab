﻿using System;
using System.Diagnostics;
using System.Threading;

namespace BranchPredictionAndElimination {
    public static class PerformanceUtils {

        public static void Measure(Action fp, int times = 10) {
            Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
            Thread.CurrentThread.Priority = ThreadPriority.Highest;

            Console.WriteLine(" WarmUp... ");
            for (int i = 0; i < 4; i++) {
                fp.Invoke();
            }

            Console.WriteLine(" Running... ");
            var sw = new Stopwatch(); var total = 0L;
            for (int i = 0; i < times; i++) {
                sw.Restart();
                fp.Invoke();
                sw.Stop();
                total += sw.ElapsedMilliseconds;
                Console.WriteLine($" [{i.ToString()}] Took: {sw.ElapsedMilliseconds.ToString("N0")} ms");
            }
            Console.WriteLine($" Average:  {(total / times).ToString("N0")} ms");
        }
    }

}
