﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace BranchPredictionAndElimination {

    // https://www.youtube.com/watch?v=gO3t9kauCwg
    class Program {
        static void Main(string[] args) {
            var l = new List<int>(20_000);
            for (int i = 0; i < l.Capacity; i++) {
                l.Add(i % 20);
            }

            //var rnd = new Random(2000);
            //for (int i = 0; i < l.Count; i++) {
            //    var idx = rnd.Next(0, l.Count);
            //    (l[i], l[idx]) = (l[idx], l[i]);
            //}

            PerformanceUtils.Measure(() => {
                for (int i = 0; i < 1_000; i++) {
                    //CountOdd_Linq(l);
                    CountOdd(l);
                    //CountOddNoBrach(l);
                    //CountOdd_CustomLinq1(l);
                    //CountOdd_CustomLinq2(l);
                }
            });

        }





        private static int CountOdd_Linq(List<int> l) {
            return l.Count(number => (number & 1) == 1);
        }

        private static int CountOdd(List<int> l) {
            var total = 0;
            for (int i = 0; i < l.Count; i++) {
                //if ((i & 1) == 1) {
                if (i % 2 != 0) {
                    checked {
                        total++;
                    }
                }
            }
            return total;
        }

        private static int CountOddNoBrach(List<int> l) {
            var total = 0;
            for (int i = 0; i < l.Count; i++) {
                checked {
                    total += l[i] & 1;
                }
            }
            return total;
        }

        private static int CountOdd_CustomLinq1(List<int> l) {
            return l.CountCustom1(number => (number & 1) == 1);
        }

        private static int CountOdd_CustomLinq2(List<int> l) {
            return l.CountCustom1(number => (number & 1) == 1);
        }
    }

    static class LinqExtensions {

        public static unsafe int CountCustom1<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate) {
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (predicate is null) throw new ArgumentNullException(nameof(predicate));

            int total = 0;
            foreach (var item in source) {
                var result = predicate(item);
                var value = *(int*)&result;
                checked {
                    total += value;
                }
            }
            return total;
        }

        public static int CountCustom2<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate) {
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (predicate is null) throw new ArgumentNullException(nameof(predicate));

            int total = 0;
            foreach (var item in source) {
                var result = predicate(item);
                var value = Unsafe.As<bool, int>(ref result);
                checked {
                    total += value;
                }
            }
            return total;
        }

    }
}
