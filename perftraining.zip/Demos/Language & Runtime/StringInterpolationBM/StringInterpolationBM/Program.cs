﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

BenchmarkRunner.Run<BM>();

//Console.WriteLine(new BM().GetVersion());

[SimpleJob(BenchmarkDotNet.Jobs.RuntimeMoniker.Net60, baseline: true)]
[SimpleJob(BenchmarkDotNet.Jobs.RuntimeMoniker.Net50)]
[SimpleJob(BenchmarkDotNet.Jobs.RuntimeMoniker.Net48)]
[MemoryDiagnoser(false)]
[HideColumns("Job", "Median", "RatioSD", "Alloc Ratio")]
public class BM {


    [Benchmark]
    public string GetVersion() => FormatVersion(1, 2, 3, 255);

    public static string FormatVersion(int major, int minor, int build, int revision) =>
#if NET6_0_OR_GREATER
           $"{major:X}.{minor:X}.{build:X}.{revision:X}";
#else
#pragma warning disable IDE0071 // Simplify interpolation
            $"{major.ToString("X")}.{minor.ToString("X")}.{build.ToString("X")}.{revision.ToString("X")}";
#pragma warning restore IDE0071 // Simplify interpolation
#endif


}