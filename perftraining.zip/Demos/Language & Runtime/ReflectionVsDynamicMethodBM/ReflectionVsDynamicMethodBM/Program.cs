﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Reflection;
using System.Reflection.Emit;

namespace ReflectionVsDynamicMethodBM {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }


    [MemoryDiagnoser]
    public class BM {

        [Benchmark]
        public double Reflection() {
            var fons = new Employee("Fons", 2000);

            var t = fons.GetType();
            var pi = t.GetProperty("Salary");

            double d = 0;
            for (int i = 0; i < 10_000; i++) {
                d = (double)pi.GetValue(fons);
            }
            return d;
        }

        [Benchmark(Baseline = true)]
        public double DynMethod() {
            Employee fons = new Employee("Fons", 2000);

            var t = fons.GetType();
            var pi = t.GetProperty("Salary");
            var getter = pi.GetGetMethod();

            var dm = new DynamicMethod("GetValue", typeof(object), new Type[] { typeof(object) }, typeof(object), true);
            var lgen = dm.GetILGenerator();

            lgen.Emit(OpCodes.Ldarg_0);
            lgen.Emit(OpCodes.Call, getter);

            if (getter.ReturnType.GetTypeInfo().IsValueType) {
                lgen.Emit(OpCodes.Box, getter.ReturnType);
            }
            lgen.Emit(OpCodes.Ret);

            var fp = dm.CreateDelegate(typeof(PropertyGetDelegate)) as PropertyGetDelegate;

            double d = 0;
            for (int i = 0; i < 10_000; i++) {
                d = (double)fp(fons);
            }
            return d;
        }
    }

    public delegate object PropertyGetDelegate(object obj);

    public class Employee {
        public Employee(string name, double salary) {
            this.Name = name;
            this.Salary = salary;
        }

        public string Name { get; set; }

        public void RaiseSalary(double percentage) {
            this.Salary += Salary * (percentage / 100);
        }

        public double Salary { get; set; }

        public override string ToString() {
            return string.Format("Employee Name = {0}, Salary = {1}", this.Name, this.Salary);
        }
    }

}
