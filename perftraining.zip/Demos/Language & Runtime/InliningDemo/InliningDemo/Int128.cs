﻿
#if !NET7_0_OR_GREATER

/// <summary>
/// Fake Int128
/// </summary>
readonly struct Int128 {

    public readonly long Value1;
    public readonly long Value2;

    public Int128(long value) {
        Value1 = value;
        Value2 = value; // this is incorrect
    }

    public static Int128 operator +(Int128 a, Int128 b) => new Int128(a.Value1 + b.Value1);
    public static Int128 operator +(Int128 a, int b) => new Int128(a.Value1 + b);

    public static implicit operator Int128(long value) => new Int128(value);
}

#endif


