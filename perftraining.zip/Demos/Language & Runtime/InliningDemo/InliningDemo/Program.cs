﻿using System;
using System.Runtime.CompilerServices;

internal class Program {
    static void Main() {

        PerformanceUtils.Measure(() => {
            Int128 a = 5;
            Int128 b = 7;
            Int128 c;

            for (int i = 0; i < 10_000_000; i++) {
                c = Foo(a, b);
            }
        });
    }

    //[MethodImpl(MethodImplOptions.AggressiveInlining)]
    [MethodImpl(MethodImplOptions.NoInlining)]
    private static Int128 Foo(Int128 a, Int128 b) {
        return a + b + 2;
    }
}