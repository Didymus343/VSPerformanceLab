﻿public static class PerformanceUtils {

    public static void Measure(Action fp, int times = 10, int repeats = 1, int warmups = 4) {
        System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.High;
        System.Threading.Thread.CurrentThread.Priority = System.Threading.ThreadPriority.Highest;

        Console.WriteLine(" Warmup... ");
        for (int i = 0; i < warmups; i++) {
            fp.Invoke();
        }
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();

        Console.WriteLine(" Running... ");
        var sw = new System.Diagnostics.Stopwatch();
        var total = 0L;
        for (int i = 0; i < times; i++) {
            sw.Restart();
            for (int j = 0; j < repeats; j++) {
                fp.Invoke();
            }
            sw.Stop(); //x
            total += sw.ElapsedMilliseconds;
            Console.WriteLine($" [{i}] Took:\t{sw.ElapsedMilliseconds:N0} ms");
        }
        Console.WriteLine($" Average:\t{total / times:N0} ms");
    }
}


