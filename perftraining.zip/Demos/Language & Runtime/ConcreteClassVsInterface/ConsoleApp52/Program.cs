﻿using BenchmarkDotNet.Running;
using System;

namespace ConsoleApp52 {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<ListBM>();
            //BenchmarkRunner.Run<DictionaryBM>();
            //BenchmarkRunner.Run<EmployeeSalaryBM>();
            //BenchmarkRunner.Run<EmployeeFooBM>();
        }
    }
}
