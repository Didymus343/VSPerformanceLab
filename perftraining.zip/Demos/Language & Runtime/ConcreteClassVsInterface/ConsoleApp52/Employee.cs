﻿using System;
using System.Runtime.CompilerServices;

namespace ConsoleApp52 {
    public class Employee : IEmployee {

        private double _salary;
        public string Name { get; set; }

        public Employee(string name, double salary) {
            this.Name = name;
            this.Salary1 = salary;
        }

        public double Salary1 {
            get => _salary;
            set {
                this._salary = value;
            }
        }

        public virtual double Salary2 {
            get => _salary;
            set {
                _salary = value;
            }
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Foo() {
            _salary += 1;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Foo(int p) {
            _salary += 1;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Foo(double p) {
            _salary += 1;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Foo(long p) {
            _salary += 1;
        }

        public override string ToString() {
            return string.Format("Employee Name = {0}, Salary = {1}", this.Name, this.Salary1);
        }
    }

    class ThrowHelper {
        public static void ArgumentOutOfRangeException() => throw new ArgumentOutOfRangeException();
        public static void InvalidOperationException() => throw new InvalidOperationException();
    }

}