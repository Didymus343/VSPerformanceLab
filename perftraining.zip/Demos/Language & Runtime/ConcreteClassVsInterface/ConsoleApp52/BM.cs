﻿using System;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Engines;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp52 {

    [RPlotExporter]
    [MemoryDiagnoser]
    public class DictionaryBM {

        private Dictionary<string, string> _dict;
        private IDictionary<string, string> _iDict;

        [Params(1, 100, 1000, 10000)]
        public int Size { get; set; }

        [GlobalSetup]
        public void Setup() {
            _iDict = _dict = Enumerable.Range(1, this.Size).ToDictionary(n => n.ToString(), n => n.ToString());
        }

        [Benchmark(Baseline = true)]
        public Dictionary<string, string> DictionaryEnumeration() {
            foreach (var kvp in _dict) {
            }
            return _dict;
        }

        [Benchmark]
        public IDictionary<string, string> IDictionaryEnumeration() {
            foreach (var kvp in _iDict) {
            }
            return _iDict;
        }

    }

    public class ListBM {

        private List<string> _list;
        private IList<string> _iList;
        private IEnumerable<string> _iEnumerable;

        [Params(1, 100, 1000, 10000)]
        public int Size { get; set; }

        [GlobalSetup]
        public void Setup() {
            _iEnumerable = _iList = _list = Enumerable.Range(1, this.Size).Select(n => n.ToString()).ToList();
        }

        [Benchmark(Baseline = true)]
        public List<string> ListEnumeration() {
            foreach (var item in _list) {
            }
            return _list;
        }

        [Benchmark]
        public IList<string> IListEnumeration() {
            foreach (var item in _iList) {
            }
            return _iList;
        }

        [Benchmark]
        public string IEnumerableEnumeration() {
            foreach (var item in _iEnumerable) {
            }
            return "abc";
        }

    }


    public class EmployeeSalaryBM {

        private Employee _emp;
        private IEmployee _iEmp;

        [GlobalSetup]
        public void Setup() {
            _iEmp = _emp = new Employee("Fons", 2000);
        }

        [Benchmark(Baseline = true)]
        public Employee EmployeeSalary() {
            for (int i = 0; i < 1000; i++) {
                _emp.Salary1 += 1;
            }
            return _emp;
        }

        [Benchmark]
        public Employee EmployeeVirtualSalary() {
            for (int i = 0; i < 1000; i++) {
                _emp.Salary2 += 1;
            }
            return _emp;
        }

        [Benchmark()]
        public IEmployee IEmployeeSalary() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Salary1 += 1;
            }
            return _iEmp;
        }

        [Benchmark]
        public IEmployee IEmployeeVirtualSalary() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Salary2 += 1;
            }
            return _iEmp;
        }

    }



    public class EmployeeFooBM {

        private Employee _emp;
        private IEmployee _iEmp;

        [GlobalSetup]
        public void Setup() {
            _iEmp = _emp = new Employee("Fons", 2000);
        }

        [Benchmark(Baseline = true)]
        public Employee EmployeeFoo() {
            for (int i = 0; i < 1000; i++) {
                _emp.Foo();
            }
            return _emp;
        }

        [Benchmark]
        public Employee EmployeeFooInt() {
            for (int i = 0; i < 1000; i++) {
                _emp.Foo(1);
            }
            return _emp;
        }

        [Benchmark()]
        public Employee EmployeeFooDouble() {
            for (int i = 0; i < 1000; i++) {
                _emp.Foo(1D);
            }
            return _emp;
        }

        [Benchmark]
        public Employee EmployeeFooLong() {
            for (int i = 0; i < 1000; i++) {
                _emp.Foo(1L);
            }
            return _emp;
        }

        [Benchmark()]
        public IEmployee IEmployeeFoo() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Foo();
            }
            return _iEmp;
        }

        [Benchmark]
        public IEmployee IEmployeeFooInt() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Foo(1);
            }
            return _iEmp;
        }

        [Benchmark()]
        public IEmployee IEmployeeFooDouble() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Foo(1D);
            }
            return _iEmp;
        }

        [Benchmark]
        public IEmployee IEmployeeFooLong() {
            for (int i = 0; i < 1000; i++) {
                _iEmp.Foo(1L);
            }
            return _iEmp;
        }

    }

}