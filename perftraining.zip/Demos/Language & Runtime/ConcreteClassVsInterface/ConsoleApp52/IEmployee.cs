﻿namespace ConsoleApp52 {
    public interface IEmployee {
        string Name { get; set; }
        double Salary1 { get; set; }
        double Salary2 { get; set; }

        void Foo();
        void Foo(int p);
        void Foo(double p);
        void Foo(long p);
    }
}