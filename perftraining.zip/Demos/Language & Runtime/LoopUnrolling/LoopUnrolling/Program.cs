﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Linq;

namespace LoopUnrolling {

    // https://www.codeproject.com/Articles/844781/Digging-Into-NET-Loop-Performance-Bounds-checking

    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    public class BM {

        private int[] _array;
        private const int ArraySize = 100;

        [GlobalSetup]
        public void Setup() {
            _array = Enumerable.Range(1, ArraySize).ToArray();
        }

        [Benchmark]
        public int Normal() {
            return GetSum(_array);

            static int GetSum(int[] array) {
                int sum = 0;
                for (int i = 0; i < array.Length; i++) {
                    sum += array[i];
                }
                return sum;
            }
        }

        [Benchmark]
        public int LoopUnrolledUsingConstant() {
            return GetSum(_array);

            static int GetSum(int[] array) {
                int sum = 0;
                for (int i = 0; i < ArraySize; i++) {
                    sum += array[i];
                }
                return sum;
            }
        }

        [Benchmark(Baseline = true)]
        public int LoopUnrolledUsingLogic() {
            return GetSum(_array);

            static int GetSum(int[] array) {
                int sum = 0;
                for (int i = 0; i < array.Length - 4; i += 4) {
                    sum += array[i] + array[i + 1] + array[i + 2] + array[i + 3];
                }
                return sum;
            }
        }

    }
}
