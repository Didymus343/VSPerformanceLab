﻿using System.IO.MemoryMappedFiles;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

const long offset = 0x10000000; // 256 megabytes
const long length = 0x20000000; // 512 megabytes

// Create the file
using (var fileStream = File.Create(@"d:\ExtremelyLargeImage.data")) {
    int colorSize = Unsafe.SizeOf<MyColor>();
    var color = new MyColor(128, 128, 128, 255);
    Span<byte> span = stackalloc byte[colorSize];
    MemoryMarshal.Write(span, ref color);
    for (long i = 0; i < length * 2; i += colorSize) {
        fileStream.Write(span);
    }
}
Console.WriteLine("Created");

// Create the memory-mapped file.
using (var mmf = MemoryMappedFile.CreateFromFile(@"d:\ExtremelyLargeImage.data", FileMode.Open, "ImgA")) {
    // Create a random access view, from the 256th megabyte (the offset)
    // to the 768th megabyte (the offset plus length).
    using (var accessor = mmf.CreateViewAccessor(offset, length)) {
        int colorSize = Unsafe.SizeOf<MyColor>();
        MyColor color;

        // Make changes to the view.
        for (long i = 0; i < length; i += colorSize) {
            accessor.Read(i, out color);
            color.Brighten(10);
            accessor.Write(i, ref color);
        }
    }
}
Console.WriteLine("Updated");

public record struct MyColor(short Red, short Green, short Blue, short Alpha) {

    public short Red = Red;
    public short Green = Green;
    public short Blue = Blue;
    public short Alpha = Alpha;

    // Make the view brighter.
    public void Brighten(short value) {
        Red = (short)Math.Min(short.MaxValue, (int)Red + value);
        Green = (short)Math.Min(short.MaxValue, (int)Green + value);
        Blue = (short)Math.Min(short.MaxValue, (int)Blue + value);
        Alpha = (short)Math.Min(short.MaxValue, (int)Alpha + value);
    }
}
