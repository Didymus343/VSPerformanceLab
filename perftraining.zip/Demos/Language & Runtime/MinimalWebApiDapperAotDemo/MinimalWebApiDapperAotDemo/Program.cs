var builder = WebApplication.CreateBuilder(args);
// Add services to the container.

// Inject SqlConnection using erikej.sqlclient.extensions NuGet package
builder.Services.AddSqlDataSource(builder.Configuration.GetConnectionString("Northwind")!, 
                                  ServiceLifetime.Scoped);

// Json serialization without Reflection, uses the JSON SourceGenerator
builder.Services.ConfigureHttpJsonOptions(options => {
    options.SerializerOptions.TypeInfoResolverChain.Insert(0, MyJsonContext.Default);
});

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.MapGet("/suppliers", async Task<IEnumerable<Supplier>> (SqlConnection connection) => {
    return await Supplier.GetSuppliersFromCountryAsync(connection, "USA");
});

app.MapGet("/suppliers/{id}", async Task<Supplier> (SqlConnection connection, int id) => {
    return await Supplier.GetSupplierByIdAsync(connection, id);
});

//app.MapSupplierEndpoints();

app.Run();
