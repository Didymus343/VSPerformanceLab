﻿global using Microsoft.Data.SqlClient;
global using MinimalWebApiDapperAotDemo;
global using MinimalWebApiDapperAotDemo.Models;
global using MinimalWebApiDapperAotDemo.Endpoints;
