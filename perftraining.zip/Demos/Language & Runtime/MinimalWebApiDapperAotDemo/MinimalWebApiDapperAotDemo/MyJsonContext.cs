﻿using System.Text.Json.Serialization;

namespace MinimalWebApiDapperAotDemo;

[JsonSerializable(typeof(IEnumerable<Supplier>))]
internal partial class MyJsonContext : JsonSerializerContext { // Partial class

}
