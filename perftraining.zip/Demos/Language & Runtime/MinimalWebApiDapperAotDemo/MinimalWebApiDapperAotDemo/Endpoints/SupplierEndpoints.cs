﻿namespace MinimalWebApiDapperAotDemo.Endpoints {

    public static class SupplierEndpoints {

        public static void MapSupplierEndpoints(this IEndpointRouteBuilder routes) {
            var group = routes.MapGroup("/suppliers").WithTags(nameof(Supplier));

            group.MapGet("/", async (SqlConnection connection) => {
                return await Supplier.GetSuppliersFromCountryAsync(connection, "USA");
            }).WithName("GetAllSuppliersFromUSA");

            group.MapGet("/{id}", async (SqlConnection connection, int id) => {
                return await Supplier.GetSupplierByIdAsync(connection, id);
            }).WithName("GetSupplierById");

        }

    }
}
