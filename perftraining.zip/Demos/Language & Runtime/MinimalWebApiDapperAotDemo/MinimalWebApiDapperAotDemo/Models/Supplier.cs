﻿using Dapper;
using Microsoft.Data.SqlClient;

namespace MinimalWebApiDapperAotDemo.Models;

[DapperAot]
public partial class Supplier
{

    public static async Task<Supplier> GetSupplierByIdAsync(SqlConnection connection, int id)
        => await connection.QueryFirstAsync<Supplier>("select * from dbo.Suppliers where SupplierId = @id", new { id });

    public static async Task<IEnumerable<Supplier>> GetSuppliersFromCountryAsync(SqlConnection connection, string country)
        => await connection.QueryAsync<Supplier>("select * from dbo.Suppliers where Country = @country", new { country });

    public int SupplierId { get; set; }

    //public required string CompanyName { get; set; }
    public string CompanyName { get; set; } = string.Empty;

    public string? ContactName { get; set; }

    public string? ContactTitle { get; set; }

    public string? Address { get; set; }

    public string? City { get; set; }

    public string? Region { get; set; }

    public string? PostalCode { get; set; }

    public string? Country { get; set; }

    public string? Phone { get; set; }

    public string? Fax { get; set; }

    public string? HomePage { get; set; }

}