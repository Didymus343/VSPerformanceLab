﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Reports;

namespace InliningBenchmarks {
    class TrendRatioStyleConfigAttribute : ConfigAttribute {

        public TrendRatioStyleConfigAttribute() : base(typeof(TrendRatioStyleConfig)) {
        }

        private class TrendRatioStyleConfig : ManualConfig {

            public TrendRatioStyleConfig() {
                SummaryStyle = SummaryStyle.Default.WithRatioStyle(RatioStyle.Trend);
            }
        }

    }

}
