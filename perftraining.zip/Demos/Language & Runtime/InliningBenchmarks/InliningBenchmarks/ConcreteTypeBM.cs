﻿using BenchmarkDotNet.Attributes;
using System;

namespace InliningBenchmarks.Concrete {

    public class ConcreteTypeBM {

        private readonly ClassA _a = new ClassA();
        private readonly IInterfaceA _b = new ClassA();

        [Benchmark()]
        public double Interface() => _b.Foo(1D, 3D);

        [Benchmark(Baseline = true)]
        public double ConcreteType() => _a.Foo(1D, 3D);
    }

    interface IInterfaceA {
        double Foo(double a, double b);
    }

    public class ClassA : IInterfaceA {
        public double Foo(double a, double b) => a / b * Math.PI;
    }

}
