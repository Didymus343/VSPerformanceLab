﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using System;

namespace InliningBenchmarks {

    [ShortRunJob(runtimeMoniker: RuntimeMoniker.Net80)]
    [ShortRunJob(runtimeMoniker: RuntimeMoniker.Net60)]
    [ShortRunJob(runtimeMoniker: RuntimeMoniker.Net48)]
    [HideColumns("Job", "RatioSD")]
    [TrendRatioStyleConfig]
    public class ThrowBM {

        private double _salary;

        [Benchmark(Baseline = true)]
        public void ThrowNewException() {
            for (int i = 0; i < 100; i++) {
                this.Salary += 1D; // Not inlined
            }
        }

        [Benchmark]
        public void UseCommunityToolkitThrowHelper() {
            for (int i = 0; i < 100; i++) {
                this.SalaryWithCommunityToolkitThrowHelper += 1D; // Inlined
            }
        }

        [Benchmark]
        public void UseMyThrowHelper() {
            for (int i = 0; i < 100; i++) {
                this.SalaryWithMyThrowHelper += 1D; // Inlined
            }
        }

        [Benchmark]
        public void UseGuard() {
            for (int i = 0; i < 100; i++) {
                this.SalaryWithGuard += 1D; // Inlined
            }
        }

        private double Salary {
            get => this._salary;
            set {
                if (value < 0) {
                    throw new ArgumentOutOfRangeException(nameof(value));
                }
                this._salary = value;
            }
        }

        private double SalaryWithCommunityToolkitThrowHelper {
            get => this._salary;
            set {
                if (value < 0) {
                    CommunityToolkit.Diagnostics.ThrowHelper.ThrowArgumentOutOfRangeException(nameof(value));
                }
                this._salary = value;
            }
        }

        private double SalaryWithMyThrowHelper {
            get => this._salary;
            set {
                if (value < 0) {
                    InliningBenchmarks.ThrowHelper.ThrowArgumentOutOfRangeException(nameof(value));
                }
                this._salary = value;
            }
        }

        private double SalaryWithGuard {
            get => this._salary;
            set {
                CommunityToolkit.Diagnostics.Guard.IsGreaterThanOrEqualTo(value, 0);
                this._salary = value;
            }
        }

#if NET8_0_OR_GREATER

        [Benchmark]
        public void UseThrowIfNegative() {
            for (int i = 0; i < 100; i++) {
                this.SalaryWithThrowIfNegative += 1D; // Inlined
            }
        }

        private double SalaryWithThrowIfNegative {
            get => this._salary;
            set {
                ArgumentOutOfRangeException.ThrowIfNegative(value);
                this._salary = value;
            }
        }
#else
        [Benchmark]
        public void UseThrowIfNegative() {
            for (int i = 0; i < 100; i++) {
                this.Salary += 1D; // Not Inlined
            }
        }
#endif

    }


}
