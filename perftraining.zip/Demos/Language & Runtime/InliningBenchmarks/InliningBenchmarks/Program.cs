﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;
using InliningBenchmarks.Concrete;

namespace InliningBenchmarks {
    class Program {

        static void Main(string[] args) {
            BenchmarkRunner.Run<ThrowBM>();
            //BenchmarkRunner.Run<VirtualBM>();
            //BenchmarkRunner.Run<SealedOverrideBM>();
            //BenchmarkRunner.Run<ConcreteTypeBM>();
        }
    }

}
