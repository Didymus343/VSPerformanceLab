﻿using BenchmarkDotNet.Attributes;
using System;

namespace InliningBenchmarks {

    public class VirtualBM {

        [Benchmark]
        public double Virtual() {
            return Foo(1D, 2D);
        }

        [Benchmark(Baseline = true)]
        public double NonVirtual() {
            return Bar(1D, 2D);
        }

        public virtual double Foo(double a, double b) {
            return a + b;
        }

        public double Bar(double a, double b) {
            return a + b;
        }
    }

    
}
