﻿using System;
using System.Runtime.CompilerServices;

namespace InliningBenchmarks {

    internal static class ThrowHelper {

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static void ThrowArgumentOutOfRangeException(string paramName) {
            throw new ArgumentOutOfRangeException(paramName);
        }
    }


}
