﻿using BenchmarkDotNet.Attributes;
using System;

namespace InliningBenchmarks {

    public class SealedOverrideBM {

        private readonly ClassB _b = new ClassB();
        private readonly ClassC _c = new ClassC();

        [Benchmark()]
        public double Override() => _b.Foo(1D, 3D);

        [Benchmark(Baseline = true)]
        public double SealedMethodOverride() => _c.Foo(1D, 3D);

    }

    public class ClassA {
        public virtual double Foo(double a, double b) => 1D;
    }

    public class ClassB : ClassA {
        public override double Foo(double a, double b) => a / b * Math.PI;
    }

    public class ClassC : ClassA {
        public sealed override double Foo(double a, double b) => a / b * Math.PI;
    }

    public sealed class ClassD : ClassA {
        public override double Foo(double a, double b) => a / b * Math.PI;
    }
}
