﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Toolchains.CsProj;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastBM {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    public class MultipleRuntimes : ManualConfig {
        public MultipleRuntimes() {
            Add(Job.Default.With(CsProjClassicNetToolchain.Net472)); // .NET Framework 4.7.2
            Add(Job.Default.With(CsProjCoreToolchain.NetCoreApp22)); // .NET Core 2.2
        }
    }

    [Config(typeof(MultipleRuntimes))]
    public class BM {

        private readonly object _value = new Implementation();

        [Benchmark]
        public object ObjectCast() => _value;

        [Benchmark(Baseline = true)]
        public Implementation ImplementationCast() => (Implementation)_value;

        [Benchmark]
        public IInterface InterfaceCast() => (IInterface)_value;

        [Benchmark]
        public IGeneric<int> GenericCast() => (IGeneric<int>)_value;

        [Benchmark]
        public ICovariant<int> CovariantCast() => (ICovariant<int>)_value;

        [Benchmark]
        public IContravariant<int> ContravariantCast() => (IContravariant<int>)_value;

        public class Implementation : IInterface, IGeneric<int>, ICovariant<int>, IContravariant<int> { }
        public interface IInterface { }
        public interface IGeneric<T> { }
        public interface ICovariant<out T> { }
        public interface IContravariant<in T> { }

    }
}
