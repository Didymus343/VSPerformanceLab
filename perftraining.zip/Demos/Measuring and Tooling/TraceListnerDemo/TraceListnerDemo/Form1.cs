﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TraceListnerDemo {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e) {
            var sw = System.Diagnostics.Stopwatch.StartNew();

            Parallel.For(1, 100000, i => {
                Trace.WriteLine($"Trace {i.ToString()}");
            });


            sw.Stop();
            button1.Text = sw.Elapsed.ToString();

        }
    }

   

}
