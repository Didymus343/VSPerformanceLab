﻿namespace XUnitTestProject1 {
    public struct PointStruct {
        public int X;
        public int Y;

        public PointStruct(int x, int y) {
            this.X = x;
            this.Y = y;
        }
    }

}


