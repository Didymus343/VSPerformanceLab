﻿using BenchmarkDotNet.Exporters;
using BenchmarkDotNet.Extensions;
using BenchmarkDotNet.Running;
using Xunit;
using Xunit.Abstractions;

namespace XUnitTestProject1 {

    public class UnitTestBM {

        public ITestOutputHelper TestOutputHelper { get; }

        public UnitTestBM(ITestOutputHelper testOutputHelper) => TestOutputHelper = testOutputHelper;


        [Fact]
        public void TestBM() {
            var summary = BenchmarkRunner.Run<BM>();

            using var logger = new TestOutpubBenchmarkLogger(TestOutputHelper);
            MarkdownExporter.Console.ExportToLog(summary, logger);

            var reportClass = summary.GetReportFor<BM>(r => r.CreatePointClass());
            var reportStruct = summary.GetReportFor<BM>(r => r.CreatePointStruct());

            // Mean
            Assert.InRange(reportClass.ResultStatistics.Mean, low: 200, high: 400);
            Assert.InRange(reportStruct.ResultStatistics.Mean, low: 20, high: 40);

            // Allocations
            Assert.Equal(2400, reportClass.Metrics["Allocated Memory"].Value);
            Assert.Equal(0.0, reportStruct.Metrics["Allocated Memory"].Value);

        }

    }

}


