﻿using BenchmarkDotNet.Attributes;

namespace XUnitTestProject1 {
    [MemoryDiagnoser]
    [SimpleJob(warmupCount: 4, targetCount: 10, invocationCount: 100_000)]
    public class BM {

        [Benchmark]
        public void CreatePointClass() {
            for (int i = 0; i < 100; i++) {
                new PointClass(i, 2);
            }
        }

        [Benchmark]
        public void CreatePointStruct() {
            for (int i = 0; i < 100; i++) {
                new PointStruct(i, 2);
            }
        }

    }

}


