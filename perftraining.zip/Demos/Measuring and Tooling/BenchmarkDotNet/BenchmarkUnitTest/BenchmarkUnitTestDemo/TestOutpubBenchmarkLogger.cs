﻿using System;
using System.Text;
using Xunit.Abstractions;
using ILogger = BenchmarkDotNet.Loggers.ILogger;

namespace XUnitTestProject1 {
    class TestOutpubBenchmarkLogger : ILogger, IDisposable {

        private readonly StringBuilder _sb = new StringBuilder();
        private readonly ITestOutputHelper _testOutputHelper;

        public TestOutpubBenchmarkLogger(ITestOutputHelper testOutputHelper) {
            _testOutputHelper = testOutputHelper;
        }

        public void Write(BenchmarkDotNet.Loggers.LogKind logKind, string text) {
            _sb.Append(text);
        }

        public void WriteLine() {
            _sb.AppendLine();
        }

        public void WriteLine(BenchmarkDotNet.Loggers.LogKind logKind, string text) {
            _sb.AppendLine(text);
        }

        public void Flush() {
            _testOutputHelper.WriteLine(_sb.ToString());
            _sb.Clear();
        }

        public string Id { get; }
        public int Priority { get; }

        public void Dispose() {
            this.Flush();
        }
    }

}


