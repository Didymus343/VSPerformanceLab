﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Open.Numeric.Primes;


BenchmarkRunner.Run<BM>();
//Console.WriteLine(new BM().CountSqrt());
//Console.WriteLine(new BM().CountMultiply());

public class BM {

    [Benchmark]
    public int CountSqrt() {
        int total = 0;
        for (int i = 0; i < 200_000; i++)
            if (IsPrime(i)) total++;
        return total;

            static bool IsPrime(int number) {
                if (number <= 2) return number == 2;
                if ((number % 2) == 0) return false;
                int sqrt = (int)Math.Sqrt(number);
                for (int t = 3; t <= sqrt; t += 2) {
                    if (number % t == 0) return false;
                }
                return true;
            }
    }

    [Benchmark]
    public int CountMultiply() {
        int total = 0;
        for (int i = 0; i < 200_000; i++)
            if (IsPrime(i)) total++;
        return total;

        static bool IsPrime(int number) {
            if (number <= 2) return number == 2;
            if ((number % 2) == 0) return false;
            for (int t = 3; t * t < number; t += 2) {
                if (number % t == 0) return false;
            }
            return true;
        }
    }

    /// <summary>
    /// Source: https://en.m.wikipedia.org/wiki/Primality_test
    /// </summary>
    [Benchmark(Baseline = true)]
    public int CountFast() {
        int total = 0;
        for (int i = 0; i < 200_000; i++)
            if (IsPrime(i)) total++;
        return total;

        bool IsPrime(int n) {
            if (n == 2 || n == 3) return true;
            if (n <= 1 || n % 2 == 0 || n % 3 == 0) return false;
            for (int i = 5; i * i <= n; i += 6) {
                if (n % i == 0 || n % (i + 2) == 0) return false;
            }
            return true;
        } 
    }

    [Benchmark()]
    public int CountOpenNumericsPrimes() {
        // Install-Package Open.Numeric.Primes
        int total = 0;
        for (int i = 0; i < 200_000; i++)
            if (Number.IsPrime(i)) total++;
        return total;
    }
}
