﻿using BenchmarkDotNet.Running;

BenchmarkRunner.Run<BM>();

//BenchmarkRunner.Run<ParamsBM>();
//BenchmarkRunner.Run<ArgumentsBM>();
//BenchmarkRunner.Run<StringConcatBM>();
