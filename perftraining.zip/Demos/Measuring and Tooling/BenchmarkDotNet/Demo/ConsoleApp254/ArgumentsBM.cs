﻿using BenchmarkDotNet.Attributes;

[ShortRunJob]
public class ArgumentsBM {

    [Benchmark]
    [Arguments(10, 20, 30)]
    [Arguments(30, 40, 50)]
    public void Benchmark(int a, int b, int c) => Thread.Sleep(a + b + c);
}

