﻿using BenchmarkDotNet.Attributes;

[ShortRunJob]
public class ParamsBM {

    [Params(100, 200)]
    public int A { get; set; }

    [Params(10, 20)]
    public int B { get; set; }

    [Benchmark]
    public void Benchmark1() => Thread.Sleep(A + B);

    [Benchmark]
    public void Benchmark2() => Thread.Sleep(A + B + 50);

}

