﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;

[HideColumns("Job", "IterationCount", "LaunchCount", "WarmupCount", "RatioSD")]
[RankColumn]
[MemoryDiagnoser(displayGenColumns: false)]
[ShortRunJob(RuntimeMoniker.Net48)]
[ShortRunJob(RuntimeMoniker.Net50)]
[ShortRunJob(RuntimeMoniker.Net60)]
[ShortRunJob(RuntimeMoniker.Net80)]
public class StringConcatBM {

    private DateTime _birthDate = new DateTime(1969, 7, 22);

    [Benchmark] public string StringConcat() => "Birthday = " + _birthDate.ToString("d") + ", Month = " + _birthDate.Month;
    [Benchmark] public string StringInterpolation() => $"Birthday = {_birthDate:d}, Month = {_birthDate.Month}";
    [Benchmark] public string StringInterpolationToString() => $"\"Birthday = {_birthDate.ToString("d")}, Month = {_birthDate.Month.ToString()}";
}
