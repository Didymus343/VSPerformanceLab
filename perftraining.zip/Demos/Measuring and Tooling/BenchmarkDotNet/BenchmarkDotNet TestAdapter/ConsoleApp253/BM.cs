﻿
using BenchmarkDotNet.Attributes;

namespace MyBenchmarLibrary;

[MemoryDiagnoser(displayGenColumns: false)]
[ShortRunJob]
public class BM {
    private List<Employee> _employees = new List<Employee>(1000);

    [GlobalSetup]
    public void Setup() {
        for (int i = 0; i < _employees.Capacity; i++) _employees.Add(new Employee("Fons", i));
    }

    [Benchmark(Baseline = true)]
    public Employee? ListFind() => _employees.Find(emp => emp.Salary > 500);

    [Benchmark]
    public Employee? LinqFirstOrDefault() => _employees.FirstOrDefault(emp => emp.Salary > 500);

    [Benchmark]
    public Employee? LinqWhereFirstOrDefault() => _employees.Where(emp => emp.Salary > 500).FirstOrDefault();

    [Benchmark]
    public Employee? LinqWhereToListIndex0() => _employees.Where(emp => emp.Salary > 500).ToList()[0];
}

