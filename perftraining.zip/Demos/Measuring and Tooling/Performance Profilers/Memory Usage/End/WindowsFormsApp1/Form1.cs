﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsFormsApp1 {
    public partial class Form1 : Form {

        public Form1() {
            InitializeComponent();
        }

        private readonly List<Employee> _list = new List<Employee>();
        //private readonly List<Employee> _list = new List<Employee>(capacity: 200_000); // When not on .NET 6

        private void Button1_Click(object sender, EventArgs e) {
            // Make sure we have enough capacity, new API in .NET 6
            _list.EnsureCapacity(_list.Count + 100_000);

            for (int i = 0; i < 100_000; i++) {
                _list.Add(new Employee("Fons" + i, 2000 + i));
            }
            button1.Text = _list.Count.ToString();
        }

        private void Button2_Click(object sender, EventArgs e) {
            _list.Clear();
            
            _list.TrimExcess(); // Remove wasted array memory

            button1.Text = _list.Count.ToString();
        }

        private void Button3_Click(object sender, EventArgs e) {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

    }

}
