﻿namespace WindowsFormsApp1 {

    internal class Employee {

        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Employee() {
        }

        public Employee(string name, decimal salary) {
            this.Name = name;
            this.Salary = salary;
        }

        public override string ToString() => $"Employee Name = {this.Name}, Salary = {this.Salary:C2}";
    }

}
