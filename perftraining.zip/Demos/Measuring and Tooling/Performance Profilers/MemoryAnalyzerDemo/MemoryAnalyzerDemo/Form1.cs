﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MemoryAnalyzerDemo {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e) {
            var sw = Stopwatch.StartNew();
            for (int i = 0; i < 100_000; i++) {
                FormatVersion(i, i, i, i);
            }
            sw.Stop();
            button1.Text = sw.Elapsed.ToString();
        }

        public static string FormatVersion(int major, int minor, int build, int revision) {
            return $"{major}.{minor}.{build}.{revision}";
        }


        private void Button2_Click(object sender, EventArgs e) {
            var sw = Stopwatch.StartNew();
            for (int i = 0; i < 100_000; i++) {
                FormatVersion2(i, i, i, i);
                //FormatVersion3(i, i, i, i);
                //FormatVersion4(i, i, i, i);
            }
            sw.Stop();
            button2.Text = sw.Elapsed.ToString();
        }


        public static string FormatVersion2(int major, int minor, int build, int revision) {
            return $"{major.ToString()}.{minor.ToString()}.{build.ToString()}.{revision.ToString()}";
        }

        public static string FormatVersion3(int major, int minor, int build, int revision) {
            var sb = new StringBuilder();
            sb.Append(major);
            sb.Append(".");
            sb.Append(minor);
            sb.Append(".");
            sb.Append(build);
            sb.Append(".");
            sb.Append(revision);
            return sb.ToString();
        }

        public static string FormatVersion4(int major, int minor, int build, int revision) {
            var sb = new StringBuilder(64);
            sb.Append(major);
            sb.Append(".");
            sb.Append(minor);
            sb.Append(".");
            sb.Append(build);
            sb.Append(".");
            sb.Append(revision);
            return sb.ToString();
        }

        private void Button3_Click(object sender, EventArgs e) {
            var sw = Stopwatch.StartNew();
            var sb = new StringBuilder(64);
            for (int i = 0; i < 100_000; i++) {
                FormatVersion5(sb, i, i, i, i);
                sb.Clear();
            }
            sw.Stop();
            button3.Text = sw.Elapsed.ToString();
        }

        public static string FormatVersion5(StringBuilder sb, int major, int minor, int build, int revision) {
            sb.Append(major);
            sb.Append(".");
            sb.Append(minor);
            sb.Append(".");
            sb.Append(build);
            sb.Append(".");
            sb.Append(revision);
            return sb.ToString();
        }

        private void Button4_Click(object sender, EventArgs e) {
            var sw = Stopwatch.StartNew();
            for (int i = 0; i < 100_000; i++) {
                Debug.WriteLineIf(i < 0, $"{i}.{i}.{i}.{i}");
            }
            sw.Stop();
            button4.Text = sw.Elapsed.ToString();
        }

    }
}
