﻿using System;
using System.Windows.Forms;

namespace Primes {
    public sealed class WaitCursor : IDisposable {
        private readonly Cursor _prev;

        public WaitCursor() {
            _prev = Cursor.Current;
            Cursor.Current = Cursors.WaitCursor;
        }

        public void Dispose() {
            Cursor.Current = _prev;
        }
    }

}
