﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Primes {
    public partial class Form1 : Form {

        public Form1() {
            this.InitializeComponent();
        }

        private void Button1_Click(object sender, System.EventArgs e) {
            using (new WaitCursor()) {

                var sw = Stopwatch.StartNew();
                int total = CountPrimes();
                sw.Stop();

                this.button1.Text = $"{total} Primes in {sw.ElapsedMilliseconds / 1000D:N2} sec";
            }
        }

        private int CountPrimes() {
            int total = 0;
            for (int i = 0; i < 20_000_000; i++) {
                if (IsPrime(i)) {
                    total++;
                }
            }
            return total;
        }

        private static bool IsPrime(int number) {
            if (number < 2) {
                return false;
            }
            if (number == 2) {
                return true;
            }
            if (number % 2 == 0) {
                return false;
            }
            for (int i = 3; i <= Math.Sqrt(number); i += 2) {
                if (number % i == 0) {
                    return false;
                }
            }
            return true;
        }


        private static bool IsPrime2(int number) {
            if (number < 2) {
                return false;
            }
            if (number == 2) {
                return true;
            }
            if (number % 2 == 0) {
                return false;
            }

            var sqrt = Math.Sqrt(number);
            for (int i = 3; i <= sqrt; i += 2) {
                if (number % i == 0) {
                    return false;
                }
            }
            return true;
        }

        private static bool IsPrime3(int number) {
            if (number < 2) {
                return false;
            }
            if (number == 2) {
                return true;
            }
            if (number % 2 == 0) {
                return false;
            }

            var sqrt = (int)Math.Sqrt(number);
            for (int i = 3; i <= sqrt; i += 2) {
                if (number % i == 0) {
                    return false;
                }
            }
            return true;
        }

    }

}
