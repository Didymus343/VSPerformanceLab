﻿using System;

namespace ClassLibrary1;

public static class Utils {

    public static int CountPrimes(int from, int to) {
        int count = 0;
        for (int i = from; i <= to; i++) {
            if (IsPrime(i)) count++;
        }
        return count;
    }

    public static bool IsPrime(int number) {
        if (number < 2) {
            return false;
        }
        if (number == 2) {
            return true;
        }
        if (number % 2 == 0) {
            return false;
        }
        for (int i = 3; i <= Math.Sqrt(number); i += 2) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }


    public static bool IsPrime2(int number) {
        if (number < 2) {
            return false;
        }
        if (number == 2) {
            return true;
        }
        if (number % 2 == 0) {
            return false;
        }

        var sqrt = Math.Sqrt(number);
        for (int i = 3; i <= sqrt; i += 2) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static bool IsPrime3(int number) {
        if (number < 2) {
            return false;
        }
        if (number == 2) {
            return true;
        }
        if (number % 2 == 0) {
            return false;
        }

        var sqrt = (int)Math.Sqrt(number);
        for (int i = 3; i <= sqrt; i += 2) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static string FormatVersion(int major, int minor, int build, int revision) {
        return $"{major}.{minor}.{build}.{revision}";
    }
}
