﻿using ClassLibrary1;
using NUnit.Framework;

namespace UnitTestProject1; 

public class UnitTestPrimes {

    [Test]
    public void TestPrime0() {
        Assert.IsFalse(Utils.IsPrime(0));
    }

    [Test]
    public void TestPrime1() {
        Assert.IsFalse(Utils.IsPrime(1));
    }

    [Test]
    public void TestCountPrimes100() {
        Assert.That(Utils.CountPrimes(1, 100), Is.EqualTo(25));
    }

    [Test]
    public void TestCountPrimes1M() {
        Assert.That(Utils.CountPrimes(1, 1_000_000), Is.EqualTo(78498));
    }

    [Test]
    public void TestCountPrimes20M() {
        Assert.That(Utils.CountPrimes(1, 20_000_000), Is.EqualTo(1270607));
    }

    [Test]
    public void TestFormatVersion() {
        Assert.That(Utils.FormatVersion(1, 2, 3, 4), Is.EqualTo("1.2.3.4"));
    }
}
