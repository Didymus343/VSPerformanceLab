﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnitTestProject1;

namespace ProfinlingDemoUsingUnitTest {
    class Program {
        static void Main(string[] args) {
            var ut = new UnitTestPrimes();
            ut.TestCountPrimes1M();
        }
    }
}
