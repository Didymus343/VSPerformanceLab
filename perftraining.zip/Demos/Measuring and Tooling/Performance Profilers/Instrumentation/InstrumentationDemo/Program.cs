﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp151 {
    class Program {
        static void Main(string[] args) {
            var employees = new List<Employee>() {
                new Employee("Fons", 2000),
                new Employee("Tim", 6000),
                new Employee("Jim", 4000),
                new Employee("Franci", 6000),
                new Employee("Ellen", 3000),
                new Employee("Richard", 9001),
            };

            var qry = employees.Where(emp => {
                return emp.Salary > employees.Average(emp2 => emp2.Salary);
            });

            foreach (var item in qry) {
                Console.WriteLine(item);
            }

        }
    }


    internal class Employee {

        public string Name { get; set; }
        public double Salary { get; set; }

        public Employee() {
        }

        public Employee(string name, double salary) {
            this.Name = name;
            this.Salary = salary;
        }

        public void RaiseSalary(double percentage) {
            this.Salary += Salary * (percentage / 100);
        }

        public override string ToString() {
            return $"Employee Name = {this.Name}, Salary = {this.Salary:C}";
        }
    }

}

