﻿using System;

namespace WpfApp34 {
    static class Extensions {

        public static bool IsPrime1(this int number) {
            if ((number % 2) == 0) {
                return number == 2;
            }
            for (int t = 3; t <= Math.Sqrt(number); t = t + 2) {
                if (number % t == 0) {
                    return false;
                }
            }
            return number != 1;
        }

        public static bool IsPrime2(this int number) {
            if ((number % 2) == 0) {
                return number == 2;
            }
            for (int t = 3; t <= (int)Math.Sqrt(number); t = t + 2) {
                if (number % t == 0) {
                    return false;
                }
            }
            return number != 1;
        }
    }
}
