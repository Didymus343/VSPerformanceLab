﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace App46.Views.Resources {
    partial class ResourceDictionary1 : ResourceDictionary {
        public ResourceDictionary1() {
            this.InitializeComponent();
        }
    }
}
