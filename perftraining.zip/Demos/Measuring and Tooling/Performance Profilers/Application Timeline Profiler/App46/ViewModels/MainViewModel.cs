﻿using App46.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App46.ViewModels {
    internal class MainViewModel {

        public static MainViewModel Instance { get; } = new MainViewModel();

        public List<Employee> Employees { get; } =
            Enumerable.Range(1, 1000).Select(n => new Employee($"Emp {n.ToString()}", n)).ToList();
    }
}
