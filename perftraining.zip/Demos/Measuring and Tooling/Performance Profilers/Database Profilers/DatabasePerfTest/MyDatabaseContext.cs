﻿using Microsoft.EntityFrameworkCore;

namespace DatabasePerfTest;

public class MyDatabaseContext : DbContext {

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
        optionsBuilder.UseSqlServer(@"Server=.\sqlexpress;Database=MyDatabase;" +
                                     "Trusted_Connection=True;App=Training;", options => {
                                         //options.MaxBatchSize(1);
                                     });
    }


#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public DbSet<CategoryInt> CategoriesInt { get; set; }
    public DbSet<CategoryGuid> CategoriesGuid { get; set; }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
}
