﻿namespace DatabasePerfTest;
class Program {
    static void Main(string[] args) {
        using var db = new MyDatabaseContext();
        //db.Database.EnsureDeleted();
        //db.Database.EnsureCreated();

        string name = new string('a', 4000); // 8000 bytes (Unicode)


        for (int i = 0; i < 100; i++) {
            //db.CategoriesGuid.Add(new CategoryGuid {
            //    Id = Guid.NewGuid(),
            //    Name = name,
            //});

            db.CategoriesInt.Add(new CategoryInt {
                Name = name,
            });
        }

        var sw = System.Diagnostics.Stopwatch.StartNew();
        db.SaveChanges();
        sw.Stop();
        Console.WriteLine(sw.Elapsed.ToString());

    }
}
