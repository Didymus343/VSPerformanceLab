﻿namespace DatabasePerfTest;

public class CategoryInt {

    public int Id { get; set; }

    public string? Name { get; set; }
}

public class CategoryGuid {

    public Guid Id { get; set; }

    public string? Name { get; set; }
}