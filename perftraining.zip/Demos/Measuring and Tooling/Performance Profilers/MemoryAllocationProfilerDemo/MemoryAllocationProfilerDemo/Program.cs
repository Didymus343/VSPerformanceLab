﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Demo {
    internal class Program {
        static void Main(string[] args) {
            var employees = GetEmployees();

            for (var i = 0; i < 50_000; i++) {
                Foo(employees);
            }
        }

        private static void Foo(List<Employee> employees) {
            var result = FindEmployeesWithMinimalSalary(employees, 400);
            //Console.WriteLine(result.Count);
        }

        private static List<Employee> FindEmployeesWithMinimalSalary(List<Employee> employees, int minimalSalary) {
            return employees.FindAll(emp => emp.Salary >= minimalSalary);
            //return employees.Where(emp => emp.Salary >= minimalSalary).ToList();
        }

        private static List<Employee> GetEmployees() {
            var employees = new List<Employee>();
            for (var i = 0; i < 1250; i++) {
                employees.Add(new Employee($"Fons {i}", i));
            }
            return employees;
        }
    }

}
