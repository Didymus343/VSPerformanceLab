﻿namespace Demo {
    internal class Employee {
        public Employee() {
        }

        public Employee(string name, double salary) {
            Name = name;
            Salary = salary;
        }

        public string Name { get; set; }

        public void RaiseSalary(double percentage) {
            Salary += Salary * (percentage / 100);
        }

        public double Salary { get; set; }

        public override string ToString() {
            return string.Format("Employee Name = {0}, Salary = {1:C}", Name, Salary);
        }
    }

}
