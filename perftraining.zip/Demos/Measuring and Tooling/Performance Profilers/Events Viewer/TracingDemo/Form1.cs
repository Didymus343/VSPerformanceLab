using Microsoft.Diagnostics.Tracing.Parsers;
using Microsoft.Diagnostics.Tracing.Session;
using Microsoft.Extensions.Logging;

namespace TracingDemo {
    public partial class Form1 : Form {

        private readonly ILoggerFactory _factoryFile;

        private readonly ILogger _loggerDebug;
        private readonly ILogger _loggerFile;
        private readonly ILoggerFactory _factoryETW;
        private readonly ILogger _loggerETW;

        public Form1() {
            InitializeComponent();

            // Debug
            using ILoggerFactory factoryDebug = LoggerFactory.Create(builder => {
                builder.AddDebug();
            });
            _loggerDebug = factoryDebug.CreateLogger("Form1");

            // File
            _factoryFile = LoggerFactory.Create(builder => {
                builder.AddFile(@"d:\log.txt", isJson: false);
            });
            _loggerFile = _factoryFile.CreateLogger("Form1");

            // ETW
            _factoryETW = LoggerFactory.Create(builder => {
                builder.AddEventSourceLogger();
            });
            _loggerETW = _factoryETW.CreateLogger("Form1");


            var etwSession = new TraceEventSession("MyEtwLog", @"d:\log.etl");
            etwSession.EnableProvider(
                providerName: "Microsoft-Extensions-Logging",
                providerLevel: Microsoft.Diagnostics.Tracing.TraceEventLevel.Informational
                options: new TraceEventProviderOptions() {
                    StacksEnabled = false,
                    Arguments = new[]
                            {
                    new KeyValuePair<string, string>("FilterAndPayloadSpecs", "[AS]*:Tags=*Activity.Tags.*Enumerate;Baggage=*Activity.Baggage.*Enumerate\r\n*"),
                                // ProcessIDFilter = new[] { 123 },
                            },
                }
            );


        }

        private string Foo(ILogger logger) {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            for (int i = 0; i < 1_000_000; i++) {
                logger.LogInformation("Hello World {0}.", i);
            }
            sw.Stop();
            return sw.Elapsed.TotalSeconds.ToString();
        }

        private void ButtonDebug_Click(object sender, EventArgs e) {
            buttonDebug.Text = $"Debug {Foo(_loggerDebug)}";
        }

        private void ButtonFile_Click(object sender, EventArgs e) {
            buttonFile.Text = $"Debug {Foo(_loggerFile)}";
        }

        private void ButtonETW_Click(object sender, EventArgs e) {
            buttonETW.Text = $"Debug {Foo(_loggerETW)}";
        }

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing) {
                components?.Dispose();
                _factoryFile?.Dispose();
                _factoryETW?.Dispose();
            }
            base.Dispose(disposing);
        }
    }


}
