﻿namespace TracingDemo {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            buttonDebug = new Button();
            buttonFile = new Button();
            buttonETW = new Button();
            SuspendLayout();
            // 
            // buttonDebug
            // 
            buttonDebug.Font = new Font("Segoe UI", 14F);
            buttonDebug.Location = new Point(32, 55);
            buttonDebug.Name = "buttonDebug";
            buttonDebug.Size = new Size(732, 108);
            buttonDebug.TabIndex = 0;
            buttonDebug.Text = "Debug";
            buttonDebug.UseVisualStyleBackColor = true;
            buttonDebug.Click += ButtonDebug_Click;
            // 
            // buttonFile
            // 
            buttonFile.Font = new Font("Segoe UI", 14F);
            buttonFile.Location = new Point(32, 217);
            buttonFile.Name = "buttonFile";
            buttonFile.Size = new Size(732, 108);
            buttonFile.TabIndex = 1;
            buttonFile.Text = "File";
            buttonFile.UseVisualStyleBackColor = true;
            buttonFile.Click += ButtonFile_Click;
            // 
            // buttonETW
            // 
            buttonETW.Font = new Font("Segoe UI", 14F);
            buttonETW.Location = new Point(32, 388);
            buttonETW.Name = "buttonETW";
            buttonETW.Size = new Size(732, 108);
            buttonETW.TabIndex = 2;
            buttonETW.Text = "ETW";
            buttonETW.UseVisualStyleBackColor = true;
            buttonETW.Click += ButtonETW_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 546);
            Controls.Add(buttonETW);
            Controls.Add(buttonFile);
            Controls.Add(buttonDebug);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button buttonDebug;
        private Button buttonFile;
        private Button buttonETW;
    }
}
