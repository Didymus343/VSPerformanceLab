﻿using System;
using System.Linq;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.Threading;

namespace ParallelLab {

    class Program {


        static void Main(string[] args) {

            const string source = @"c:\temp\images";
            const string dest = source + @"\thumbs";

            if (!Directory.Exists(dest)) {
                throw new InvalidOperationException($"Make sure that the '{dest}' folder exists");
            }

            var files = Directory.GetFiles(source, "*.jpg");

            Stopwatch sw = Stopwatch.StartNew();
            double totalFactor = 0;

            //foreach (var file in files) {
            //    var factor = GenerateThumbNail(file, dest, 800, 600);
            //    totalFactor += factor;
            //};

            var maxDegree = Math.Max(1, Environment.ProcessorCount / 2);

            var options = new ParallelOptions {
                MaxDegreeOfParallelism = maxDegree,
            };

            object lockObject = new object();
            Parallel.ForEach(files, options, file => {
                var factor = GenerateThumbNail(file, dest, 800, 600);
                lock (lockObject) {
                    totalFactor += factor;
                }
            });

            //var factors = new ConcurrentBag<double>();
            //Parallel.ForEach(files, options, file => {
            //    var factor = GenerateThumbNail(file, dest, 800, 600);
            //    factors.Add(factor);
            //});
            //double totalFactor = factors.Sum();

            //Task<double>[] tasks = new Task<double>[files.Length];
            //Semaphore semaphore = new Semaphore(initialCount: maxDegree, maximumCount: maxDegree);
            //for (int i = 0; i < files.Length; i++) {
            //    var file = files[i];
            //    tasks[i] = Task.Run(() => {
            //        semaphore.WaitOne();
            //        try {
            //            return GenerateThumbNail(file, dest, 800, 600);
            //        } finally {
            //            semaphore.Release();
            //        }
            //    });
            //}
            //Task.WaitAll(tasks);
            //double totalFactor = tasks.Sum(t => t.Result);

            //double totalFactor = files.AsParallel()
            //                          .WithDegreeOfParallelism(maxDegree)
            //                          .Sum(file => GenerateThumbNail(file, dest, 800, 600));

            sw.Stop();

            Console.WriteLine(totalFactor);
            Console.WriteLine(sw.Elapsed);
        }


        private static double GenerateThumbNail(string file, string dest, int width, int height) {
            using (System.Drawing.Image sourceImage = System.Drawing.Image.FromFile(file)) {
                using (System.Drawing.Image destImage = new Bitmap(width, height, sourceImage.PixelFormat)) {
                    using (Graphics graph = Graphics.FromImage(destImage)) {

                        graph.CompositingQuality = CompositingQuality.HighQuality;
                        graph.SmoothingMode = SmoothingMode.HighQuality;
                        graph.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        Rectangle oRectangle = new Rectangle(0, 0, width, height);
                        graph.DrawImage(sourceImage, oRectangle);
                        destImage.Save($"{dest}\\{Path.GetFileNameWithoutExtension(file)}.png", ImageFormat.Png);

                        return (double)sourceImage.Width / destImage.Width;
                    }
                }
            }
        }
    }
}
