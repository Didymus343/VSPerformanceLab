﻿// https://blogs.msdn.microsoft.com/maoni/2019/04/08/a-portable-way-to-get-gc-events-in-process-and-no-admin-privilege-with-10-lines-of-code-and-ability-to-dynamically-enable-disable-events/#comment-28015
// https://medium.com/criteo-labs/c-in-process-clr-event-listeners-with-net-core-2-2-ef4075c14e87

using System;
using System.Diagnostics;
using System.Diagnostics.Tracing;

namespace RuntimeEvents {
    public class GcEventListener : EventListener {

        private const int GCKeyword = 0x1;
        private const int GCStart = 1;
        private const int GCEnd = 2;

        private DateTime _timeGCStart;
        public TimeSpan TotalDuration { get; private set; }
        public long CountTotalEvents { get; private set; }

        protected override void OnEventSourceCreated(EventSource eventSource) {
            //Trace.WriteLine(eventSource.Name);
            if (eventSource.Name.Equals("Microsoft-Windows-DotNETRuntime")) {
                EnableEvents(eventSource, EventLevel.Informational, (EventKeywords)GCKeyword);
            }
        }

        protected override void OnEventWritten(EventWrittenEventArgs eventData) {
            if (eventData.EventId == GCStart) {
                _timeGCStart = eventData.TimeStamp;
            } else if (eventData.EventId == GCEnd) {
                var duration = eventData.TimeStamp - _timeGCStart;
                TotalDuration += duration;
                long gcIndex = long.Parse(eventData.Payload[0].ToString());
                Trace.WriteLine($"GC#{gcIndex.ToString()} took {duration}");
                CountTotalEvents++;
            }
        }

    }
}