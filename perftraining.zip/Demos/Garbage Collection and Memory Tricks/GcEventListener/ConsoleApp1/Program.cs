﻿// https://blogs.msdn.microsoft.com/maoni/2019/04/08/a-portable-way-to-get-gc-events-in-process-and-no-admin-privilege-with-10-lines-of-code-and-ability-to-dynamically-enable-disable-events/#comment-28015
// https://medium.com/criteo-labs/c-in-process-clr-event-listeners-with-net-core-2-2-ef4075c14e87

using System;
using System.Diagnostics;
using System.IO;

namespace RuntimeEvents {

    public class Program {

        static void Main(string[] args) {
            Allocate1();
            //Allocate2();

            using (var l = new GcEventListener()) {

                var sw = new Stopwatch();

                sw.Start();
                Allocate1();
                //Allocate2();
                sw.Stop();

                Console.WriteLine($"Duration {sw.ElapsedMilliseconds.ToString()}ms");
                Console.WriteLine($"GC Count = {l.CountTotalEvents.ToString()}");
                Console.WriteLine($"GC Duration= {l.TotalDuration.TotalMilliseconds.ToString()}ms");
                Console.WriteLine($"In GC = {(l.TotalDuration.TotalMilliseconds / sw.ElapsedMilliseconds).ToString("P2")}");
            }

            Console.ReadKey();
        }

        static void Allocate1() {
            for (int i = 0; i < 2_000_000; i++) {
                string s = "abc" + i;
                //string s = "abc" + i.ToString();
            }
        }

        static void Allocate2() {
            for (int i = 0; i < 100; i++) {
                Trace.WriteLine($"+Allocate {i.ToString()}");
                var x = new int[1_000_000];
                Trace.WriteLine($"-Allocate {i.ToString()}");
            }
        }

    }
}