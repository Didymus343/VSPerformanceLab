﻿using System;

namespace ConsoleApp28 {
    // Source: https://twitter.com/KooKiz/status/1067106037667430405 
    class Program {
        private static Action _action;

        static void Main(string[] args) {
            Foo();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            Console.ReadKey();
        }

        static void Foo() {
            var obj1 = new TrackedObject("Obj1");
            var obj2 = new TrackedObject("Obj2");
            Ephemeral(() => Console.WriteLine($"Ephemeral  {obj1.Name} {obj2.Name}"));
            Persistent(() => Console.WriteLine($"Persistent {obj2.Name}"));

            //Bar(obj2);
            //void Bar(TrackedObject t) {
            //    Persistent(() => Console.WriteLine($"Persistent {t.Name}"));
            //}
        }

        private static void Ephemeral(Action action) => action();

        private static void Persistent(Action action) {
            _action = action;
            _action();
        }
    }



    public class TrackedObject {
        public string Name { get; }
        public TrackedObject(string name) {
            this.Name = name;
        }

        ~TrackedObject() => Console.WriteLine("Finalizing " + Name);

    }
}

