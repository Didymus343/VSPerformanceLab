﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Linq;

namespace StringReverse {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        private readonly string _text = new string('x', 4096);

        [Benchmark]
        public string ReverseWithLinq() {
            return new String(_text.Reverse().ToArray()); // 3 Allocations
        }

        [Benchmark]
        public string ReverseWithArrays() {
            var chars = new char[_text.Length]; // Allocation
            for (int src = 0, dst = _text.Length - 1; src < _text.Length; src++, dst--) {
                chars[dst] = _text[src];
            }
            return new string(chars); // Allocation
        }

        [Benchmark]
        public string ReverseWithArrayReverse() {
            var chars = _text.ToCharArray(); // Allocation
            chars.Reverse();
            return new string(chars); // Allocation
        }

        [Benchmark()]
        public unsafe string ReverseWithUnmanagedMemmory() {
            var revStr = new string(' ', _text.Length); // Allocation
            fixed (char* strPtr = _text)
            fixed (char* revStrPtr = revStr) {
                for (int src = 0, dst = _text.Length - 1; src < _text.Length; src++, dst--) {
                    revStrPtr[dst] = strPtr[src];
                }
            }
            return revStr;
        }

    }
}