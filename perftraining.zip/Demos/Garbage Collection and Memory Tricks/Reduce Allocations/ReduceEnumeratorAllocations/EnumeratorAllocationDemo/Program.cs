﻿var list = Enumerable.Range(1, 1000).Select(index => new Employee("Fons", index)).ToList();
var readonlyCollection = list.AsReadOnly();

for (int i = 0; i < 100_000; i++) {
    //var sum = list.Sum(emp => emp.Salary);
    var sum = Helpers.SumSalaryUsingIEnumerable(list);
    //var sum = Helpers.SumSalaryUsingList(list);
    //var sum = Helpers.SumSalaryUsingIList(list);

    //var sum = readonlyCollection.Sum(emp => emp.Salary);
    //var sum = Helpers.SumSalaryUsingIEnumerable(readonlyCollection);
    //var sum = Helpers.SumSalaryUsingReadonlyCollection(readonlyCollection);
    //var sum = Helpers.SumSalaryUsingIList(readonlyCollection);
}

//BenchmarkDotNet.Running.BenchmarkRunner.Run<BM>();
