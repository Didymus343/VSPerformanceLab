﻿public class Employee {
    public string? Name { get; set; }

    public decimal Salary { get; set; }


    public Employee(string? name, decimal salary) {
		this.Name = name;
		this.Salary = salary;
	}
}
