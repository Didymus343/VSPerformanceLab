﻿using System.Collections.ObjectModel;

public static class Helpers {

    public static decimal SumSalaryUsingIEnumerable(IEnumerable<Employee> source) {
        decimal total = 0;
        foreach (var emp in source) total += emp.Salary;
        return total;
    }

    public static decimal SumSalaryUsingList(List<Employee> source) {
        decimal total = 0;
        foreach (var emp in source) total += emp.Salary;
        return total;
    }

    public static decimal SumSalaryUsingIList(IList<Employee> source) {
        decimal total = 0;
        for (int i = 0; i < source.Count; i++) total += source[i].Salary;
        return total;
    }

    public static decimal SumSalaryUsingReadonlyCollection(ReadOnlyCollection<Employee> source) {
        decimal total = 0;
        foreach (var emp in source) total += emp.Salary;
        return total;
    }
}