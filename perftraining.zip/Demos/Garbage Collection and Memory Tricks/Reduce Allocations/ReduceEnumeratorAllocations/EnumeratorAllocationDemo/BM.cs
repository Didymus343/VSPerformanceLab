﻿using BenchmarkDotNet.Attributes;
using System.Collections.ObjectModel;

[ShortRunJob]
[MemoryDiagnoser(false)]
public class BM {

    private List<Employee> _list = null!;
    private ReadOnlyCollection<Employee> _readonlyCollection = null!;

    [GlobalSetup]
    public void Setup() {
        _list = Enumerable.Range(1, 1000).Select(index => new Employee("Fons", index)).ToList();
        _readonlyCollection = _list.AsReadOnly();
    }

    [Benchmark] public decimal ListLinq() => _list.Sum(static emp => emp.Salary);

    [Benchmark] public decimal ListIEnumerable() => Helpers.SumSalaryUsingIEnumerable(_list);

    [Benchmark] public decimal ListList() => Helpers.SumSalaryUsingList(_list);
    
    [Benchmark] public decimal ListIList() => Helpers.SumSalaryUsingIList(_list);

    [Benchmark] public decimal ReadOnlyCollectionLinq() => _readonlyCollection.Sum(static emp => emp.Salary);

    [Benchmark] public decimal ReadOnlyCollectionIEnumerable() => Helpers.SumSalaryUsingIEnumerable(_readonlyCollection);

    [Benchmark] public decimal ReadOnlyCollectionReadOnlyCollection() => Helpers.SumSalaryUsingReadonlyCollection(_readonlyCollection);

    [Benchmark] public decimal ReadOnlyCollectionIList() => Helpers.SumSalaryUsingIList(_readonlyCollection);

}