﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace ReduceTaskAllocations {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        [Benchmark]
        public async Task<int> Tasks() {
            int t = 0;
            for (int i = 0; i < 1000; i++) {
                t += await GetTaskAsync(i);
            }
            return t;
        }

        private async Task<int> GetTaskAsync(int i) {
            if (i % 100 == 0) {
                await Task.Delay(1);
                return i - 1000;
            } else {
                return i;
            }
        }

        [Benchmark]
        public async Task<int> ValueTasksOK() {
            int t = 0;
            for (int i = 0; i < 1000; i++) {
                t += await GetValueTaskAsync(i);
            }
            return t;
        }

        [Benchmark]
        public async Task<int> ValueTasksPerfect() {
            int t = 0;
            for (int i = 0; i < 1000; i++) {
                ValueTask<int> task = GetValueTaskAsync(i);
                int r = task.IsCompleted ? task.Result : await task.AsTask();
                t += r;
            }
            return t;
        }

        private async ValueTask<int> GetValueTaskAsync(int i) {
            if (i % 100 == 0) {
                await Task.Delay(1);
                return i - 1000;
            } else {
                return i;
            }
        }


        [Benchmark]
        public async Task<int> InlinedValueTasksOK() {
            int t = 0;
            for (int i = 0; i < 1000; i++) {
                t += await GetInlinedValueTaskAsync(i);
            }
            return t;
        }

        [Benchmark]
        public async Task<int> InlinedValueTasksPerfect() {
            int t = 0;
            for (int i = 0; i < 1000; i++) {
                ValueTask<int> task = GetInlinedValueTaskAsync(i);
                t += task.IsCompleted ? task.Result : await task.AsTask();
            }
            return t;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)] // super important!
        private ValueTask<int> GetInlinedValueTaskAsync(int i) {
            return i % 100 == 0 ? new ValueTask<int>(GetAsyncResult(i)) : new ValueTask<int>(i);
        }

        private async Task<int> GetAsyncResult(int i) {
            await Task.Delay(1);
            return i - 1000;
        }
    }
}
