﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo7 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {

            // C# 8.0 Static Local Function
            static bool Filter(int value, int n) {
                return value % n == 0;
            }

            return _list.Where(i => Filter(i, 2));
        }

    }


}
