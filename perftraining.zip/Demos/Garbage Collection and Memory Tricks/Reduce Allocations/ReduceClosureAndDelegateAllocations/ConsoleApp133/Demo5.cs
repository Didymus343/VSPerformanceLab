﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo5 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {

            // Local Function
            bool Filter(int value) {
                return value % 2 == 0;
            }

            // Delegate Inference
            return _list.Where(Filter);
        }

    }

}
