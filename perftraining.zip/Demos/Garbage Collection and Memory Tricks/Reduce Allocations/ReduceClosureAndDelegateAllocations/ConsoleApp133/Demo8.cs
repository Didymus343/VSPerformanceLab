﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo8 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {
            int n = 2;
            return _list.Where(i => i % n == 0);
        }

    }

}
