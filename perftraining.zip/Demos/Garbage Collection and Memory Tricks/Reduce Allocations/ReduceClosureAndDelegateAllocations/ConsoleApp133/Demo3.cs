﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo3 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {
            // Delegate Inference
            return _list.Where(Filter);

            //return _list.Where(new Func<int, bool>(Filter));
        }

        private static bool Filter(int value) {
            return value % 2 == 0;
        }
    }

}
