﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo0 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {
            return _list.Where(i => i % 2 == 0);
        }

    }

}
