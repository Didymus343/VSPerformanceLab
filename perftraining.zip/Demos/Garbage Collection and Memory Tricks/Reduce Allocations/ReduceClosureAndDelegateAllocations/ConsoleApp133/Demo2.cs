﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {

    class Demo2 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {
            return _list.Where(i => Filter(i));
        }

        // Static Filter method
        private static bool Filter(int value) {
            return value % 2 == 0;
        }
    }

}
