﻿using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp133 {
    class Demo6 {

        private readonly List<int> _list = Enumerable.Range(1, 1000).ToList();

        public IEnumerable<int> GetItems() {
            int n = 2;

            bool Filter(int value) {
                return value % n == 0;
            }

            return _list.Where(i => Filter(i));
        }
    }

}
