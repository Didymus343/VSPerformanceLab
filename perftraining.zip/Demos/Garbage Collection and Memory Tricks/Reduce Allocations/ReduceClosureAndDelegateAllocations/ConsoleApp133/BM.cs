﻿using BenchmarkDotNet.Attributes;
using System.Linq;

namespace ConsoleApp133 {

    [MemoryDiagnoser(displayGenColumns: false)]
    [RankColumn]
    [ShortRunJob]
    public class BM {
        private readonly Demo0 _demo0 = new Demo0();
        private readonly Demo1 _demo1 = new Demo1();
        private readonly Demo2 _demo2 = new Demo2(); 
        private readonly Demo3 _demo3 = new Demo3(); 
        private readonly Demo4 _demo4 = new Demo4();
        private readonly Demo5 _demo5 = new Demo5(); 
        private readonly Demo6 _demo6 = new Demo6(); 
        private readonly Demo7 _demo7 = new Demo7(); 
        private readonly Demo8 _demo8 = new Demo8();

        [Benchmark(Description = "Demo0 - Lambda")]
        public int Demo0() => _demo0.GetItems().Count();

        [Benchmark(Description = "Demo1 - Lambda with a non static function call")]
        public int Demo1() => _demo1.GetItems().Count();

        [Benchmark(Description = "Demo2 - Lambda with a static function call")]
        public int Demo2() => _demo2.GetItems().Count();

        [Benchmark(Description = "Demo3 - Delegate Inference to static function")]
        public int Demo3() => _demo3.GetItems().Count();

        [Benchmark(Description = "Demo4 - Lambda with Local Function call")]
        public int Demo4() => _demo4.GetItems().Count();

        [Benchmark(Description = "Demo5 - Delegate Inference to Local Function")]
        public int Demo5() => _demo5.GetItems().Count();

        [Benchmark(Description = "Demo6 - Local Function with Capture local variable")]
        public int Demo6() => _demo6.GetItems().Count();

        [Benchmark(Description = "Demo7 - Lambda with C# 8 Static Local Function call")]
        public int Demo7() => _demo7.GetItems().Count();

        [Benchmark(Description = "Demo8 - Lambda with Capture local variable")]
        public int Demo8() => _demo8.GetItems().Count();
    }

}
