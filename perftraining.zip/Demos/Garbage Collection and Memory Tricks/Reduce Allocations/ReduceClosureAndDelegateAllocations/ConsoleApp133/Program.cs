﻿using BenchmarkDotNet.Running;

namespace ConsoleApp133 {
    class Program {

        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

}
