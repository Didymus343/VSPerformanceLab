﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EventSubscribeBM {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
            //new BM().Shared2();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        [Params(false, true)]
        public bool MustFire;

        private Employee[] _employees;

        private EventHandler _shared2, _shared3;

        [GlobalSetup]
        public void Setup() {
            _employees = Enumerable.Range(1, 1000).Select(n => new Employee("Emp" + n.ToString(), n)).ToArray();
        }

        [Benchmark]
        public void Normal() {
            foreach (var emp in _employees) emp.SalaryChanged += this.Emp_SalaryChanged;
            Fire();
            foreach (var emp in _employees) emp.SalaryChanged -= this.Emp_SalaryChanged;
        }

        [Benchmark()]
        public void Shared1() {
            var eh = new EventHandler(Emp_SalaryChanged);
            foreach (var emp in _employees) emp.SalaryChanged += eh;
            Fire();
            foreach (var emp in _employees) emp.SalaryChanged -= eh;
            
        }

        [Benchmark(Baseline = true)]
        public void Shared2() {
            _shared2 = _shared2 ?? Emp_SalaryChanged;
            foreach (var emp in _employees) emp.SalaryChanged += _shared2;
            Fire();
            foreach (var emp in _employees) emp.SalaryChanged -= _shared2;
        }

        [Benchmark()]
        public void Shared3() {
            foreach (var emp in _employees) emp.SalaryChanged += SharedHandler3;
            Fire();
            foreach (var emp in _employees) emp.SalaryChanged -= SharedHandler3;
        }

        private EventHandler SharedHandler3 => _shared3 ?? (_shared3 = Emp_SalaryChanged);

        private void Fire() {
            if (MustFire) foreach (var emp in _employees) emp.Salary += 1;
        }

        private void Emp_SalaryChanged(object sender, EventArgs e) {}
    }

}
