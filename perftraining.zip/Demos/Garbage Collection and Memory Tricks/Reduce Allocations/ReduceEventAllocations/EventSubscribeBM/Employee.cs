﻿using System;

namespace EventSubscribeBM {

    internal class Employee {

        private double _salary;
        public string Name { get; set; }

        public event EventHandler SalaryChanged;

        public Employee(string name, double salary) {
            this.Name = name;
            this.Salary = salary;
        }

        public double Salary {
            get => _salary;
            set {
                _salary = value;
                OnSalaryChanged();
            }
        }

        protected virtual void OnSalaryChanged() => SalaryChanged?.Invoke(this, EventArgs.Empty);

        public void RaiseSalary(double percentage) => this.Salary += Salary * (percentage / 100);

        public override string ToString() => $"Employee Name = {this.Name}, Salary = {this.Salary.ToString()}";
    }

}
