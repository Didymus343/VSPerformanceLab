﻿using System;
using System.Collections.Generic;

namespace ConsoleApp244 {
    class Program {
        static void Main(string[] args) {
            var b = new Bank();
            b.Accounts.Add(new Account("RABO 123", 100));
            b.Accounts.Add(new Account("RABO 456", 100_000));
            b.Accounts.Add(new Account("RABO 678", 200_000));

            foreach (var item in b.GetLargeAccountsV1(50_000)) {
                Console.WriteLine(item);
            }
        }
    }

    public class Bank {

        public readonly List<Account> Accounts = new List<Account>();

        public IEnumerable<Account> GetLargeAccountsV1(decimal minBalance) {
            if (minBalance < 5000) {
                throw new ArgumentOutOfRangeException();
            }
            return Accounts.Where(a => a.Balance >= minBalance);
        }

        //public IEnumerable<Account> GetLargeAccountsV2(decimal minBalance) {
        //    if (minBalance < 5000) {
        //        throw new ArgumentOutOfRangeException();
        //    } else {
        //        return Accounts.Where(a => a.Balance >= minBalance);
        //    }
        //}

        //public IEnumerable<Account> GetLargeAccountsV3(decimal minBalance) {
        //    if (minBalance < 5000) {
        //        throw new ArgumentOutOfRangeException();
        //    }
        //    var min = minBalance;
        //    return Accounts.Where(a => a.Balance >= min);
        //}

        //public IEnumerable<Account> GetLargeAccountsV4(decimal minBalance) {
        //    if (minBalance < 5000) {
        //        throw new ArgumentOutOfRangeException();
        //    } else {
        //        var min = minBalance;
        //        return Accounts.Where(a => a.Balance >= min);
        //    }
        //}
    }

    public class Account {

        public string Number { get; }
        public decimal Balance { get; set; }

        public Account(string number, decimal balance) {
            this.Number = number;
            this.Balance = balance;
        }

        public override string ToString() {
            return $"No: {Number} = {this.Balance:C2}";
        }

    }

}
