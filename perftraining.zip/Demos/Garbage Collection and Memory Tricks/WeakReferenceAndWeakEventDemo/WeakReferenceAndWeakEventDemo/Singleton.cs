﻿using System;

namespace WeakReferenceAndWeakEventDemo {
    internal class Singleton {
        private Singleton() { }

        public static Singleton Instance { get; } = new Singleton();

        public event EventHandler? SomethingChanged;

        protected virtual void OnSomethingChanged() {
            SomethingChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
