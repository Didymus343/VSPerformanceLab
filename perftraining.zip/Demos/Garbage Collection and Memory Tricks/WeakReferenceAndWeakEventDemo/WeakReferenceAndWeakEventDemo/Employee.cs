﻿namespace WeakReferenceAndWeakEventDemo {

    internal class Employee {

        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Employee(string name, decimal salary) {
            this.Name = name;
            this.Salary = salary;

            Singleton.Instance.SomethingChanged += Current_SomethingChanged;
            
            //SingletonWithWeakEvents.Instance.SomethingChanged += Current_SomethingChanged;
        }

        private void Current_SomethingChanged(object? sender, EventArgs e) {
            // Some code
        }

        public override string ToString() => $"Employee Name = {Name}, Salary = {this.Salary}";
    }

}