﻿using WeakEvent;

namespace WeakReferenceAndWeakEventDemo {
    internal class SingletonWithWeakEvents {
        private SingletonWithWeakEvents() { }

        public static SingletonWithWeakEvents Instance { get; } = new SingletonWithWeakEvents();

        // NUGET: Install-Package ThomasLevesque.WeakEvent
        private readonly WeakEventSource<EventArgs> _somethingChanged = new WeakEventSource<EventArgs>();

        public event EventHandler<EventArgs> SomethingChanged {
            add { _somethingChanged.Subscribe(value); }
            remove { _somethingChanged.Unsubscribe(value); }
        }

        protected virtual void OnSomethingChanged() {
            _somethingChanged.Raise(this, EventArgs.Empty);
        }
    }
}
