﻿using System;
using System.Windows.Forms;

namespace WeakReferenceAndWeakEventDemo {
    public partial class Form1 : Form {

        private WeakReference? _weakEmployee;

        public Form1() {
            InitializeComponent();
        }

        private void ButtonNewEmployee_Click(object sender, EventArgs e) {
            Employee fons = new Employee("Fons", 2000);
            _weakEmployee = new WeakReference(fons);

            this.Text = fons.ToString();
        }

        private void ButtonIsAlive_Click(object sender, EventArgs e) {
            this.Text = _weakEmployee?.IsAlive.ToString();
        }

        private void ButtonGC_Collect_Click(object sender, EventArgs e) {
            GC.Collect();
            this.Text = "GC.Collect()";
        }
    }
}
