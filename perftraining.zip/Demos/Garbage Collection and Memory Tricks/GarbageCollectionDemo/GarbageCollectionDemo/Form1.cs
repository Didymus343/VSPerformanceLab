﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;

namespace GarbageCollectionDemo {
    public partial class Form1 : Form {

        private readonly List<Employee> _employeeList = new List<Employee>();

        private readonly byte[] _data = new byte[85_000];   // 85_000
        //private readonly int[] _data = new int[21_000];     // 22_000
        //private readonly double[] _data = new double[1000]; // 1000

        //private readonly Employee[] _data = new Employee[21_000]; // 22000 (32Bit)
        //private readonly Employee[] _data = new Employee[10_500]; // 11000 (64Bit)

        public Form1() {
            InitializeComponent();
            UpdateStatus();
        }

        private void Button1_Click(object sender, EventArgs e) {
            for (var i = 0; i < 10_000; i++) {
                _employeeList.Add(new Employee("Fons", 2000));
            }
            UpdateStatus();
        }

        private void Button2_Click(object sender, EventArgs e) {
            _employeeList.Clear();
            UpdateStatus();
        }

        private void Button3_Click(object sender, EventArgs e) {
            //GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
            GC.Collect();
            UpdateStatus();
        }

        private void UpdateStatus() {
            var txt = $"Employees: {_employeeList.Count.ToString("N0")}\r\n" +
                $"Capacity: {_employeeList.Capacity.ToString("N0")}\r\n" +
                $"Memory: {GC.GetTotalMemory(false).ToString("N0")}\r\n";

            var dict = new Dictionary<int, int>() {
                [0] = 0,
                [1] = 0,
                [2] = 0,
            };
            foreach (var item in _employeeList) {
                dict[GC.GetGeneration(item)] += 1;
            }

            txt += $"Employees in Gen 0: {dict[0].ToString("N0")}\r\n" +
                   $"Employees in Gen 1: {dict[1].ToString("N0")}\r\n" +
                   $"Employees in Gen 2: {dict[2].ToString("N0")}\r\n";

            txt += $"List<Employee> Generation {GC.GetGeneration(_employeeList)}\r\n";
            txt += $"{_data.GetType().Name.Replace("]", string.Empty)}{_data.Length}] Generation {GC.GetGeneration(_data)}\r\n";
            
            for (int index = 0; index <= GC.MaxGeneration; index++) {
                txt += $"Gen {index} collections: {GC.CollectionCount(index)}\r\n";
            }

            label1.Text = txt;
        }

        private void Button4_Click(object sender, EventArgs e) {
            double t = 0;
            for (var i = 0; i < 10_000; i++) {
                var emp = new Employee("Fons", 2000);
                t += emp.Salary;
            }
            Debug.WriteLine(t);
            UpdateStatus();
        }

        private void Button5_Click(object sender, EventArgs e) {
            for (var i = 0; i < 1000; i++) {
                Button1_Click(null, null);
                _employeeList.Clear();
            }
            UpdateStatus();
        }
    }
}
