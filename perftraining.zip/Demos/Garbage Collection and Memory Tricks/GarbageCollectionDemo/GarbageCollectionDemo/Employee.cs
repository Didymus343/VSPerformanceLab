﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectionDemo {

    internal class Employee {

        public string Name { get; set; }
        public double Salary { get; set; }
        //public decimal[] Data { get; } = new decimal[100];

        public Employee(string name, double salary) {
            this.Name = name;
            this.Salary = salary;
        }

        public void RaiseSalary(double percentage) {
            this.Salary += Salary * (percentage / 100);
        }

        public override string ToString() {
            return string.Format("Employee Name = {0}, Salary = {1}", this.Name, this.Salary);
        }
    }

}
