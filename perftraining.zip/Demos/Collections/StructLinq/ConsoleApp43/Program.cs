﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using StructLinq;

namespace ConsoleApp43 {
    class Program {
        static void Main(string[] args) {
            //BenchmarkRunner.Run<BM>();

            int[] array = new[] { 1, 2, 3, 4, 5 };

            // Normal LINQ
            int result1 = array.Where(x => (x & 1) == 0)
                                .Select(x => x * 2)
                                .Sum();

            // StuctLinq with delegate => allocatons
            int result2 = array.ToStructEnumerable()
                                .Where(x => (x & 1) == 0, x => x)
                                .Select(x => x * 2, x => x)
                                .Sum(x => x);

            // StuctLinq no allocatons
            var where = new IsEvenPredicate();
            var select = new DoubleSelectPredicate();

            int result3 = array.ToStructEnumerable()
                                .Where(ref @where, x => x)
                                .Select(ref @select, x => x, x => x)
                                .Sum();

            Console.WriteLine(result1); // 12 = (2 * 2) + (4 * 2)
            Console.WriteLine(result2); // 12 = (2 * 2) + (4 * 2)
            Console.WriteLine(result3); // 12 = (2 * 2) + (4 * 2)
        }
    }

    struct IsEvenPredicate : IFunction<int, bool> {

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public readonly bool Eval(int x) {
            return (x & 1) == 0;
        }
    }

    struct DoubleSelectPredicate : IFunction<int, int> {

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public readonly int Eval(int x) {
            return x * 2;
        }
    }

    [MemoryDiagnoser]
    public class BM {

        private readonly int[] _list = new int[20_000];

        [GlobalSetup]
        public void Setup() {
            for (int i = 0; i < _list.Length; i++) _list[i] = (i % 20);
            var rnd = new Random(2000);
            for (int i = 0; i < _list.Length; i++) {
                var idx = rnd.Next(0, _list.Length);
                (_list[i], _list[idx]) = (_list[idx], _list[i]);
            }
        }

        [Benchmark]
        public int Linq() => _list.Where(x => (x & 1) == 0).Select(x => x * 2).Sum();

        [Benchmark]
        public int StructLinqWithDelegates() => _list.ToStructEnumerable().Where(x => (x & 1) == 0, x => x).Select(x => x * 2, x => x).Sum();

        [Benchmark(Baseline = true)]
        public int StructLinqNoAllocations() {
            var filter = new IsEvenPredicate();
            var selector = new DoubleSelectPredicate();
            return _list.ToStructEnumerable().Where(ref filter, x => x).Select(ref selector, x => x, x => x).Sum(x => x);
        }
    }

}
