﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;

namespace RightCollection {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    //[MemoryDiagnoser]
    public class BM {

        private static readonly Random _random = new Random();
        private int[] _array, _sortedArray;
        private HashSet<int> _hashSet;
        private int _value;

        [Params(1000, 100_000)]
        public int N;

        [GlobalSetup]
        public void Setup() {
            _array = new int[N];
            _sortedArray = new int[N];
            _hashSet = new HashSet<int>(N);
            for (int i = 0; i < N; i++) {
                var v = _random.Next(1000);
                _array[i] = v = _sortedArray[i] = v;
                _hashSet.Add(v);
            }
            Array.Sort(_sortedArray);
            _value = _sortedArray[N / 2];
        }

        [Benchmark]
        public bool SearchArrayUsingIndexOf() => Array.IndexOf(_array, _value) != -1;

        [Benchmark]
        public bool SearchSortedArrayUsingBinarySearch() => Array.BinarySearch(_sortedArray, _value) != -1;

        [Benchmark(Baseline = true)]
        public bool SearchHashSetUsingContains() => _hashSet.Contains(_value);

        [Benchmark]
        public bool SortAndSearchArrayUsingBinarySearch() {
            Array.Sort(_array); // Must be sorted otherwise Array.BinarySearch() may work incorrect
            return Array.BinarySearch(_array, _value) != -1;
        }
    }
}
