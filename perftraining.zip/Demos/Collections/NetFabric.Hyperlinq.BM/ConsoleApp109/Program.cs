﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using NetFabric.Hyperlinq;
using System;
using System.Collections.Generic;
//using System.Linq;

namespace ConsoleApp109 {

    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        private List<int> _l = Enumerable.Range(1, 1000).ToList();


        [Benchmark] // Copy
        public int Linq() => System.Linq.Enumerable.Count(_l, n => n > 200);

        [Benchmark(Baseline = true)]
        public int Hyperlinq() => _l.Count(n => n > 200);

        [Benchmark]
        public int LinqWithClosure() => this.Linq(200);

        [Benchmark]
        public int HyperlinqWithClosure() => this.Hyperlinq(200);

        [Benchmark]
        public int HyperlinqWithLocalFunction() => this.HyperlinqLF(200);

        private int Linq(int limit) => System.Linq.Enumerable.Count(_l, n => n > limit);

        public int Hyperlinq(int limit) => _l.Count(n => n > limit);

        public int HyperlinqLF(int limit) {
            bool Filter(int n) => n > limit;
            return this._l.Count(Filter);
        }
    }
}
