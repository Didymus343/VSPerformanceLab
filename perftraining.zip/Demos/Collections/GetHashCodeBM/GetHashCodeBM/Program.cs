﻿// https://docs.microsoft.com/en-us/dotnet/api/system.object.gethashcode?view=netframework-4.7.2

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;

#if RELEASE
BenchmarkRunner.Run<HashSetBM>();
//BenchmarkRunner.Run<RandomXY_BM>();
#else
var dict = new Dictionary<int, int>();
var random = new Random(2000);
for (int i = 0; i < 10_000; i++) {
    int hashcode = new PointFrameworkJetBrains(i, i).GetHashCode();
    //int hashcode = new PointFrameworkJetBrains(random.Next(100), random.Next(100)).GetHashCode();
    if (dict.ContainsKey(hashcode)) {
        dict[hashcode]++;
    } else {
        dict.Add(hashcode, 1);
    }
}
foreach (var item in dict) {
    Console.WriteLine($"{item.Key} = {item.Value}");
}
Console.WriteLine();
Console.WriteLine(dict.Count);
#endif

[RankColumn]
[TrendRatioStyleConfig]
//[ShortRunJob]
public class HashSetBM {

    const int Size = 10000;

    [Benchmark]
    public HashSet<PointXor> Xor() {
        var hs = new HashSet<PointXor>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointXor(i, i));
        return hs;
    }

    [Benchmark]
    public HashSet<PointFrameworkJetBrains> FrameworkJetBrains() {
        var hs = new HashSet<PointFrameworkJetBrains>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointFrameworkJetBrains(i, i));
        return hs;
    }

    [Benchmark]
    public HashSet<PointFrameworkVS> FrameworkVisualStudio() {
        var hs = new HashSet<PointFrameworkVS>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointFrameworkVS(i, i));
        return hs;
    }

    [Benchmark]
    public HashSet<PointHashCodeCombine> HashCodeCombine() {
        var hs = new HashSet<PointHashCodeCombine>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointHashCodeCombine(i, i));
        return hs;
    }

    [Benchmark(Baseline = true)]
    public HashSet<PointRecord> Record() {
        var hs = new HashSet<PointRecord>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointRecord(i, i));
        return hs;
    }

    [Benchmark]
    public HashSet<PointValueTuple> ValueTuple() {
        var hs = new HashSet<PointValueTuple>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointValueTuple(i, i));
        return hs;
    }

    [Benchmark]
    public HashSet<PointShiftAndWrap> ShiftAndWrap() {
        var hs = new HashSet<PointShiftAndWrap>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointShiftAndWrap(i, i));
        return hs;
    }
}

/// <summary>
/// GetHashCode using X ^ Y
/// </summary>
public readonly struct PointXor : IEquatable<PointXor> {

    public readonly int X;
    public readonly int Y;

    public PointXor(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointXor other) =>
        this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() => X ^ Y;
}

/// <summary>
/// Resharper/Rider generated GetHashCode() for .NET Framework projects
/// </summary>
public readonly struct PointFrameworkJetBrains : IEquatable<PointFrameworkJetBrains> {

    public readonly int X;
    public readonly int Y;

    public PointFrameworkJetBrains(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointFrameworkJetBrains other) =>
        this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() {
        unchecked { return (X * 397) ^ (Y * 397); }
    }
}

/// <summary>
/// Visual Studio generated GetHashCode() for .NET Framework projects
/// </summary>
public readonly struct PointFrameworkVS : IEquatable<PointFrameworkVS> {

    public readonly int X;
    public readonly int Y;

    public PointFrameworkVS(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointFrameworkVS other) =>
        this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() {
        var hashCode = 1861411795;
        hashCode = hashCode * -1521134295 + this.X.GetHashCode();
        hashCode = hashCode * -1521134295 + this.Y.GetHashCode();
        return hashCode;
    }
}

/// <summary>
/// HashCode.Combine() GetHashCode() for .NET (Core) projects
/// </summary>
public readonly struct PointHashCodeCombine : IEquatable<PointHashCodeCombine> {

    public readonly int X;
    public readonly int Y;

    public PointHashCodeCombine(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointHashCodeCombine other) => this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() => HashCode.Combine(X, Y);
}

/// <summary>
/// ValueTuple GetHashCode()
/// </summary>
public readonly struct PointValueTuple : IEquatable<PointValueTuple> {

    public readonly int X;
    public readonly int Y;

    public PointValueTuple(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointValueTuple other) => this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() => (X, Y).GetHashCode();

}

/// <summary>
/// Example from: https://learn.microsoft.com/en-us/dotnet/api/system.object.gethashcode?view=net-7.0#examples
/// </summary>
public readonly struct PointShiftAndWrap : IEquatable<PointShiftAndWrap> {

    public readonly int X;
    public readonly int Y;

    public PointShiftAndWrap(int x, int y) {
        this.X = x;
        this.Y = y;
    }

    public bool Equals(PointShiftAndWrap other) => this.X == other.X && this.Y == other.Y;

    public override int GetHashCode() => ShiftAndWrap(X.GetHashCode(), 2) ^ Y.GetHashCode();

    private int ShiftAndWrap(int value, int positions) {
        positions = positions & 0x1F;

        // Save the existing bit pattern, but interpret it as an unsigned integer.
        uint number = BitConverter.ToUInt32(BitConverter.GetBytes(value), 0);
        // Preserve the bits to be discarded.
        uint wrapped = number >> (32 - positions);
        // Shift and wrap the discarded bits.
        return BitConverter.ToInt32(BitConverter.GetBytes((number << positions) | wrapped), 0);
    }
}

/// <summary>
/// C# 10 record struct
/// </summary>
public readonly record struct PointRecord {

    public readonly int X;
    public readonly int Y;

    public PointRecord(int x, int y) {
        this.X = x;
        this.Y = y;
    }
}


class TrendRatioStyleConfigAttribute : ConfigAttribute {

    public TrendRatioStyleConfigAttribute() : base(typeof(TrendRatioStyleConfig)) {
    }

    private class TrendRatioStyleConfig : ManualConfig {

        public TrendRatioStyleConfig() {
            SummaryStyle = SummaryStyle.Default.WithRatioStyle(RatioStyle.Trend);
        }
    }

}

[RankColumn]
[TrendRatioStyleConfig]
[ShortRunJob]
public class RandomXY_BM {

    private const int Size = 10000;
    private Random _random;

    [GlobalSetup]
    public void Setup() => _random = new Random(2000);

    [Benchmark]
    public HashSet<PointXor> Xor() {
        var hs = new HashSet<PointXor>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointXor(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark]
    public HashSet<PointFrameworkJetBrains> FrameworkJetBrains() {
        var hs = new HashSet<PointFrameworkJetBrains>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointFrameworkJetBrains(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark]
    public HashSet<PointFrameworkVS> FrameworkVisualStudio() {
        var hs = new HashSet<PointFrameworkVS>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointFrameworkVS(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark]
    public HashSet<PointHashCodeCombine> HashCodeCombine() {
        var hs = new HashSet<PointHashCodeCombine>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointHashCodeCombine(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark(Baseline = true)]
    public HashSet<PointRecord> Record() {
        var hs = new HashSet<PointRecord>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointRecord(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark]
    public HashSet<PointValueTuple> ValueTuple() {
        var hs = new HashSet<PointValueTuple>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointValueTuple(_random.Next(100), _random.Next(100)));
        return hs;
    }

    [Benchmark]
    public HashSet<PointShiftAndWrap> ShiftAndWrap() {
        var hs = new HashSet<PointShiftAndWrap>(capacity: Size);
        for (int i = 0; i < Size; i++) hs.Add(new PointShiftAndWrap(_random.Next(100), _random.Next(100)));
        return hs;
    }
}