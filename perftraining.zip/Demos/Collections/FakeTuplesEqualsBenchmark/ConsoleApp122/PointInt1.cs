﻿using System;

namespace ConsoleApp122 {
    readonly struct PointInt1 : IEquatable<PointInt1> {

        public int X { get; }
        public int Y { get; }
        public PointInt1(int x, int y) : this() {
            this.X = x;
            this.Y = y;
        }

        public override bool Equals(object obj) {
            return obj is PointInt1 && this.Equals((PointInt1)obj);
        }

        public bool Equals(PointInt1 other) {
            return this.X == other.X &&
                   this.Y == other.Y;
        }

        public override int GetHashCode() {
            var hashCode = 1861411795;
            hashCode = hashCode * -1521134295 + this.X.GetHashCode();
            hashCode = hashCode * -1521134295 + this.Y.GetHashCode();
            return hashCode;
        }
    }
}

