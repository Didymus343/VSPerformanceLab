﻿using System;

namespace ConsoleApp122 {
    readonly struct PointInt2 : IEquatable<PointInt2> {

        public int X { get; }
        public int Y { get; }
        public PointInt2(int x, int y) : this() {
            this.X = x;
            this.Y = y;
        }

        public override bool Equals(object obj) => obj is PointInt2 && this.Equals((PointInt2)obj);

        public bool Equals(PointInt2 other) => (this.X, this.Y) == (other.X, other.Y);

        public override int GetHashCode() => (this.X, this.Y).GetHashCode();

    }
}

