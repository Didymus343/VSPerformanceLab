﻿using System;

namespace ConsoleApp122 {
    readonly struct PointInt3 : IEquatable<PointInt3> {

        public int X { get; }
        public int Y { get; }
        public PointInt3(int x, int y) : this() {
            this.X = x;
            this.Y = y;
        }

        public override bool Equals(object obj) => obj is PointInt3 && this.Equals((PointInt3)obj);

        public bool Equals(PointInt3 other) => (this.X, this.Y) == (other.X, other.Y);

        public override int GetHashCode() => HashCode.Combine(this.X, this.Y);

    }
}

