﻿using System;

namespace ConsoleApp122 {
    readonly struct PointDouble1 : IEquatable<PointDouble1> {

        public double X { get; }
        public double Y { get; }
        public double Z { get; }
        public PointDouble1(double x, double y, double z) : this() {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public override bool Equals(object obj) {
            return obj is PointDouble1 && this.Equals((PointDouble1)obj);
        }

        public bool Equals(PointDouble1 other) {
            return this.X == other.X &&
                   this.Y == other.Y;
        }

        public override int GetHashCode() {
            var hashCode = 1861411795;
            hashCode = hashCode * -1521134295 + this.X.GetHashCode();
            hashCode = hashCode * -1521134295 + this.Y.GetHashCode();
            hashCode = hashCode * -1521134295 + this.Z.GetHashCode();
            return hashCode;
        }
    }
}

