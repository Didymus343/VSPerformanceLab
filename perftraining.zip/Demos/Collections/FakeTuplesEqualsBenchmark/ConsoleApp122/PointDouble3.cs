﻿using System;

namespace ConsoleApp122 {
    readonly struct PointDouble3 : IEquatable<PointDouble3> {

        public double X { get; }
        public double Y { get; }
        public double Z { get; }

        public PointDouble3(double x, double y, double z) : this() {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public override bool Equals(object obj) => obj is PointDouble3 && this.Equals((PointDouble3)obj);

        public bool Equals(PointDouble3 other) => (this.X, this.Y, this.Z) == (other.X, other.Y, other.Z);

        public override int GetHashCode() => HashCode.Combine(this.X, this.Y, this.Z);

    }
}

