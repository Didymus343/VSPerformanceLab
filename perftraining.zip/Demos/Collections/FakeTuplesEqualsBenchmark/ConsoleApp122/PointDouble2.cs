﻿using System;

namespace ConsoleApp122 {
    readonly struct PointDouble2 : IEquatable<PointDouble2> {

        public double X { get; }
        public double Y { get; }
        public double Z { get; }

        public PointDouble2(double x, double y, double z) : this() {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public override bool Equals(object obj) => obj is PointDouble2 && this.Equals((PointDouble2)obj);

        public bool Equals(PointDouble2 other) => (this.X, this.Y, this.Z) == (other.X, other.Y, other.Z);

        public override int GetHashCode() => (this.X, this.Y, this.Z).GetHashCode();

    }
}

