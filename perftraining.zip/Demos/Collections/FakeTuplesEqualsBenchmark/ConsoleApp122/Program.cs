﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System.Linq;

namespace ConsoleApp122 {

    internal class Program {
        private static void Main(string[] args) {
            //BenchmarkRunner.Run<TestEquals>();
            //BenchmarkRunner.Run<TestIntGetHashCode>();
            BenchmarkRunner.Run<TestDoubleGetHashCode>();
        }
    }

    public class TestEquals {

        private readonly PointInt1 _p1a = new PointInt1(0, 2);
        private readonly PointInt1[] _a1 = new PointInt1[1000];

        private readonly PointInt2 _p2a = new PointInt2(0, 2);
        private readonly PointInt2[] _a2 = new PointInt2[1000];

        [Benchmark(Baseline = true)]
        public bool EqualsCompare() {
            //return p1a.Equals(p1b);
            var b = true;
            foreach (var item in this._a1) {
                b = b & item.Equals(this._p1a);
            }
            return b;
        }

        [Benchmark]
        public bool EqualsFakeTuples() {
            //return p2a.Equals(p2b);
            var b = true;
            foreach (var item in this._a2) {
                b = b & item.Equals(this._p2a);
            }
            return b;
        }

    }

    [MemoryDiagnoser]
    public class TestIntGetHashCode {

        private readonly PointInt1[] _a1 = Enumerable.Range(-500, 1000).Select(n => new PointInt1(n, n * 2)).ToArray();
        private readonly PointInt2[] _a2 = Enumerable.Range(-500, 1000).Select(n => new PointInt2(n, n * 2)).ToArray();
        private readonly PointInt3[] _a3 = Enumerable.Range(-500, 1000).Select(n => new PointInt3(n, n * 2)).ToArray();

        [Benchmark(Baseline = true)]
        public int TestCalc() {
            int retVal = 0;
            foreach (var item in this._a1) {
                retVal = item.GetHashCode();
            }
            return retVal;
        }

        [Benchmark]
        public int TestTuples() {
            int retVal = 0;
            foreach (var item in this._a2) {
                retVal = item.GetHashCode();
            }
            return retVal;
        }

        [Benchmark]
        public int TestHashCode_Combine() {
            int retVal = 0;
            foreach (var item in this._a3) {
                retVal = item.GetHashCode();
            }
            return retVal;
        }

    }

    [MemoryDiagnoser]
    public class TestDoubleGetHashCode {

        private readonly PointDouble1[] _a1 = Enumerable.Range(-500, 1000).Select(n => new PointDouble1(n, n * 2, -n)).ToArray();
        private readonly PointDouble2[] _a2 = Enumerable.Range(-500, 1000).Select(n => new PointDouble2(n, n * 2, -n)).ToArray();
        private readonly PointDouble3[] _a3 = Enumerable.Range(-500, 1000).Select(n => new PointDouble3(n, n * 2, -n)).ToArray();

        [Benchmark(Baseline = true)]
        public int TestCalc() {
            int retVal = 0;
            foreach (var item in this._a1) {
                retVal = item.GetHashCode();
            }
            return retVal;
        }

        [Benchmark]
        public int TestTuples() {
            int retVal = 0;
            foreach (var item in this._a2) {
                retVal = item.GetHashCode();
            }
            return retVal;

        }

        [Benchmark]
        public int TestHashCode_Combine() {
            int retVal = 0;
            foreach (var item in this._a3) {
                retVal = item.GetHashCode();
            }
            return retVal;
        }

    }
}

