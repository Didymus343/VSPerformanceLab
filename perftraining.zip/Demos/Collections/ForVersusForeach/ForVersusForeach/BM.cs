﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;

[MemoryDiagnoser(false)]
[HideColumns("Job", "Alloc Ratio", "Ratio SD")]
[ShortRunJob(runtimeMoniker: RuntimeMoniker.Net48)]
[ShortRunJob(runtimeMoniker: RuntimeMoniker.Net70)]
[ShortRunJob(runtimeMoniker: RuntimeMoniker.Net80)]
public class BM {

    private string[] _array = null!;
    private List<string> _list = null!;

    [GlobalSetup]
    public void Setup() {
        _array = Enumerable.Range(1, 4096).Select(i => i.ToString()).ToArray();
        _list = _array.ToList();
        _list.TrimExcess();
    }

    [Benchmark(Baseline = true)]
    public int ArrayForLoop() {
        int total = 0;
        for (var i = 0; i < _array.Length; i++) total += this._array[i].Length;
        return total;
    }

    [Benchmark]
    public int ArrayForeachLoop() {
        int total = 0;
        foreach (var text in _array) total += text.Length;
        return total;
    }

    [Benchmark]
    public int ArrayLinqSum() => _array.Sum(static text => text.Length);

    [Benchmark]
    public int ListForLoop() {
        int total = 0;
        for (var i = 0; i < _list.Count; i++) total += _list[i].Length;
        return total;
    }

    [Benchmark]
    public int ListForeachLoop() {
        int total = 0;
        foreach (var text in _list) total += text.Length;
        return total;
    }

    [Benchmark]
    public int ListForEach() {
        int total = 0;
        _list.ForEach(text => total += text.Length);
        return total;
    }

    [Benchmark]
    public int ListLinqSum() => _list.Sum(static text => text.Length);

}


