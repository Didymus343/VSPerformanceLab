﻿using BenchmarkDotNet.Running;

BenchmarkRunner.Run<BM>();

