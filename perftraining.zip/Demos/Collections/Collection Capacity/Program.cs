﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Collection_Capacity {
    class Program {
        static void Main(string[] args) {

            //List<long> l = new List<long>(); // Initial Capacity 4 (4 * 8 bytes = 32 bytes)
            //var sw = Stopwatch.StartNew();
            //for (int i = 0; i < 100000; i++) {
            //    l.Add(42); // Resize 4 -> 8 -> 16 -> 32 -> 64 -> 128 -> 256 -> 512 -> 1K -> 2K -> 4K -> 8K -> 
            //               // 16K (LOH) -> 32K (LOH) -> 64K (LOH) => 128K (LOH)
            //}

            //sw.Stop();
            //Console.WriteLine(sw.Elapsed.ToString());
            ////Console.WriteLine(l.Capacity / 1024);

            //l = new List<long>(100000);
            //GC.Collect();
            //sw = Stopwatch.StartNew();

            //for (int i = 0; i < 100000; i++) {
            //    l.Add(42);
            //}

            //sw.Stop();
            //Console.WriteLine(sw.Elapsed.ToString());

            BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        [Benchmark]
        public List<long> WithoutCapacity() {
            List<long> l = new List<long>(); // Initial Capacity 4 (4 * 8 bytes = 32 bytes)
            for (int i = 0; i < 100000; i++) {
                l.Add(42); // Resize 4 -> 8 -> 16 -> 32 -> 64 -> 128 -> 256 -> 512 -> 1K -> 2K -> 4K -> 8K -> 
                           // 16K (LOH) -> 32K (LOH) -> 64K (LOH) => 128K (LOH)
            }
            return l;
        }

        [Benchmark(Baseline = true)]
        public List<long> WithCapacity() {
            List<long> l = new List<long>(100000); 
            for (int i = 0; i < 100000; i++) {
                l.Add(42); 
            }
            return l;
        }

        [Benchmark()]
        public List<long> WithOverCapacity() {
            List<long> l = new List<long>(110000);
            for (int i = 0; i < 100000; i++) {
                l.Add(42);
            }
            l.TrimExcess();
            return l;
        }

    }
}
