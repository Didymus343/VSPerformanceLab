﻿using System;

namespace ReadonlySpanDemo {
    class Program {
        static void Main(string[] args) {
            Foo();
            Console.WriteLine();
            Bar();
        }

        private static void Foo() {
            string s = "Hello World";
            //string s = "Hello World?";

            var first = s.Substring(0, length: 5);
            var second = s.Substring(6);

            Console.WriteLine(IsCSharpIdentifier(first));
            Console.WriteLine(IsCSharpIdentifier(second));
        }

        static bool IsCSharpIdentifier(string value) {
            if (value.Length == 0) {
                return false;
            }
            if (char.IsNumber(value[0])) {
                return false;
            }
            for (var i = 0; i < value.Length; i++) {
                char c = value[i];
                if (!(char.IsLetterOrDigit(c) || c == '_')) {
                    return false;
                }
            }
            return true;
        }


        private static void Bar() {
            ReadOnlySpan<char> s = "Hello World".AsSpan();
            //ReadOnlySpan<char> s = "Hello World?".AsSpan();
            var first = s.Slice(0, length: 5);
            var second = s.Slice(6);

            Console.WriteLine(IsCSharpIdentifier(first));
            Console.WriteLine(IsCSharpIdentifier(second));
        }

        static bool IsCSharpIdentifier(ReadOnlySpan<char> value) {
            if (value.Length == 0) {
                return false;
            }
            if (char.IsNumber(value[0])) {
                return false;
            }
            for (var i = 0; i < value.Length; i++) {
                char c = value[i];
                if (!(char.IsLetterOrDigit(c) || c == '_')) {
                    return false;
                }
            }
            return true;
        }

    }
}
