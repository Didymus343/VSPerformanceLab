﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using Microsoft.Toolkit.HighPerformance.Buffers;
using Microsoft.Toolkit.HighPerformance.Enumerables;
using Microsoft.Toolkit.HighPerformance.Extensions;
using Microsoft.Toolkit.HighPerformance.Helpers;
using System;
using System.Threading.Tasks;

namespace ToolkitHighPerformanceBM {
    class Program {
        static void Main(string[] args) {
            //BenchmarkRunner.Run<ParallelBM>();
            BenchmarkRunner.Run<StringPoolBM>();

            //var x = new StringPoolBM();
            //foreach (var item in x.StringSplit()) {
            //foreach (var item in x.UsingStringPool()) {
            //    Console.WriteLine(item);
            //}
        }
    }

    [MemoryDiagnoser]
    [SimpleJob(RuntimeMoniker.Net48)]
    [SimpleJob(RuntimeMoniker.NetCoreApp31)]
    public class StringPoolBM {

        private readonly string _input = "Bla Bli Bli Bla Bla Bli Bla Bli Bli " +
            "Bla Bla Bli Bli Bla Bla Bli Bla Bli Bli Bla Bla Bli Bli Bla Bla Bli " +
            "Bli Bla Bli Bla Bla Bla Bli Bla Bli Bli Bla Bla Bli Bli Bla Bla Bli " +
            "Bla Bla Bli Bli Bla Bla Bli Bla Bli Bli Bla Bla Bli Bli Bla Bla Bli " +
            "Bla Bli Bli Bli Bla Bla Bli Bla Bli Bli Bla Bla Bli Bli Bli Bla Bli " +
            "Bla Bli Bli Bla Bla Bli Bli Bla Bla Bli Bli Bla Bla Bli Bla Bli Bli " +
            "Bla Bla Bli Bla Bli Bli Bla";

        [Benchmark]
        public string[] UsingStringSplit() => _input.Split(' ');

        [Benchmark]
        public string[] UsingStringPool() {
            var span = _input.AsSpan();

            // Count the number of spaces and create the correct size array
            var array = new string[span.Count(' ') + 1];

            // Spit the span in words. GetOrAdd each word from the StringPool 
            // and store it in the array
            int index = 0;
            foreach (var word in span.Tokenize(' ')) {
                array[index++] = StringPool.Shared.GetOrAdd(word);
            }
            return array;
        }
    }

    [MemoryDiagnoser]
    public class ParallelBM {

        private double[] _array;

        [Params(10_000, 100_000, 1_000_000)]
        public int Size;

        [GlobalSetup]
        public void Setup() => _array = new double[Size];

        [Benchmark]
        public void SingleThreaded() {
            for (int i = 0; i < _array.Length; i++) _array[i] += 2;
        }

        [Benchmark]
        public void Parallel_For() => Parallel.For(0, _array.Length, i => _array[i] += 2);

        [Benchmark(Baseline = true)]
        public void ParallelHelper_ForEach() => ParallelHelper.ForEach<double, AddTwo>(_array);

        private readonly struct AddTwo : IRefAction<double> {
            public void Invoke(ref double x) => x += 2;
        }
    }




}
