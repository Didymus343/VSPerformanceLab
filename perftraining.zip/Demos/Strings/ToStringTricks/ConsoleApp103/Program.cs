﻿// Branchmark for https://www.meziantou.net/2019/03/04/some-performance-tricks-with-net-strings

using System;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

namespace BranchmarkString {

    [CoreJob]
    [MemoryDiagnoser]
    //[DisassemblyDiagnoser(printAsm: true, printSource: true)]
    [RankColumn]
    public class BM {
        private static readonly string _encode32Chars =      "0123456789ABCDEFGHIJKLMNOPQRSTUV";
        private static readonly char[] _encode32CharsArray = "0123456789ABCDEFGHIJKLMNOPQRSTUV".ToCharArray();

        public long Id = DateTime.UtcNow.Ticks;

        [Benchmark()]
        public string V0() {
            return Id.ToString();
        }

        [Benchmark(Baseline = true)]
        public unsafe string V1() {
            var id = Id;

            char* buffer = stackalloc char[13];
            buffer[0] = _encode32Chars[(int)(id >> 60) & 31];
            buffer[1] = _encode32Chars[(int)(id >> 55) & 31];
            buffer[2] = _encode32Chars[(int)(id >> 50) & 31];
            buffer[3] = _encode32Chars[(int)(id >> 45) & 31];
            buffer[4] = _encode32Chars[(int)(id >> 40) & 31];
            buffer[5] = _encode32Chars[(int)(id >> 35) & 31];
            buffer[6] = _encode32Chars[(int)(id >> 30) & 31];
            buffer[7] = _encode32Chars[(int)(id >> 25) & 31];
            buffer[8] = _encode32Chars[(int)(id >> 20) & 31];
            buffer[9] = _encode32Chars[(int)(id >> 15) & 31];
            buffer[10] = _encode32Chars[(int)(id >> 10) & 31];
            buffer[11] = _encode32Chars[(int)(id >> 5) & 31];
            buffer[12] = _encode32Chars[(int)id & 31];
            return new string(buffer, 0, 13);
        }

        [Benchmark]
        public string V2() {
            var id = Id;

            Span<char> buffer = stackalloc char[13];

            buffer[0] = _encode32Chars[(int)(id >> 60) & 31];
            buffer[1] = _encode32Chars[(int)(id >> 55) & 31];
            buffer[2] = _encode32Chars[(int)(id >> 50) & 31];
            buffer[3] = _encode32Chars[(int)(id >> 45) & 31];
            buffer[4] = _encode32Chars[(int)(id >> 40) & 31];
            buffer[5] = _encode32Chars[(int)(id >> 35) & 31];
            buffer[6] = _encode32Chars[(int)(id >> 30) & 31];
            buffer[7] = _encode32Chars[(int)(id >> 25) & 31];
            buffer[8] = _encode32Chars[(int)(id >> 20) & 31];
            buffer[9] = _encode32Chars[(int)(id >> 15) & 31];
            buffer[10] = _encode32Chars[(int)(id >> 10) & 31];
            buffer[11] = _encode32Chars[(int)(id >> 5) & 31];
            buffer[12] = _encode32Chars[(int)id & 31];

            return buffer.ToString();
        }

        [Benchmark]
        public string V3() {
            return string.Create(13, Id, (buffer, id) => {
                buffer[0] = _encode32Chars[(int)(id >> 60) & 31];
                buffer[1] = _encode32Chars[(int)(id >> 55) & 31];
                buffer[2] = _encode32Chars[(int)(id >> 50) & 31];
                buffer[3] = _encode32Chars[(int)(id >> 45) & 31];
                buffer[4] = _encode32Chars[(int)(id >> 40) & 31];
                buffer[5] = _encode32Chars[(int)(id >> 35) & 31];
                buffer[6] = _encode32Chars[(int)(id >> 30) & 31];
                buffer[7] = _encode32Chars[(int)(id >> 25) & 31];
                buffer[8] = _encode32Chars[(int)(id >> 20) & 31];
                buffer[9] = _encode32Chars[(int)(id >> 15) & 31];
                buffer[10] = _encode32Chars[(int)(id >> 10) & 31];
                buffer[11] = _encode32Chars[(int)(id >> 5) & 31];
                buffer[12] = _encode32Chars[(int)id & 31];
            });
        }

        [Benchmark]
        public string V4() {
            return string.Create(13, Id, (buffer, id) => {
                buffer[12] = _encode32Chars[(int)id & 31];
                buffer[11] = _encode32Chars[(int)(id >> 5) & 31];
                buffer[10] = _encode32Chars[(int)(id >> 10) & 31];
                buffer[9] = _encode32Chars[(int)(id >> 15) & 31];
                buffer[8] = _encode32Chars[(int)(id >> 20) & 31];
                buffer[7] = _encode32Chars[(int)(id >> 25) & 31];
                buffer[6] = _encode32Chars[(int)(id >> 30) & 31];
                buffer[5] = _encode32Chars[(int)(id >> 35) & 31];
                buffer[4] = _encode32Chars[(int)(id >> 40) & 31];
                buffer[3] = _encode32Chars[(int)(id >> 45) & 31];
                buffer[2] = _encode32Chars[(int)(id >> 50) & 31];
                buffer[1] = _encode32Chars[(int)(id >> 55) & 31];
                buffer[0] = _encode32Chars[(int)(id >> 60) & 31];
            });
        }

        [Benchmark]
        public string V5() {
            return string.Create(13, Id, (buffer, id) => {
                var encode32Chars = _encode32Chars;
                buffer[12] = encode32Chars[(int)id & 31];
                buffer[11] = encode32Chars[(int)(id >> 5) & 31];
                buffer[10] = encode32Chars[(int)(id >> 10) & 31];
                buffer[9] = encode32Chars[(int)(id >> 15) & 31];
                buffer[8] = encode32Chars[(int)(id >> 20) & 31];
                buffer[7] = encode32Chars[(int)(id >> 25) & 31];
                buffer[6] = encode32Chars[(int)(id >> 30) & 31];
                buffer[5] = encode32Chars[(int)(id >> 35) & 31];
                buffer[4] = encode32Chars[(int)(id >> 40) & 31];
                buffer[3] = encode32Chars[(int)(id >> 45) & 31];
                buffer[2] = encode32Chars[(int)(id >> 50) & 31];
                buffer[1] = encode32Chars[(int)(id >> 55) & 31];
                buffer[0] = encode32Chars[(int)(id >> 60) & 31];
            });
        }

        [Benchmark]
        public string V6() {
            return string.Create(13, Id, (buffer, id) => {
                var encode32CharsArray = _encode32CharsArray;
                buffer[12] = encode32CharsArray[id & 31];
                buffer[11] = encode32CharsArray[(id >> 5) & 31];
                buffer[10] = encode32CharsArray[(id >> 10) & 31];
                buffer[9] = encode32CharsArray[(id >> 15) & 31];
                buffer[8] = encode32CharsArray[(id >> 20) & 31];
                buffer[7] = encode32CharsArray[(id >> 25) & 31];
                buffer[6] = encode32CharsArray[(id >> 30) & 31];
                buffer[5] = encode32CharsArray[(id >> 35) & 31];
                buffer[4] = encode32CharsArray[(id >> 40) & 31];
                buffer[3] = encode32CharsArray[(id >> 45) & 31];
                buffer[2] = encode32CharsArray[(id >> 50) & 31];
                buffer[1] = encode32CharsArray[(id >> 55) & 31];
                buffer[0] = encode32CharsArray[(id >> 60) & 31];
            });
        }
    }

    class Program {
        public static void Main() {
            var summary = BenchmarkRunner.Run<BM>();

            //var bm = new BM();
            //Console.WriteLine(bm.V0());
            //Console.WriteLine(bm.V1());
            //Console.WriteLine(bm.V2());
            //Console.WriteLine(bm.V3());
            //Console.WriteLine(bm.V4());
            //Console.WriteLine(bm.V5());
            //Console.WriteLine(bm.V5());
            //Console.WriteLine(bm.V6());
        }
    }
}