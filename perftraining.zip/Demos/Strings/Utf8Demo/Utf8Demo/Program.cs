﻿using System;
using System.Buffers;
using System.Buffers.Text;
using System.IO;
using System.Text;

namespace Utf8Demo {
    class Program {
        static void Main(string[] args) {
            string path = @"d:\temp\test.txt";
            WriteFile(path);
            ReadFile(path);
            ReadFileUsingStackalloc(path);
            ReadFileUsingArrayPool(path);
        }

        private static void WriteFile(string path) {
            string text = "X-Mas,2020,12,25";
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            File.WriteAllBytes(path, bytes);
        }

        private static void ReadFile(string path) {
            byte[] bytes = File.ReadAllBytes(path);
            ReadOnlySpan<byte> span = bytes;
            var seperator = (byte)',';
            var name = Encoding.UTF8.GetString(span.SplitNext(seperator));
            Utf8Parser.TryParse(span.SplitNext(seperator), out int year, out _);
            Utf8Parser.TryParse(span.SplitNext(seperator), out int month, out _);
            Utf8Parser.TryParse(span.SplitNext(seperator), out int day, out _);
            Console.WriteLine($"{name} {year} {month} {day}");
        }

        private static void ReadFileUsingArrayPool(string path) {
            using var stream = File.OpenRead(path);
            byte[] bytes = ArrayPool<byte>.Shared.Rent((int)stream.Length);
            try {
                stream.Read(bytes);

                ReadOnlySpan<byte> span = bytes;

                var seperator = (byte)',';
                var name = Encoding.UTF8.GetString(span.SplitNext(seperator));
                Utf8Parser.TryParse(span.SplitNext(seperator), out int year, out _);
                Utf8Parser.TryParse(span.SplitNext(seperator), out int month, out _);
                Utf8Parser.TryParse(span.SplitNext(seperator), out int day, out _);
                Console.WriteLine($"{name} {year} {month} {day}");
            } finally {
                ArrayPool<byte>.Shared.Return(bytes);
            }
        }

        private static void ReadFileUsingStackalloc(string path) {
            using var stream = File.OpenRead(path);
            Span<byte> bytes = stackalloc byte[(int)stream.Length];
            stream.Read(bytes);

            ReadOnlySpan<byte> span = bytes;

            var seperator = (byte)',';
            var name = Encoding.UTF8.GetString(span.SplitNext(seperator));
            Utf8Parser.TryParse(span.SplitNext(seperator), out int year, out _);
            Utf8Parser.TryParse(span.SplitNext(seperator), out int month, out _);
            Utf8Parser.TryParse(span.SplitNext(seperator), out int day, out _);
            Console.WriteLine($"{name} {year} {month} {day}");
        }

    }
    public static class Extensions {

        /// <summary>
        /// Split the next part of this span with the given separator. 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="span">A reference to the span</param>
        /// <param name="seperator">A seperator that delimits the values</param>
        /// <returns>The first splitted value</returns>
        public static ReadOnlySpan<T> SplitNext<T>(this ref ReadOnlySpan<T> span, T seperator) where T : IEquatable<T> {
            int pos = span.IndexOf(seperator);
            if (pos > -1) {
                var part = span.Slice(0, pos);
                span = span.Slice(pos + 1);
                return part;
            } else {
                var part = span;
                span = span.Slice(span.Length);
                return part;
            }
        }
    }
}
