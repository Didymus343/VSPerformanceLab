namespace StringInternDemo {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private readonly List<string> _strings = new List<string>();

        private void Button1_Click(object sender, EventArgs e) {
            _strings.EnsureCapacity(_strings.Count + 1000 * 10);
            for (int i = 0; i < 1000; i++) {
                for (int t = 0; t < 10; t++) {
                    string txt = $"Hello {t}";
                    _strings.Add(txt);
                }
            }
        }

        private void Button2_Click(object sender, EventArgs e) {
            _strings.EnsureCapacity(_strings.Count + 1000 * 10);
            for (int i = 0; i < 1000; i++) {
                for (int t = 0; t < 10; t++) {
                    string txt = $"Hello {t}";
                    txt = string.Intern(txt);
                    _strings.Add(txt);
                }
            }
        }
    }
}