﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Text;

namespace ConsoleApp166 {
    class Program {
        static void Main(string[] args) {
            int length = 25;
            Random rand = new Random();

            string id = string.Create(length, rand, (Span<char> chars, Random r) => {
                for (int i = 0; i < chars.Length; i++) {
                    chars[i] = (char)(r.Next(48, 58));
                }
            });

            Console.WriteLine(id);

            //BenchmarkRunner.Run<BM>();

            //var b = new BMReverse();
            //Console.WriteLine(b.ArrayReverse());
            //Console.WriteLine(b.StringCreate());
            //Console.WriteLine(b.StringCreate2());

            BenchmarkRunner.Run<BMReverse>();

            //BenchmarkRunner.Run<BoundCheck>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        private int _length = 25;
        private Random _rand = new Random(1000);

        [Benchmark(Baseline = true)]
        public string StringCreate() {
            return string.Create(_length, _rand, (Span<char> chars, Random r) => {
                for (int i = 0; i < chars.Length; i++) {
                    chars[i] = (char)(r.Next(48, 58));
                }
            });
        }

        [Benchmark]
        public string StringBuilder() {
            var sb = new StringBuilder(_length);
            for (int i = 0; i < _length; i++) {
                sb.Append((char)(_rand.Next(48, 58)));
            }
            return sb.ToString();
        }
    }

    [MemoryDiagnoser]
    public class BMReverse {

        private readonly string _text = new string('x', 4096);

        [Benchmark()]
        public string StringCreate() {
            return string.Create(_text.Length, _text, (chars, input) => {
                input.AsSpan().CopyTo(chars);
                chars.Reverse();
            });
        }

        [Benchmark]
        public string ArrayReverse() {
            var a = _text.ToCharArray();
            Array.Reverse(a);
            return new string(a);
        }

        //[Benchmark()]
        //public unsafe string ReverseWithUnmanagedMemmory() {
        //    var revStr = new string(' ', _text.Length); // Allocation
        //    fixed (char* strPtr = _text)
        //    fixed (char* revStrPtr = revStr) {
        //        for (int src = 0, dst = _text.Length - 1; src < _text.Length; src++, dst--) {
        //            revStrPtr[dst] = strPtr[src];
        //        }
        //    }
        //    return revStr;
        //}
    }

    public class BoundCheck {

        [Benchmark]
        public int SpanForward() {
            int sum = 0;
            Span<int> span = new int[] { 3, 15, 43, 124, 55, 3245234, 2344, 234, 23, 4234, 234, 2, 23542435 };
            for (int i = 0; i < span.Length; i++) {
                sum += span[i]; // Bound checking
            }
            return sum;
        }

        [Benchmark(Baseline = true)]
        public int SpanBackward() {
            int sum = 0;
            Span<int> span = new int[] { 3, 15, 43, 124, 55, 3245234, 2344, 234, 23, 4234, 234, 2, 23542435 };
            for (int i = span.Length - 1; i > -1; i--) {
                sum += span[i]; // No bound check, i is lower than in the previous iteration
            }
            return sum;
        }

    }
}
