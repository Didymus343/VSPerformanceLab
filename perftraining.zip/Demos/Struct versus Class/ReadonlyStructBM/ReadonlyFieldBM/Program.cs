﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Runtime.CompilerServices;

namespace ReadonlyBM {
    class Program {
        static void Main(string[] args) {
            //BenchmarkRunner.Run<ReadonlyLocalAndReturnBM>();
            BenchmarkRunner.Run<InParameterBM>();
            //BenchmarkRunner.Run<ReadonlyFieldBM>();
        }
    }

    public class ReadonlyFieldBM {

        private readonly PointStruct _p1 = new PointStruct(3, 4);
        private PointStruct _p2 = new PointStruct(3, 4);
        private readonly ReadonlyPointStruct _p3 = new ReadonlyPointStruct(3, 4);
        private ReadonlyPointStruct _p4 = new ReadonlyPointStruct(3, 4);

        [Benchmark]
        public long PointInReadOnlyField() {
            return _p1.Foo();
        }

        [Benchmark(Baseline = true)]
        public long PointInReadWriteField() {
            return _p2.Foo();
        }

        [Benchmark]
        public long ReadonlyPointInReadOnlyField() {
            return _p3.Foo();
        }

        [Benchmark()]
        public long ReadonlyPointInReadWriteField() {
            return _p4.Foo();
        }

    }

    public class InParameterBM {

        [Benchmark]
        public long Point() {
            var p = new PointStruct(1, 2);
            return Bar(in p);
        }

        [Benchmark(Baseline = true)]
        public long ReadonlyPoint() {
            var p = new ReadonlyPointStruct(1, 2);
            return Bar(in p);
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private long Bar(in PointStruct p) {
            return p.Foo(); // Defensive Copy
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private long Bar(in ReadonlyPointStruct p) {
            return p.Foo();
        }

    }

    public class ReadonlyLocalAndReturnBM {

        private PointStruct _p1 = new PointStruct(3, 4);
        private ReadonlyPointStruct _p2 = new ReadonlyPointStruct(3, 4);

        [Benchmark]
        public long Point() {
            ref readonly PointStruct p = ref GetPoint();
            return p.Foo();
        }

        [Benchmark(Baseline = true)]
        public long ReadonlyPoint() {
            ref readonly ReadonlyPointStruct p = ref GetReadonlyPoint();
            return p.Foo();
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private ref readonly PointStruct GetPoint() {
            return ref _p1;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private ref readonly ReadonlyPointStruct GetReadonlyPoint() {
            return ref _p2;
        }

    }

    public struct PointStruct {

        public readonly long X, Y;

        public PointStruct(long x, long y) => (X, Y) = (x, y);

        [MethodImpl(MethodImplOptions.NoInlining)]
        public long Foo() => this.X + this.Y;

    }

    public readonly struct ReadonlyPointStruct {

        public readonly long X, Y;

        public ReadonlyPointStruct(long x, long y) => (X, Y) = (x, y);

        [MethodImpl(MethodImplOptions.NoInlining)]
        public long Foo() => this.X + this.Y;

    }

}
