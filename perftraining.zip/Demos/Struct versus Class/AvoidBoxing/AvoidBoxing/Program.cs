﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Toolchains.CsProj;
using System;

namespace AvoidBoxing {
    class Program {
        static void Main(string[] args) {
            BenchmarkRunner.Run<AvoidBoxingWithStringFormat>();
            //BenchmarkRunner.Run<AvoidBoxingWithStringConcat>();
        }
    }

    public class MultipleRuntimes : ManualConfig {
        public MultipleRuntimes() {
            Add(Job.Default.With(CsProjClassicNetToolchain.Net48)); // .NET Framework 4.8
            Add(Job.Default.With(CsProjCoreToolchain.NetCoreApp20)); // .NET Core 2.0
            Add(Job.Default.With(CsProjCoreToolchain.NetCoreApp30).AsBaseline()); // .NET Core 3.0
        }
    }

    [SimpleJob(RuntimeMoniker.Net48)]
    [SimpleJob(RuntimeMoniker.NetCoreApp20)]
    [SimpleJob(RuntimeMoniker.NetCoreApp30, baseline: true)]
    //[Config(typeof(MultipleRuntimes))]
    [MemoryDiagnoser]
    public class AvoidBoxingWithStringFormat {

        private const int Iterations = 10_000;

        [Benchmark]
        public int FormatString() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++) {
                s = $"Value {d:N2}";
            }
            return s.Length;
        }

        //[Benchmark(Baseline = true)]
        [Benchmark]
        public int FormatStringWithToString() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++) {
                s = $"Value {d.ToString("N2")}";
            }
            return s.Length;
        }
    }

    [Config(typeof(MultipleRuntimes))]
    [MemoryDiagnoser]
    public class AvoidBoxingWithStringConcat {

        private const int Iterations = 10_000;

        [Benchmark]
        public int StringConcat() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++)
                s = "Value" + i;
            return s.Length;
        }

        [Benchmark(Baseline = true)]
        public int StringConcatWithToString() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++)
                s = "Value" + i.ToString();
            return s.Length;
        }

        [Benchmark]
        public int StringFormat() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++)
                s = $"Value {i}";
            return s.Length;
        }

        [Benchmark]
        public int StringFormatWithToString() {
            string s = string.Empty;
            double d = 12.5;
            for (int i = 0; i < Iterations; i++)
                s = $"Value {i.ToString()}";
            return s.Length;
        }
    }

}
