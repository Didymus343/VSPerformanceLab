﻿using Microsoft.Extensions.PlatformAbstractions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ConsoleApp82 {
    class Program {
        static void Main(string[] args) {
            decimal d = 12.5M;
            string s = string.Empty;
            Console.WriteLine(PlatformServices.Default.Application.RuntimeFramework);

            var sw = Stopwatch.StartNew();
            for (int i = 0; i < 10_000_000; i++) {
                //s = $"Value {d:N2}";
                s = "abc" + i;
            }
            sw.Stop();
            Console.WriteLine(s);
            Console.WriteLine(sw.Elapsed.ToString());

            sw = Stopwatch.StartNew();
            for (int i = 0; i < 10_000_000; i++) {
                //s = $"Value {d.ToString("N2")}";
                s = "abc" + i.ToString();
            }
            sw.Stop();
            Console.WriteLine(s);
            Console.WriteLine(sw.Elapsed.ToString());
        }
    }
}
