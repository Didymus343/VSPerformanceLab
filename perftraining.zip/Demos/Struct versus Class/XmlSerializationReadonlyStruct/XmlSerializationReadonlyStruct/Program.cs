﻿using System.Xml.Serialization;

var employee = new Employee("Fons", 2000);

var point = new Point(1, 2);
Console.WriteLine(point.ToString());

//var xml = SerializeToXml(employee);
var xml = SerializeToXml(point);
Console.WriteLine(xml);

//xml = "<Employee><Name>Jim</Name><Salary>4000</Salary></Employee>";
//employee = DeserializeFromXml<Employee>(xml);
//Console.WriteLine(employee.ToString());

xml = "<Point X=\"3\" Y=\"4\" />";
point = DeserializeFromXml<Point>(xml);
Console.WriteLine(point.ToString());

static string SerializeToXml<T>(T point) {
    XmlSerializer serializer = new XmlSerializer(typeof(T));
    using (var sw = new StringWriter()) {
        serializer.Serialize(sw, point);
        return sw.ToString();
    }
}

static T DeserializeFromXml<T>(string xml) {
    XmlSerializer serializer = new XmlSerializer(typeof(T));
    using (var sr = new StringReader(xml)) {
        return (T)serializer.Deserialize(sr)!;
    }
}

