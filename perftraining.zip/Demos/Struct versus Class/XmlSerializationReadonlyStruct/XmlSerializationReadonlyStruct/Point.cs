﻿using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

//public record struct Point : IXmlSerializable {

//    public int X; 
//    public int Y; 

//    public Point(int x, int y) {
//        X = x;
//        Y = y;
//    }

//    public double Dist => Math.Sqrt((X * X) + (Y * Y));

//    public override string ToString() => $"{X}:{Y}";

//    public XmlSchema GetSchema() => null!;

//    public void ReadXml(XmlReader reader) {
//        int x = int.Parse(reader.MoveToAttribute("X") ? reader.Value : "0");
//        int y = int.Parse(reader.MoveToAttribute("Y") ? reader.Value : "0");
//        reader.Skip();

//        this = new Point(x, y);
//    }

//    public void WriteXml(XmlWriter writer) {
//        writer.WriteAttributeString("X", X.ToString());
//        writer.WriteAttributeString("Y", Y.ToString());
//    }
//}


public readonly record struct Point : IXmlSerializable {

    public readonly int X;
    public readonly int Y;

    public Point(int x, int y) {
        X = x;
        Y = y;
    }

    public void ReadXml(XmlReader reader) {
        int x = int.Parse(reader.MoveToAttribute("X") ? reader.Value : "0");
        int y = int.Parse(reader.MoveToAttribute("Y") ? reader.Value : "0");
        reader.Skip();

        // Update this using the Unsafe.AsRef() workaround 
        Unsafe.AsRef(this) = new Point(x, y);
    }

    public void WriteXml(XmlWriter writer) {
        writer.WriteAttributeString("X", X.ToString());
        writer.WriteAttributeString("Y", Y.ToString());
    }

    public XmlSchema GetSchema() => null!;

    public double Dist => Math.Sqrt((X * X) + (Y * Y));

    public override string ToString() => $"{X}:{Y}";
}

