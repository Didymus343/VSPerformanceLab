﻿using System.Xml;
using System.Xml.Serialization;

public class Employee {

    public string? Name { get; set; }

    [XmlAttribute]
    public decimal Salary { get; set; }

    public Employee() {
        // Public parameterless constructuctor is
        // required for Deserialization
    }

    public Employee(string? name, decimal salary) {
        Name = name;
        Salary = salary;
    }

    public override string ToString() => $"Employee {Name} {Salary}";
}

