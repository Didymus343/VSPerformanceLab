﻿using System;
using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace ClassLibrary1 {

    public readonly struct Point : IXmlSerializable {

        public readonly int X; // { get; set; }
        public readonly int Y; // { get; set; }

        public Point(int x, int y) {
            X = x;
            Y = y;
        }

        public double Dist => Math.Sqrt((X * X) + (Y * Y));

        public override string ToString() => $"{X}:{Y}";

        public XmlSchema GetSchema() => null;

        public void ReadXml(XmlReader reader) {
            int x = int.Parse(reader.MoveToAttribute("X") ? reader.Value : "0");
            int y = int.Parse(reader.MoveToAttribute("Y") ? reader.Value : "0");
            reader.Skip();

            // Update this using the Unsafe.AsRef() workaround which is required for readonly structs
            Unsafe.AsRef(this) = new Point(x, y);
        }

        public void WriteXml(XmlWriter writer) {
            writer.WriteAttributeString("X", X.ToString());
            writer.WriteAttributeString("Y", Y.ToString());
        }
    }
}