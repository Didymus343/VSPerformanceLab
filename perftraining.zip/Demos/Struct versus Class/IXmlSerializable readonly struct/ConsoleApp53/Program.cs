﻿using ClassLibrary1;
using System;
using System.IO;
using System.Xml.Serialization;

var point = new Point(1, 2);
Console.WriteLine(point.ToString());
Console.WriteLine(point.Dist);

// Serialize
XmlSerializer serializer = new XmlSerializer(typeof(Point));
using (var sw = new StringWriter()) {
    serializer.Serialize(sw, point);
    sw.Flush();
    Console.WriteLine(sw.ToString());
}

// Deserialize
using (var sr = new StringReader("<Point X=\"3\" Y=\"4\" />")) {
    point = (Point)serializer.Deserialize(sr);
}

Console.WriteLine(point.ToString());
Console.WriteLine(point.Dist);
