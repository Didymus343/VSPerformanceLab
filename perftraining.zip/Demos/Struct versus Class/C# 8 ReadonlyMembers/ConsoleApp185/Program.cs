﻿using System;

namespace ConsoleApp185 {
    class Program {
        static void Main(string[] args) {
            var p = new PointStruct(3, 4);
            Foo(p);
        }

        private static void Foo(in PointStruct p) {
            Console.WriteLine(p.Dist);
            Console.WriteLine(p.ToString());

            p.Swap(); // Defensive copy
            Console.WriteLine(p.ToString());
        }
    }

    struct PointStruct {

        public int X;
        public int Y;

        public PointStruct(int x, int y) {
            this.X = x;
            this.Y = y;
        }

        public void Swap() {
            this = new PointStruct(this.Y, this.X);
        }

        public readonly double Dist => Math.Sqrt((X * X) + (Y * Y));

        public readonly override string ToString() => $"({X.ToString()},{Y.ToString()})";
    }


}
