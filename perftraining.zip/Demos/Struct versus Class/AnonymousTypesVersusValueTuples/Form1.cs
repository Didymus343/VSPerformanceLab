﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4 {
    public partial class Form1 : Form {
        public Form1() {
            this.InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e) {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            AnonymousTypes();
            sw.Stop();
            (sender as Button).Text += Environment.NewLine + sw.Elapsed.ToString();
        }

        private static long AnonymousTypes() {
            var l = Enumerable.Range(1, 10_000_000)
                                .Select(i => new { A = i, B = i * 2, C = i / 2D }).ToList(10_000_000);
            long t = 1;
            foreach (var item in l) {
                t += item.A;
            }
            return t;
        }

        private void Button2_Click(object sender, EventArgs e) {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            ValueTuples();
            sw.Stop();
            (sender as Button).Text += Environment.NewLine + sw.Elapsed.ToString();
        }

        private static long ValueTuples() {
            var l = Enumerable.Range(1, 10_000_000)
                                .Select(i => (A: i, B: i * 2, C: i / 2D)).ToList(10_000_000);

            long t = 1;
            foreach (var item in l) {
                t += item.A;
            }
            return t;
        }
    }

    public static class Extensions {
        public static List<TSource> ToList<TSource>(this IEnumerable<TSource> source, int capacity) {
            var list = new List<TSource>(capacity);
            list.AddRange(source);
            return list;
        }
    }
}
