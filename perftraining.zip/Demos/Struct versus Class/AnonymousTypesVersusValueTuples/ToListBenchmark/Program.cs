﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Toolchains.CsProj;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ToListBenchmark {
    internal class Program {
        private static void Main(string[] args) {
            //BenchmarkRunner.Run<TestWithLinqRange>();
            BenchmarkRunner.Run<TestWithLinqRangeAndWhere>();
        }
    }

    [MemoryDiagnoser]
    [Config(typeof(MultipleRuntimes))]
    public class TestWithLinqRange {
        private const int SIZE = 1_000_000;

        private readonly IEnumerable<(int, int, double)> _data =
            Enumerable.Range(1, SIZE)
                      .Select(i => (A: i, B: i * 2, C: i / 2D));

        [Benchmark]
        public List<(int, int, double)> ListCtor() {
            return new List<(int, int, double)>(_data);
        }

        [Benchmark]
        public List<(int, int, double)> ToList() {
            return _data.ToList();
        }

        [Benchmark(Baseline = true)]
        public List<(int, int, double)> ToListWithCapacity() {
            return _data.ToList(SIZE);
        }

    }

    [MemoryDiagnoser]
    public class TestWithLinqRangeAndWhere {
        private const int SIZE = 1_000_000;

        private readonly IEnumerable<(int, int, double)> _data =
            Enumerable.Range(1, SIZE)
                      .Select(i => (A: i, B: i * 2, C: i / 2D))
                      .Where(n => n.A > 0);

        [Benchmark]
        public List<(int, int, double)> ListCtor() {
            return new List<(int, int, double)>(_data);
        }

        [Benchmark]
        public List<(int, int, double)> ToList() {
            return _data.ToList();
        }

        [Benchmark(Baseline = true)]
        public List<(int, int, double)> ToListWithCapacity() {
            return _data.ToList(SIZE);
        }

    }

    public class MultipleRuntimes : ManualConfig {
        public MultipleRuntimes() {
            Add(Job.Default.With(CsProjClassicNetToolchain.Net472)); // .NET Framework 4.7.1
            Add(Job.Default.With(CsProjCoreToolchain.NetCoreApp20)); // .NET Core 2.0
            Add(Job.Default.With(CsProjCoreToolchain.NetCoreApp21)); // .NET Core 2.1
        }
    }

    internal static class Extensions {
        public static List<TSource> ToList<TSource>(this IEnumerable<TSource> source, int capacity) {
            if (source == null) {
                //throw Error.ArgumentNull(nameof(source));
                throw new ArgumentNullException(nameof(source));
            }

            if (capacity < 0) {
                throw new ArgumentOutOfRangeException(nameof(capacity), "Non-negative number required.");
            }

            var list = new List<TSource>(capacity);
            list.AddRange(source);
            return list;
        }

    }
}
