﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;

namespace ConsoleApp91 {
    class Program {
        static void Main(string[] args) {
            //var origin1 = Point1.Origin; // Copy, expensive (24 bytes)
            //ref readonly var origin2 = ref Point2.Origin; // Reference = Alias, cheap
            //Console.WriteLine(origin1);
            //Console.WriteLine(origin2);

            BenchmarkRunner.Run<BM>();
        }
    }

    //[MemoryDiagnoser]
    public class BM {

        [Benchmark]
        public double P1() {
            return Point1.Origin.X;
        }

        [Benchmark]
        public double P2() {
            var o = Point1.Origin;
            return o.X;
        }

        [Benchmark(Baseline = true)]
        public double P3() {
            ref readonly var o = ref Point2.Origin;
            return o.X;
        }

        [Benchmark()]
        public double P4() {
            var o = Point2.Origin;
            return o.X;
        }

        [Benchmark()]
        public double P5() {
            return Point2.Origin.X;
        }
    }

    public readonly struct Point1 {
        public double X { get; }
        public double Y { get; }
        public double Z { get; }

        public Point1(double x, double y, double z) => (this.X, this.Y, this.Z) = (x, y, z);

        public static Point1 Origin { get; } = new Point1(0,0,0);
    }

    public readonly struct Point2 {
        public double X { get; }
        public double Y { get; }
        public double Z { get; }

        public Point2(double x, double y, double z) => (this.X, this.Y, this.Z) = (x, y, z);

        private static readonly Point2 _origin = new Point2(0,0,0);

        public static ref readonly Point2 Origin => ref _origin;  // must be readonly because _origin is readonly
    }

}
