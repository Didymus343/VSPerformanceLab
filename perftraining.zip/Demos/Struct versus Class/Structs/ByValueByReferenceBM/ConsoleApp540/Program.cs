﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Engines;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using System.Runtime.CompilerServices;

class Program {
    static void Main(string[] args) {
        BenchmarkRunner.Run<BM>();
    }
}

[SimpleJob(RuntimeMoniker.Net60)]
public class BM {

    private MyValue _x = new MyValue();
    private MyValue _y = new MyValue();

    [Benchmark]
    public void ByValue() {
        for (int i = 0; i < 100; i++) {
            Foo(_x, _y);
        }
        [MethodImpl(MethodImplOptions.NoInlining)] 
        long Foo(MyValue a, MyValue b) => a.A + b.B; // Copy
    }

    [Benchmark(Baseline = true)]
    public void ByReference() {
        for (int i = 0; i < 100; i++) {
            Foo(ref _x, ref _y);
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        long Foo(ref MyValue a, ref MyValue b) => a.A + b.B; // Alias
    }
}

struct MyValue { // Size 24
    public long A;
    public long B;
    public long C;
    public long D;
    public long E;
    //public long F;
}

struct MyValue2 { // Size 8
    public int A;
    public int B;
    public int C;
}