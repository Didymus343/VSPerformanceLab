﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using ObjectLayoutInspector;
using System;
using System.Runtime.InteropServices;

namespace ConsoleApp1 {
    class Program {
        static void Main() {
            TypeLayout.PrintLayout<Test1>();
            //TypeLayout.PrintLayout<Test2>();
            //TypeLayout.PrintLayout<Test3>();
            //BenchmarkRunner.Run<BM>();
        }
    }

    [MemoryDiagnoser]
    public class BM {

        [Benchmark]
        public Test1[] NotAlignedTypes() {
            return new Test1[1000];
        }

        [Benchmark(Baseline = true)]
        public Test3[] AlignedTypes() {
            return new Test3[1000];
        }
    }

    public struct Test1 { // 24 bytes
        public int A;  // 4 bytes + 4 Padding
        public long B; // 8 bytes
        public bool C; // 1 byte + 7 padding
    }

    public struct Test2 { // 16 bytes
        public int A;  // 4 bytes 
        public bool C; // 1 byte + 3 padding
        public long B; // 8 bytes
    }

    [StructLayout(LayoutKind.Auto)]
    public struct Test3 { // 16 bytes (B,A,C)
        public int A;
        public long B;
        public bool C;
    }


}
