﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e) {
            var sw = System.Diagnostics.Stopwatch.StartNew();

            PointStruct[] a1 = new PointStruct[10_000_000];
            for (int i = 0; i < a1.Length; i++) {
                a1[i] = new PointStruct(i, i);
            }

            sw.Stop();
            button1.Text = sw.Elapsed.ToString();
        }

        private void Button2_Click(object sender, EventArgs e) {
            var sw = System.Diagnostics.Stopwatch.StartNew();

            PointClass[] a1 = new PointClass[10_000_000];
            for (int i = 0; i < a1.Length; i++) {
                a1[i] = new PointClass(i, i);
            }

            sw.Stop();
            button2.Text = sw.Elapsed.ToString();
        }
    }





    class PointClass {

        public long X { get; set; }
        public long Y { get; set; }

        public PointClass(long x, long y) {
            this.X = x; this.Y = y;
        }

        public void Swap() {
            long oldX = this.X;
            this.X = this.Y;
            this.Y = oldX;
        }

        public double Dist => Math.Sqrt((X * X) + (Y * Y));

        public override string ToString() {
            return $"({X.ToString()},{Y.ToString()})";
        }
    }

    struct PointStruct {

        public long X { get; set; }
        public long Y { get; set; }

        public PointStruct(long x, long y) {
            this.X = x; this.Y = y;
        }
        public void Swap() {
            //long oldX = this.X;
            //this.X = this.Y;
            //this.Y = oldX;
            this = new PointStruct(this.Y, this.X);
        }

        public double Dist => Math.Sqrt((X * X) + (Y * Y));

        public override string ToString() {
            return $"({X.ToString()},{Y.ToString()})";
        }
    }
}
