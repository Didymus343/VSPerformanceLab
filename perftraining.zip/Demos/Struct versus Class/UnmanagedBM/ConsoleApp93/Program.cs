﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Runtime.InteropServices;

namespace ConsoleApp37 {
    public struct Point2D {
        public int X, Y;
        public override string ToString() => $"({X.ToString()},{Y.ToString()})";
    }

    class Program {

        static void Main(string[] args) {
            BenchmarkRunner.Run<BM>();
        }

    }

    [MemoryDiagnoser]
    public class BM {

        private int[] a = new int[] { 1, 2, 3, 4 };

        [Benchmark(Baseline = true)]
        public int Read() {
            return BM.Read<Point2D>(a, 2).X;
        }

        [Benchmark]
        public int RefRead() {
            return BM.RefRead<Point2D>(a, 2).X;
        }

        [Benchmark]
        public int ReadOld() {
            return BM.ReadOld<Point2D>(a, 2).X;
        }

        static unsafe T Read<T>(int[] data, int offset) where T : unmanaged {
            fixed (int* p = &data[offset]) {
                return *(T*)p; // Only allowed with 'where T : unmanaged'
            }
        }

        static unsafe ref T RefRead<T>(int[] data, int offset) where T : unmanaged {
            fixed (int* p = &data[offset]) {
                return ref *(T*)p;  // Only allowed with 'where T : unmanaged'
            }
        }

        static T ReadOld<T>(ReadOnlySpan<int> data, int offset) where T : struct {
            var bytes = MemoryMarshal.Cast<int, byte>(data);
            if (MemoryMarshal.TryRead<T>(bytes.Slice(offset * 4), out var v)) {
                return v;
            }
            return default;
        }
    }
}

